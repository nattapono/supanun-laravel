
<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    				<script>document.documentElement.className = document.documentElement.className + ' yes-js js_active js'</script>
				<title>Augury WordPress Theme &#8211; Your SUPER-powered WP Engine Site</title>
<meta name='robots' content='noindex, nofollow' />
<link rel='dns-prefetch' href='//code.jquery.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="Augury WordPress Theme &raquo; Feed" href="https://dtaugury.wpengine.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Augury WordPress Theme &raquo; Comments Feed" href="https://dtaugury.wpengine.com/comments/feed/" />
<script type="text/javascript">
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/dtaugury.wpengine.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.3"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83e\udef1\ud83c\udffb\u200d\ud83e\udef2\ud83c\udfff","\ud83e\udef1\ud83c\udffb\u200b\ud83e\udef2\ud83c\udfff")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
</script>
<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 0.07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css' href='https://dtaugury.wpengine.com/wp-includes/css/dist/block-library/style.min.css?ver=6.3' type='text/css' media='all' />
<style id='wp-block-library-theme-inline-css' type='text/css'>
.wp-block-audio figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-audio figcaption{color:hsla(0,0%,100%,.65)}.wp-block-audio{margin:0 0 1em}.wp-block-code{border:1px solid #ccc;border-radius:4px;font-family:Menlo,Consolas,monaco,monospace;padding:.8em 1em}.wp-block-embed figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-embed figcaption{color:hsla(0,0%,100%,.65)}.wp-block-embed{margin:0 0 1em}.blocks-gallery-caption{color:#555;font-size:13px;text-align:center}.is-dark-theme .blocks-gallery-caption{color:hsla(0,0%,100%,.65)}.wp-block-image figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-image figcaption{color:hsla(0,0%,100%,.65)}.wp-block-image{margin:0 0 1em}.wp-block-pullquote{border-bottom:4px solid;border-top:4px solid;color:currentColor;margin-bottom:1.75em}.wp-block-pullquote cite,.wp-block-pullquote footer,.wp-block-pullquote__citation{color:currentColor;font-size:.8125em;font-style:normal;text-transform:uppercase}.wp-block-quote{border-left:.25em solid;margin:0 0 1.75em;padding-left:1em}.wp-block-quote cite,.wp-block-quote footer{color:currentColor;font-size:.8125em;font-style:normal;position:relative}.wp-block-quote.has-text-align-right{border-left:none;border-right:.25em solid;padding-left:0;padding-right:1em}.wp-block-quote.has-text-align-center{border:none;padding-left:0}.wp-block-quote.is-large,.wp-block-quote.is-style-large,.wp-block-quote.is-style-plain{border:none}.wp-block-search .wp-block-search__label{font-weight:700}.wp-block-search__button{border:1px solid #ccc;padding:.375em .625em}:where(.wp-block-group.has-background){padding:1.25em 2.375em}.wp-block-separator.has-css-opacity{opacity:.4}.wp-block-separator{border:none;border-bottom:2px solid;margin-left:auto;margin-right:auto}.wp-block-separator.has-alpha-channel-opacity{opacity:1}.wp-block-separator:not(.is-style-wide):not(.is-style-dots){width:100px}.wp-block-separator.has-background:not(.is-style-dots){border-bottom:none;height:1px}.wp-block-separator.has-background:not(.is-style-wide):not(.is-style-dots){height:2px}.wp-block-table{margin:0 0 1em}.wp-block-table td,.wp-block-table th{word-break:normal}.wp-block-table figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-table figcaption{color:hsla(0,0%,100%,.65)}.wp-block-video figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-video figcaption{color:hsla(0,0%,100%,.65)}.wp-block-video{margin:0 0 1em}.wp-block-template-part.has-background{margin-bottom:0;margin-top:0;padding:1.25em 2.375em}
</style>
<link rel='stylesheet' id='wc-blocks-vendors-style-css' href='https://dtaugury.wpengine.com/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-vendors-style.css?ver=10.4.6' type='text/css' media='all' />
<link rel='stylesheet' id='wc-blocks-style-css' href='https://dtaugury.wpengine.com/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-style.css?ver=10.4.6' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-selectBox-css' href='https://dtaugury.wpengine.com/wp-content/plugins/yith-woocommerce-wishlist/assets/css/jquery.selectBox.css?ver=1.2.0' type='text/css' media='all' />
<link rel='stylesheet' id='yith-wcwl-font-awesome-css' href='https://dtaugury.wpengine.com/wp-content/plugins/yith-woocommerce-wishlist/assets/css/font-awesome.css?ver=4.7.0' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce_prettyPhoto_css-css' href='//dtaugury.wpengine.com/wp-content/plugins/woocommerce/assets/css/prettyPhoto.css?ver=3.1.6' type='text/css' media='all' />
<link rel='stylesheet' id='yith-wcwl-main-css' href='https://dtaugury.wpengine.com/wp-content/plugins/yith-woocommerce-wishlist/assets/css/style.css?ver=3.23.0' type='text/css' media='all' />
<style id='yith-wcwl-main-inline-css' type='text/css'>
.yith-wcwl-share li a{color: #FFFFFF;}.yith-wcwl-share li a:hover{color: #FFFFFF;}.yith-wcwl-share a.facebook{background: #39599E; background-color: #39599E;}.yith-wcwl-share a.facebook:hover{background: #39599E; background-color: #39599E;}.yith-wcwl-share a.twitter{background: #45AFE2; background-color: #45AFE2;}.yith-wcwl-share a.twitter:hover{background: #39599E; background-color: #39599E;}.yith-wcwl-share a.pinterest{background: #AB2E31; background-color: #AB2E31;}.yith-wcwl-share a.pinterest:hover{background: #39599E; background-color: #39599E;}.yith-wcwl-share a.email{background: #FBB102; background-color: #FBB102;}.yith-wcwl-share a.email:hover{background: #39599E; background-color: #39599E;}.yith-wcwl-share a.whatsapp{background: #00A901; background-color: #00A901;}.yith-wcwl-share a.whatsapp:hover{background: #39599E; background-color: #39599E;}
</style>
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--color--primary: #ffffff;--wp--preset--color--secondary: #ffa35a;--wp--preset--color--tertiary: #ffffff;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='contact-form-7-css' href='https://dtaugury.wpengine.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.7.7' type='text/css' media='all' />
<link rel='stylesheet' id='fontawesome-all-css' href='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-booking-manager/vc/css/fontawesome-all.min.css?ver=6.3' type='text/css' media='all' />
<link rel='stylesheet' id='dt-booking-manager-css' href='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-booking-manager/vc/css/booking.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-ui-datepicker-css' href='https://code.jquery.com/ui/1.11.0/themes/smoothness/jquery-ui.css?ver=6.3' type='text/css' media='all' />
<link rel='stylesheet' id='fontawesome-icons-css' href='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-portfolio-addon/css/fontawesome-all.min.css?ver=6.3' type='text/css' media='all' />
<link rel='stylesheet' id='dtportfolio-animation-css' href='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-portfolio-addon/css/animations.css?ver=6.3' type='text/css' media='all' />
<link rel='stylesheet' id='dtportfolio-fullpage-css' href='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-portfolio-addon/css/jquery.fullPage.css?ver=6.3' type='text/css' media='all' />
<link rel='stylesheet' id='dtportfolio-ilightbox-css' href='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-portfolio-addon/css/ilightbox.css?ver=6.3' type='text/css' media='all' />
<link rel='stylesheet' id='dtportfolio-multiscroll-css' href='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-portfolio-addon/css/jquery.multiscroll.css?ver=6.3' type='text/css' media='all' />
<link rel='stylesheet' id='dtportfolio-swiper-css' href='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-portfolio-addon/css/swiper.min.css?ver=6.3' type='text/css' media='all' />
<link rel='stylesheet' id='dtportfolio-frontend-css' href='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-portfolio-addon/css/frontend.css?ver=6.3' type='text/css' media='all' />
<style id='dtportfolio-frontend-inline-css' type='text/css'>
.dtportfolio-item .dtportfolio-image-overlay .links a:hover, .dtportfolio-item .dtportfolio-image-overlay a:hover, .dtportfolio-fullpage-carousel .dtportfolio-fullpage-carousel-content a:hover, .dtportfolio-item.dtportfolio-hover-modern-title .dtportfolio-image-overlay .links a:hover, .dtportfolio-swiper-pagination-holder .dtportfolio-swiper-playpause:hover, .dtportfolio-categories a:hover { color:#ffffff; }.dtportfolio-swiper-pagination-holder .swiper-pagination-bullet-active { background:#ffffff; }
</style>
<link rel='stylesheet' id='dtportfolio-responsive-css' href='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-portfolio-addon/css/responsive.css?ver=6.3' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='jquery-colorbox-css' href='https://dtaugury.wpengine.com/wp-content/plugins/yith-woocommerce-compare/assets/css/colorbox.css?ver=1.4.21' type='text/css' media='all' />
<link rel='stylesheet' id='yith-quick-view-css' href='https://dtaugury.wpengine.com/wp-content/plugins/yith-woocommerce-quick-view/assets/css/yith-quick-view.css?ver=1.29.0' type='text/css' media='all' />
<style id='yith-quick-view-inline-css' type='text/css'>

				#yith-quick-view-modal .yith-wcqv-main{background:#ffffff;}
				#yith-quick-view-close{color:#cdcdcd;}
				#yith-quick-view-close:hover{color:#ff0000;}
</style>
<link rel='stylesheet' id='jet-elements-css' href='https://dtaugury.wpengine.com/wp-content/plugins/jet-elements/assets/css/jet-elements.css?ver=2.6.11' type='text/css' media='all' />
<link rel='stylesheet' id='jet-elements-skin-css' href='https://dtaugury.wpengine.com/wp-content/plugins/jet-elements/assets/css/jet-elements-skin.css?ver=2.6.11' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css' href='https://dtaugury.wpengine.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.20.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-legacy-css' href='https://dtaugury.wpengine.com/wp-content/plugins/elementor/assets/css/frontend-legacy.min.css?ver=3.14.1' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='https://dtaugury.wpengine.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.14.1' type='text/css' media='all' />
<link rel='stylesheet' id='swiper-css' href='https://dtaugury.wpengine.com/wp-content/plugins/elementor/assets/lib/swiper/css/swiper.min.css?ver=5.3.6' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-25447-css' href='https://dtaugury.wpengine.com/wp-content/uploads/elementor/css/post-25447.css?ver=1692845409' type='text/css' media='all' />
<link rel='stylesheet' id='jet-tabs-frontend-css' href='https://dtaugury.wpengine.com/wp-content/plugins/jet-tabs/assets/css/jet-tabs-frontend.css?ver=2.1.22' type='text/css' media='all' />
<link rel='stylesheet' id='jet-tricks-frontend-css' href='https://dtaugury.wpengine.com/wp-content/plugins/jet-tricks/assets/css/jet-tricks-frontend.css?ver=1.4.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-global-css' href='https://dtaugury.wpengine.com/wp-content/uploads/elementor/css/global.css?ver=1692845410' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-20398-css' href='https://dtaugury.wpengine.com/wp-content/uploads/elementor/css/post-20398.css?ver=1692845412' type='text/css' media='all' />
<link rel='stylesheet' id='augury-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/style.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='augury-base-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/css/base.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='augury-grid-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/css/grid.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='augury-widget-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/css/widget.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='augury-layout-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/css/layout.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='augury-blog-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/css/blog.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='augury-custom-class-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/css/custom-class.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='augury-browsers-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/css/browsers.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='augury-animations-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/css/animations.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='prettyphoto-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/css/prettyPhoto.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='custom-font-awesome-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/css/all.min.css?ver=6.3' type='text/css' media='all' />
<link rel='stylesheet' id='pe-icon-7-stroke-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/css/pe-icon-7-stroke.css?ver=6.3' type='text/css' media='all' />
<link rel='stylesheet' id='stroke-gap-icons-style-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/css/stroke-gap-icons-style.css?ver=6.3' type='text/css' media='all' />
<link rel='stylesheet' id='icon-moon-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/css/icon-moon.css?ver=6.3' type='text/css' media='all' />
<link rel='stylesheet' id='material-design-iconic-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/css/material-design-iconic-font.min.css?ver=6.3' type='text/css' media='all' />
<link rel='stylesheet' id='augury-woo-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/css/woocommerce.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='augury-woo-default-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/css/woocommerce/woocommerce-default.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='augury-woo-hovers-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/css/woocommerce/woocommerce-hovers.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='augury-woo-custom-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/css/woocommerce/woocommerce-custom.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='augury-customevent-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/tribe-events/custom.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='augury-magnific-popup-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/magnific/magnific-popup.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-bxslider-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/css/jquery.bxslider.min.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='augury-custom-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/css/blog-single.css?ver=2.3' type='text/css' media='all' />
<style id='augury-custom-inline-css' type='text/css'>
.dt-sc-menu-sorting a { color: rgba(255,255,255, 0.6) }
.portfolio .image-overlay, .recent-portfolio-widget ul li a:before { background: rgba(255,255,255, 0.9) }
.dt-sc-boxed-style.dt-sc-post-entry .blog-entry.sticky, .dt-sc-post-entry.entry-cover-layout .blog-entry.sticky  { box-shadow: inset 0 0 1px 3px #ffffff}
.apply-no-space .dt-sc-boxed-style.dt-sc-post-entry .blog-entry.sticky, .apply-no-space .dt-sc-post-entry.entry-cover-layout .blog-entry.sticky { box-shadow: inset 0 0 1px 3px #ffffff}
.dt-related-carousel div[class*="carousel-"] > div { box-shadow: 0 0 1px 1px #ffffff}
.dt-sc-content-overlay-style.dt-sc-post-entry.entry-grid-layout .blog-entry.sticky .entry-thumb { box-shadow: 0 -3px 0 0 #ffffff}
.dt-sc-modern-style.dt-sc-post-entry .blog-entry:hover { box-shadow: 0 5px 0 0 #ffffff}
.dt-sc-grungy-boxed-style.dt-sc-post-entry .blog-entry:before, .dt-sc-title-overlap-style.dt-sc-post-entry .blog-entry:before { box-shadow: inset 0 0 0 1px #ffffff}
.portfolio.type4 .image-overlay, .dt-sc-event-addon > .dt-sc-event-addon-date, .dt-sc-course .dt-sc-course-overlay, .dt-sc-process-steps .dt-sc-process-thumb-overlay { background: rgba(255,255,255,0.85) }
.dt-sc-product-image-360-popup-viewer-holder .dt-sc-product-image-360-viewer-enlarger { background-color: rgba(255,255,255, 0.75) }
.dt-sc-product-image-gallery-container .dt-sc-product-image-gallery-thumb-enlarger { background-color: rgba(255,255,255, 0.95) }
.woocommerce ul.products.product-border-type-default.product-border-position-left.product-bordershadow-highlight-default li.product .product-wrapper,
			.woocommerce ul.products.product-border-type-thumb.product-border-position-left.product-bordershadow-highlight-default li.product .product-thumb,

			.woocommerce ul.products.product-border-type-default.product-border-position-left.product-bordershadow-highlight-onhover li.product:hover .product-wrapper,
			.woocommerce ul.products.product-border-type-thumb.product-border-position-left.product-bordershadow-highlight-onhover li.product:hover .product-thumb { -webkit-box-shadow: -4px 0 0 0 #ffffff; box-shadow: -4px 0 0 0 #ffffff; }
.woocommerce ul.products.product-border-type-default.product-border-position-right.product-bordershadow-highlight-default li.product .product-wrapper,
			.woocommerce ul.products.product-border-type-thumb.product-border-position-right.product-bordershadow-highlight-default li.product .product-thumb,

			.woocommerce ul.products.product-border-type-default.product-border-position-right.product-bordershadow-highlight-onhover li.product:hover .product-wrapper,
			.woocommerce ul.products.product-border-type-thumb.product-border-position-right.product-bordershadow-highlight-onhover li.product:hover .product-thumb { -webkit-box-shadow: 4px 0 0 0 #ffffff; box-shadow: 4px 0 0 0 #ffffff; }
.woocommerce ul.products.product-border-type-default.product-border-position-top.product-bordershadow-highlight-default li.product .product-wrapper,
			.woocommerce ul.products.product-border-type-thumb.product-border-position-top.product-bordershadow-highlight-default li.product .product-thumb,

			.woocommerce ul.products.product-border-type-default.product-border-position-top.product-bordershadow-highlight-onhover li.product:hover .product-wrapper,
			.woocommerce ul.products.product-border-type-thumb.product-border-position-top.product-bordershadow-highlight-onhover li.product:hover .product-thumb { -webkit-box-shadow: 0 -4px 0 0 #ffffff; box-shadow: 0 -4px 0 0 #ffffff; }
.woocommerce ul.products.product-border-type-default.product-border-position-bottom.product-bordershadow-highlight-default li.product .product-wrapper,
			.woocommerce ul.products.product-border-type-thumb.product-border-position-bottom.product-bordershadow-highlight-default li.product .product-thumb,

			.woocommerce ul.products.product-border-type-default.product-border-position-bottom.product-bordershadow-highlight-onhover li.product:hover .product-wrapper,
			.woocommerce ul.products.product-border-type-thumb.product-border-position-bottom.product-bordershadow-highlight-onhover li.product:hover .product-thumb { -webkit-box-shadow: 0 4px 0 0 #ffffff; box-shadow: 0 4px 0 0 #ffffff; }
.woocommerce ul.products.product-border-type-default.product-border-position-top-left.product-bordershadow-highlight-default li.product .product-wrapper,
			.woocommerce ul.products.product-border-type-thumb.product-border-position-top-left.product-bordershadow-highlight-default li.product .product-thumb,

			.woocommerce ul.products.product-border-type-default.product-border-position-top-left.product-bordershadow-highlight-onhover li.product:hover .product-wrapper,
			.woocommerce ul.products.product-border-type-thumb.product-border-position-top-left.product-bordershadow-highlight-onhover li.product:hover .product-thumb { -webkit-box-shadow: -4px -4px 0 0 #ffffff; box-shadow: -4px -4px 0 0 #ffffff; }
.woocommerce ul.products.product-border-type-default.product-border-position-top-right.product-bordershadow-highlight-default li.product .product-wrapper,
			.woocommerce ul.products.product-border-type-thumb.product-border-position-top-right.product-bordershadow-highlight-default li.product .product-thumb,

			.woocommerce ul.products.product-border-type-default.product-border-position-top-right.product-bordershadow-highlight-onhover li.product:hover .product-wrapper,
			.woocommerce ul.products.product-border-type-thumb.product-border-position-top-right.product-bordershadow-highlight-onhover li.product:hover .product-thumb { -webkit-box-shadow: 4px -4px 0 0 #ffffff; box-shadow: 4px -4px 0 0 #ffffff; }
.woocommerce ul.products.product-border-type-default.product-border-position-bottom-left.product-bordershadow-highlight-default li.product .product-wrapper,
			.woocommerce ul.products.product-border-type-thumb.product-border-position-bottom-left.product-bordershadow-highlight-default li.product .product-thumb,

			.woocommerce ul.products.product-border-type-default.product-border-position-bottom-left.product-bordershadow-highlight-onhover li.product:hover .product-wrapper,
			.woocommerce ul.products.product-border-type-thumb.product-border-position-bottom-left.product-bordershadow-highlight-onhover li.product:hover .product-thumb { -webkit-box-shadow: -4px 4px 0 0 #ffffff; box-shadow: -4px 4px 0 0 #ffffff; }
.woocommerce ul.products.product-border-type-default.product-border-position-bottom-right.product-bordershadow-highlight-default li.product .product-wrapper,
			.woocommerce ul.products.product-border-type-thumb.product-border-position-bottom-right.product-bordershadow-highlight-default li.product .product-thumb,

			.woocommerce ul.products.product-border-type-default.product-border-position-bottom-right.product-bordershadow-highlight-onhover li.product:hover .product-wrapper,
			.woocommerce ul.products.product-border-type-thumb.product-border-position-bottom-right.product-bordershadow-highlight-onhover li.product:hover .product-thumb { -webkit-box-shadow: 4px 4px 0 0 #ffffff; box-shadow: 4px 4px 0 0 #ffffff; }
.woocommerce ul.products.product-shadow-type-default.product-shadow-position-default.product-bordershadow-highlight-default li.product .product-wrapper,
			.woocommerce ul.products.product-shadow-type-thumb.product-shadow-position-default.product-bordershadow-highlight-default li.product .product-wrapper .product-thumb,

			.woocommerce ul.products.product-shadow-type-default.product-shadow-position-default.product-bordershadow-highlight-onhover li.product:hover .product-wrapper,
			.woocommerce ul.products.product-shadow-type-thumb.product-shadow-position-default.product-bordershadow-highlight-onhover li.product:hover .product-wrapper .product-thumb { -webkit-box-shadow: 0 0 5px 1px #ffffff; box-shadow: 0 0 5px 1px #ffffff; }
.woocommerce ul.products.product-shadow-type-default.product-shadow-position-top-left.product-bordershadow-highlight-default li.product .product-wrapper,
			.woocommerce ul.products.product-shadow-type-thumb.product-shadow-position-top-left.product-bordershadow-highlight-default li.product .product-thumb,

			.woocommerce ul.products.product-shadow-type-default.product-shadow-position-top-left.product-bordershadow-highlight-onhover li.product:hover .product-wrapper,
			.woocommerce ul.products.product-shadow-type-thumb.product-shadow-position-top-left.product-bordershadow-highlight-onhover li.product:hover .product-thumb { -webkit-box-shadow: -5px -5px 5px 0 #ffffff; box-shadow: -5px -5px 5px 0 #ffffff; }
.woocommerce ul.products.product-shadow-type-default.product-shadow-position-top-right.product-bordershadow-highlight-default li.product .product-wrapper,
			.woocommerce ul.products.product-shadow-type-thumb.product-shadow-position-top-right.product-bordershadow-highlight-default li.product .product-thumb,

			.woocommerce ul.products.product-shadow-type-default.product-shadow-position-top-right.product-bordershadow-highlight-onhover li.product:hover .product-wrapper,
			.woocommerce ul.products.product-shadow-type-thumb.product-shadow-position-top-right.product-bordershadow-highlight-onhover li.product:hover .product-thumb { -webkit-box-shadow: 5px -5px 5px 0 #ffffff; box-shadow: 5px -5px 5px 0 #ffffff; }
.woocommerce ul.products.product-shadow-type-default.product-shadow-position-bottom-left.product-bordershadow-highlight-default li.product .product-wrapper,
			.woocommerce ul.products.product-shadow-type-thumb.product-shadow-position-bottom-left.product-bordershadow-highlight-default li.product .product-thumb,

			.woocommerce ul.products.product-shadow-type-default.product-shadow-position-bottom-left.product-bordershadow-highlight-onhover li.product:hover .product-wrapper,
			.woocommerce ul.products.product-shadow-type-thumb.product-shadow-position-bottom-left.product-bordershadow-highlight-onhover li.product:hover .product-thumb { -webkit-box-shadow: -5px 5px 5px 0 #ffffff; box-shadow: -5px 5px 5px 0 #ffffff; }
.woocommerce ul.products.product-shadow-type-default.product-shadow-position-bottom-right.product-bordershadow-highlight-default li.product .product-wrapper,
			.woocommerce ul.products.product-shadow-type-thumb.product-shadow-position-bottom-right.product-bordershadow-highlight-default li.product .product-thumb,

			.woocommerce ul.products.product-shadow-type-default.product-shadow-position-bottom-right.product-bordershadow-highlight-onhover li.product:hover .product-wrapper,
			.woocommerce ul.products.product-shadow-type-thumb.product-shadow-position-bottom-right.product-bordershadow-highlight-onhover li.product:hover .product-thumb { -webkit-box-shadow: 5px 5px 5px 0 #ffffff; box-shadow: 5px 5px 5px 0 #ffffff; }
.dt-sc-event-month-thumb .dt-sc-event-read-more, .dt-sc-training-thumb-overlay { background: rgba(255,163,90,0.85) }
.dt-sc-faculty .dt-sc-faculty-thumb-overlay { background: rgba(255,255,255,0.9) }
@-webkit-keyframes color-change { 0% { color:#ffffff; } 50% { color:#ffa35a; }  100% { color:#ffffff; } }
@-moz-keyframes color-change { 0% { color:#ffffff; } 50% { color:#ffa35a; } 100% { color:#ffffff; } }
@-ms-keyframes color-change { 0% { color:#ffffff; } 50% { color:#ffa35a; } 100% { color:#ffffff; }	}
@-o-keyframes color-change { 0% { color:#ffffff; } 50% { color:#ffa35a; } 100% { color:#ffffff; }	}
@keyframes color-change { 0% { color:#ffffff; } 50% { color:#ffa35a; } 100% { color:#ffffff; }	}
.dt-sc-destination-item .image-overlay:before { background: linear-gradient(to right,rgba(255,163,90, 0.9) 0%, rgba(255,255,255, 0.9) 100%); background: -webkit-linear-gradient(to right,rgba(255,163,90, 0.9) 0%, rgba(255,255,255, 0.9) 100%); background: -moz-linear-gradient(to right,rgba(255,163,90, 0.9) 0%, rgba(255,255,255, 0.9) 100%); background: -ms-linear-gradient(to right,rgba(255,163,90, 0.9) 0%, rgba(255,255,255, 0.9) 100%); }

</style>
<link rel='stylesheet' id='augury-gutenberg-css' href='https://dtaugury.wpengine.com/wp-content/themes/augury/css/gutenberg.css?ver=2.3' type='text/css' media='all' />
<style id='augury-gutenberg-inline-css' type='text/css'>
.has-primary-background-color { background-color:#ffffff; }.has-primary-color { color:#ffffff; }.has-secondary-background-color { background-color:#ffa35a; }.has-secondary-color { color:#ffa35a; }.has-tertiary-background-color { background-color:#ffffff; }.has-tertiary-color { color:#ffffff; }
</style>
<link rel='stylesheet' id='dt_booking-default-css' href='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-booking-manager/css/default.css?ver=6.3' type='text/css' media='all' />
<link rel='stylesheet' id='dtportfolio-designthemes-css' href='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-portfolio-addon/css/designthemes.css?ver=6.3' type='text/css' media='all' />
<style id='augury-customiser-skin-inline-inline-css' type='text/css'>
a, h1 a:hover, h2 a:hover, h3 a:hover, h4 a:hover, h5 a:hover, h6 a:hover, .breadcrumb a:hover { color:#ffffff; }.widget #wp-calendar td a:hover, .dt-sc-dark-bg .widget #wp-calendar td a:hover, .secondary-sidebar .widget ul li > a:hover, .secondary-sidebar .type15 .widget.widget_recent_reviews ul li .reviewer, .secondary-sidebar .type15 .widget.widget_top_rated_products ul li .amount.amount,

				#main-menu .menu-item-widget-area-container .widget ul li > a:hover, #main-menu .dt-sc-dark-bg .menu-item-widget-area-container .widget ul li > a:hover, #main-menu .dt-sc-dark-bg .menu-item-widget-area-container .widget_recent_posts .entry-title h4 a:hover, #main-menu ul li.menu-item-simple-parent.dt-sc-dark-bg ul li a:hover, #main-menu .menu-item-widget-area-container .widget li:hover:before, .widget .recent-posts-widget li .entry-meta p span { color:#ffffff; }.intro-section .elementor-column-wrap.elementor-element-populated:hover .elementor-widget-button a.elementor-button, /*#searchform:hover:before, */ .elementor-widget-jet-map .gm-style .gm-style-iw-d span, .contact-info a:hover, .elementor-widget-icon-list .elementor-icon-list-text:hover, .services-provided .elementor-column-wrap:hover .elementor-widget-heading.elementor-widget-heading h2.elementor-heading-title, #footer .footer-social .elementor-social-icon:hover i, .dt-sc-simple-style.dt-sc-post-entry .blog-entry:hover .entry-button a.dt-sc-button span, .dtportfolio-sorting a:hover, .dtportfolio-sorting a.active-sort, .post-nav-container .post-next-link a:hover, .post-nav-container .post-prev-link a:hover, .post-nav-container .post-archive-link-wrapper a:hover, article.blog-single-entry.post-overlay > .entry-categories > a:hover, .dt-elementor-ordered-list-items .dt-elementor-ordered-list-item:before, .dt-sc-header-icons-list > div.loginlogout-item a span i { color:#ffffff; }.elementor-jet-pricing-table .pricing-table:hover .pricing-table__icon-box > * svg, .footer .elementor-jet-pricing-table .pricing-table:hover .pricing-table__icon-box > * svg { fill:#ffffff; }.ico-hover-bg.elementor-widget-icon-box.elementor-view-stacked:hover .elementor-icon, .elementor-widget-icon-box.elementor-view-stacked.ico-type1.alter:hover .elementor-icon, .woocommerce nav.woocommerce-pagination ul li a:focus, .woocommerce nav.woocommerce-pagination ul li a:hover, .woocommerce nav.woocommerce-pagination ul li span.current, .woocommerce nav.woocommerce-pagination ul li .page-numbers.dots, #main .white .elementor-button:hover, .elementor-widget-image-box.ico-type1.alter:hover .elementor-image-box-img,

				.woocommerce .product-loop-sorting .product-display-controller .product-change-display li span, .woocommerce .product-loop-sorting .product-layout-controller .product-change-layout li span, .woocommerce .product-loop-sorting .product-list-options-controller .product-list-options li span { background-color:#ffffff; }.dt-sc-post-entry .blog-entry a, .dt-sc-post-entry .blog-entry .entry-title h4 a:hover, .dt-sc-post-entry.entry-cover-layout .blog-entry .entry-title h4 a:hover, .dt-sc-post-entry.entry-cover-layout .blog-entry .entry-button a.dt-sc-button:hover, .dt-sc-post-entry.entry-cover-layout .blog-entry:after, .dt-sc-boxed-style.dt-sc-post-entry .blog-entry > div.entry-meta-group .div:not(.entry-social-share) i, .dt-sc-post-entry.entry-cover-layout .blog-entry .entry-format a:after, .dt-sc-content-overlay-style.dt-sc-post-entry .blog-entry.type-post .entry-format a:hover, .dt-sc-content-overlay-style.dt-sc-post-entry .blog-entry div.entry-tags a, .dt-sc-content-overlay-style.dt-sc-post-entry .blog-entry > div.entry-date i, .dt-sc-post-entry.entry-cover-layout .blog-entry > div.entry-format a:hover, .dt-sc-simple-withbg-style.dt-sc-post-entry .blog-entry .entry-social-share .share > i, .dt-sc-simple-withbg-style.dt-sc-post-entry .blog-entry .entry-button a.dt-sc-button, .dt-sc-simple-withbg-style.dt-sc-post-entry .blog-entry .entry-format a, .dt-sc-trendy-style.dt-sc-post-entry.entry-cover-layout .blog-entry .entry-details a, .dt-sc-trendy-style.dt-sc-post-entry.entry-cover-layout .blog-entry > div a, .dt-sc-trendy-style.dt-sc-post-entry.entry-cover-layout .blog-entry > div.entry-button a:hover, .dt-sc-mobilephone-style.dt-sc-post-entry.entry-cover-layout:hover .blog-entry .entry-title h4 a:hover, .dt-sc-mobilephone-style.dt-sc-post-entry.entry-cover-layout:hover .blog-entry:before, .dt-sc-mobilephone-style.dt-sc-post-entry.entry-cover-layout .blog-entry.sticky:before, .pagination ul li a, .dt-sc-alternate-style.dt-sc-post-entry:hover .blog-entry .entry-format a:before, .dt-sc-simple-withbg-style.dt-sc-post-entry .blog-entry .entry-title h4 span.sticky-post, .dt-sc-simple-withbg-style.dt-sc-post-entry .blog-entry .entry-title h4 span.sticky-post i, .dt-sc-classic-overlay-style.dt-sc-post-entry.entry-grid-layout .blog-entry > .entry-tags > a,    .dt-sc-classic-overlay-style.dt-sc-post-entry.entry-grid-layout .blog-entry.sticky .entry-thumb .entry-format a:before, .dt-sc-classic-overlay-style.dt-sc-post-entry .blog-entry .entry-thumb:first-child + .entry-meta-group > div > a:hover, /*.blog-single-entry.post-custom-minimal div[class*="metagroup-"]:not(.metagroup-elements-boxed) div[class*="entry-"] a:hover, */ .dt-sc-grungy-boxed-style.dt-sc-post-entry .blog-entry.has-post-thumbnail > div.entry-thumb + div.entry-comments a:hover, .dt-sc-grungy-boxed-style.dt-sc-post-entry .blog-entry.has-post-thumbnail > div.entry-thumb + div.entry-likes-views a:hover, .dt-sc-grungy-boxed-style.dt-sc-post-entry .blog-entry:not(.has-post-thumbnail) > div.entry-comments:first-child a:hover, .dt-sc-grungy-boxed-style.dt-sc-post-entry .blog-entry:not(.has-post-thumbnail) > div.entry-likes-views:first-child a:hover, .commentlist li.comment .reply a,.blog-single-entry .related-article .content > span, .blog-single-entry .related-article article .entry-summary h2, .blog-single-entry.post-overlay > .entry-thumb > .entry-format > a:hover,.blog-single-entry.post-overlay > .entry-author span:hover,.blog-single-entry.post-overlay > .entry-author span:hover a,.blog-single-entry.post-overlay > .entry-categories a, .blog-single-entry.post-overlay > .entry-title h1:hover a,.blog-single-entry.post-overlay > .entry-tags a:hover,.blog-single-entry.post-overlay > .entry-comments a:hover,.blog-single-entry.post-overlay > .entry-likes-views .dt-sc-like-views a:hover,.blog-single-entry.post-overlay > .entry-social-share .share .dt-share-list li a:hover,.blog-single-entry.post-overlay > .entry-author-bio .details h3 a:hover,.blog-single-entry.post-overlay > .entry-post-navigation .post-prev-link:hover p,.blog-single-entry.post-overlay > .entry-post-navigation .post-next-link:hover p,.blog-single-entry.post-overlay > .entry-post-navigation .post-prev-link:hover span,.blog-single-entry.post-overlay > .entry-post-navigation .post-next-link:hover span,.blog-single-entry.post-overlay > div.entry-meta-group .share .dt-share-list li a:hover,.blog-single-entry.post-overlay > div.entry-meta-group .entry-categories a:hover,.blog-single-entry.post-overlay > div.entry-meta-group .entry-author span:hover, .blog-single-entry.post-overlay > div.entry-meta-group .entry-author span:hover a,.blog-single-entry.post-overlap > .entry-thumb .entry-overlap .entry-bottom-details > * a:hover,.blog-single-entry.post-overlap > .entry-author-bio > .details h3 a:hover,.blog-single-entry.post-breadcrumb-fixed > .dt-post-sticky-wrapper h4 > span,.blog-single-entry.post-overlap > .commententries #respond h3#reply-title small a:hover,.blog-single-entry.post-breadcrumb-fixed .entry-author-bio > .details h3 a:hover,.blog-single-entry.post-breadcrumb-parallax > .entry-tags a:hover, .blog-single-entry.post-breadcrumb-parallax > .entry-categories a:hover,.blog-single-entry.post-breadcrumb-parallax > .entry-comments a:hover,.blog-single-entry.post-breadcrumb-parallax > .entry-author a:hover,.blog-single-entry.post-breadcrumb-parallax > .entry-likes-views .dt-sc-like-views a:hover,.blog-single-entry.post-breadcrumb-parallax > .entry-social-share .share .dt-share-list li a:hover, .blog-single-entry.post-custom-classic div[class*="meta-elements-boxed"]:hover i, .blog-single-entry.post-custom-classic div[class*="meta-elements-boxed"] a:hover, .blog-single-entry[class*="post-custom-classic"] .entry-author-bio .details h3 span, .blog-single-entry[class*="post-custom-classic"] .entry-post-navigation > div > .nav-title-wrap h3 a:hover, div[class*="metagroup-"] div[class*="entry-"] a, div[class*="meta-elements"] a, .blog-single-entry.post-custom-classic div[class*="metagroup-"] div[class*="entry-"] a:hover, .page-link a, .page-link a > span, .blog-single-entry.post-breadcrumb-parallax > .entry-meta-group > div a:hover, .dt-sc-post-entry .blog-entry .entry-format a.ico-format:hover, .blog-single-entry.post-overlay > .entry-title h1 a, .blog-single-entry.post-overlay > .entry-author-bio .details h3 a,.blog-single-entry.post-overlap > .entry-thumb .entry-overlap .entry-title h1 a, .blog-single-entry.post-overlap > .entry-thumb .entry-overlap .entry-bottom-details > * i,.blog-single-entry.post-overlap > .entry-thumb .entry-overlap .entry-bottom-details > * a, .blog-single-entry.post-overlap > .entry-tags a,.blog-single-entry.post-overlap > .entry-social-share .share .dt-share-list li a,.blog-single-entry.post-overlap > .entry-likes-views .dt-sc-like-views > div > a,.blog-single-entry.post-overlap > .entry-categories a,.blog-single-entry.post-overlap .entry-author > .author-wrap > a,.blog-single-entry.post-overlap > div.entry-meta-group .entry-tags a, .blog-single-entry.post-overlap > div.entry-meta-group .share .dt-share-list li a,.blog-single-entry.post-overlap > div.entry-meta-group .entry-likes-views .dt-sc-like-views > div > a,.blog-single-entry.post-overlap > div.entry-meta-group > .entry-categories a,.blog-single-entry.post-overlap > div.entry-meta-group > .entry-author > .author-wrap > a,.blog-single-entry.post-overlap > .entry-author-bio > .details h3 > a,.blog-single-entry.post-overlap > .entry-title h1 a,.blog-single-entry.post-overlap > .commententries #respond h3#reply-title small a,.single-post-header-wrapper > .container h1, .blog-single-entry.post-breadcrumb-fixed .entry-author-bio > .details h3 a,.blog-single-entry.post-breadcrumb-fixed .entry-title h1 a,.blog-single-entry.post-breadcrumb-fixed .entry-related-posts > h4,.blog-single-entry.post-breadcrumb-fixed .commententries .comments-area > h3,.blog-single-entry.post-breadcrumb-fixed .commententries #respond h3#reply-title, .blog-single-entry.post-breadcrumb-fixed .commententries #respond h3#reply-title small a,.blog-single-entry.post-breadcrumb-fixed .entry-comments a,.blog-single-entry.post-breadcrumb-fixed div.entry-meta-group .entry-tags a:hover,.blog-single-entry.post-breadcrumb-fixed div.entry-meta-group > .entry-categories > .category-wrap > a:hover, .blog-single-entry.post-breadcrumb-fixed div.entry-meta-group .share .dt-share-list li a:hover,.blog-single-entry.post-breadcrumb-fixed div.entry-meta-group .entry-date .date-wrap i,.blog-single-entry.post-breadcrumb-fixed div.entry-meta-group .entry-author i,.blog-single-entry.post-breadcrumb-fixed div.entry-meta-group .entry-comments i, .blog-single-entry.post-breadcrumb-fixed div.entry-meta-group .entry-likes-views .dt-sc-like-views > div > i,.blog-single-entry.post-breadcrumb-fixed .entry-tags a,.blog-single-entry.post-breadcrumb-fixed .entry-categories > .category-wrap > a, .blog-single-entry.post-breadcrumb-fixed .entry-social-share .share .dt-share-list li a,.blog-single-entry.post-breadcrumb-fixed .entry-date .date-wrap,.blog-single-entry.post-breadcrumb-fixed .entry-author > .author-wrap > a,.blog-single-entry.post-breadcrumb-fixed .entry-likes-views .dt-sc-like-views > div > a,.single-post-header-wrapper.dt-parallax-bg > .container .post-meta .post-author a:hover,.single-post-header-wrapper.dt-parallax-bg > .container .post-meta > .post-comments a:hover,.blog-single-entry.post-breadcrumb-parallax > .entry-title h1 a,.blog-single-entry.post-breadcrumb-parallax >.entry-tags a,.blog-single-entry.post-breadcrumb-parallax > .entry-categories a,.blog-single-entry.post-breadcrumb-parallax > .entry-comments a,.blog-single-entry.post-breadcrumb-parallax > .entry-author a,.blog-single-entry.post-breadcrumb-parallax > .entry-likes-views .dt-sc-like-views a,.blog-single-entry.post-breadcrumb-parallax > .entry-social-share .share .dt-share-list li a,.blog-single-entry.post-breadcrumb-parallax > [class*="entry-"] > i,.blog-single-entry.post-breadcrumb-parallax > .entry-tags a:not(:last-child):after,.blog-single-entry.post-breadcrumb-parallax > .entry-categories a:not(:last-child):after,.blog-single-entry.post-breadcrumb-parallax > .entry-author, .blog-single-entry.post-breadcrumb-parallax > .entry-date,.blog-single-entry.post-breadcrumb-parallax > .entry-author-bio .details h3 a, .blog-single-entry.post-custom-classic .entry-title h1 a, .blog-single-entry.post-overlap > div.entry-meta-group .entry-date .date-wrap, .blog-single-entry.post-overlap > .entry-date .date-wrap, .blog-single-entry.post-overlap > div.entry-meta-group .entry-comments a, .blog-single-entry.post-overlap > .entry-comments a, .blog-single-entry.post-overlap > div.entry-meta-group .entry-likes-views .dt-sc-like-views > div, .single-post-header-wrapper > .container .post-meta-data .date, .blog-single-entry.post-breadcrumb-fixed > .dt-post-sticky-wrapper h4, .blog-single-entry.post-breadcrumb-fixed div[class*="metagroup-elements-boxed"].dt-sc-posts-meta-group .entry-likes-views:hover .dt-sc-like-views > div i, .blog-single-entry.post-breadcrumb-fixed div[class*="metagroup-elements-filled"].dt-sc-posts-meta-group .entry-likes-views:hover .dt-sc-like-views > div i:before, .elementor-button.dt-elementor-button.dt-bordered, .post-custom-modern .entry-post-navigation > div:hover div.nav-title-wrap h3 a, .blog-single-entry.post-breadcrumb-parallax .entry-post-navigation > .post-prev-link .nav-title-wrap h3 a:hover, .wp-block-image figcaption { color:#ffffff; }.portfolio .image-overlay .links a:hover, .portfolio.type7 .image-overlay .links a, .project-details li a:hover, .portfolio-categories a:hover, .dt-portfolio-single-slider-wrapper #bx-pager a.active:hover:before, .dt-portfolio-single-slider-wrapper #bx-pager a, .portfolio.type8 .image-overlay .links a { color:#ffffff; }.dt-skin-primary-color, ul.side-nav li a:hover, .dt-sc-events-list .dt-sc-event-title h5 a, .woocommerce-MyAccount-navigation ul > li.is-active > a, .side-navigation.type5 ul.side-nav li.current_page_item a, .side-navigation.type5 ul.side-nav>li>a:hover, .carousel-arrows a:hover:before,

				.dt-sc-counter-wrapper.type2 .dt-sc-counter-inner .dt-sc-counter-icon-wrapper > *, .elementor-widget-tabs.elementor-tabs-view-vertical.dt-vertical-bordered .elementor-tabs-wrapper .elementor-tab-title a:hover, .elementor-widget-tabs.elementor-tabs-view-vertical.dt-vertical-bordered .elementor-tabs-wrapper .elementor-tab-title.elementor-active a, .elementor-element.elementor-widget-image-box:hover .elementor-image-box-wrapper .elementor-image-box-content .elementor-image-box-description, .elementor-element .elementor-jet-pricing-table .pricing-table:hover .pricing-table__subtitle, .elementor-element .elementor-jet-pricing-table .pricing-table:hover span.pricing-table__price-val, .elementor-element .elementor-jet-pricing-table .pricing-table:hover span.pricing-table__price-prefix { color:#ffffff; }ul.dt-sc-tabs-vertical-frame > li > a:hover, ul.dt-sc-tabs-vertical-frame > li.current a, ul.dt-sc-tabs-vertical > li > a.current, .dt-sc-tabs-vertical-frame-container.type2 ul.dt-sc-tabs-vertical-frame > li > a.current:before, ul.dt-sc-tabs-vertical > li > a:hover, .dt-sc-tabs-vertical-frame-container.type4 ul.dt-sc-tabs-vertical-frame > li > a.current, .dt-sc-tabs-vertical-frame-container.type4 ul.dt-sc-tabs-vertical-frame > li > a:hover { color:#ffffff; }.dt-sc-event-image-caption .dt-sc-image-content h3 { color:#ffffff; }.page-template-default .blog-single-entry table thead, .post-template-default .blog-single-entry table thead, table:not(.shop_attributes) > tbody:first-child > tr > th, th { background-color:#ffffff; }#footer .wpcf7-form.bottom-bordered input[type="submit"]:hover, #footer .wpcf7-form.bottom-bordered button:hover, #footer .wpcf7-form.bottom-bordered input[type="button"]:hover, #footer .wpcf7-form.bottom-bordered input[type="reset"]:hover { background-color:#ffffff; }.tagcloud a:hover, .widgettitle:before, .dt-sc-dark-bg .tagcloud a:hover, .dt-sc-dark-bg .widget.widget_categories ul li > a:hover span, #footer .dt-sc-dark-bg .widget.widget_categories ul li > a:hover span, #footer .dt-sc-dark-bg .widget.widget_archive ul li > a:hover span { background-color:#ffffff; }.blog-entry .entry-title h4 span.sticky-post, .blog-entry .entry-social-share .share > i, .dt-sc-post-entry .blog-entry .entry-button a.dt-sc-button, .dt-sc-post-entry.entry-cover-layout .blog-entry .entry-social-share .share > i, .dt-sc-post-entry .blog-entry .entry-format a, .dt-sc-simple-style.dt-sc-post-entry .blog-entry .entry-format a:hover, .dt-sc-content-overlay-style.dt-sc-post-entry .blog-entry div.entry-categories a, .dt-sc-content-overlay-style.dt-sc-post-entry .blog-entry > div.entry-tags a:hover, .dt-sc-content-overlay-style.dt-sc-post-entry .blog-entry > div.entry-author > a:hover, .dt-sc-content-overlay-style.dt-sc-post-entry .blog-entry div.entry-comments > a:hover, .dt-sc-content-overlay-style.dt-sc-post-entry .blog-entry div.entry-tags a:hover, .dt-sc-simple-withbg-style.dt-sc-post-entry .blog-entry, .dt-sc-simple-withbg-style.dt-sc-post-entry .blog-entry .entry-format a:hover, .dt-sc-simple-withbg-style.dt-sc-post-entry .blog-entry.sticky .entry-format a, .dt-sc-simple-withbg-style.dt-sc-post-entry.entry-grid-layout .blog-entry .entry-thumb .bx-wrapper, .dt-sc-mobilephone-style.dt-sc-post-entry.entry-cover-layout:hover .blog-entry div.entry-format a, .dt-sc-mobilephone-style.dt-sc-post-entry.entry-cover-layout .blog-entry.sticky div.entry-format a, .pagination .newer-posts a, .pagination .older-posts a, .pagination ul li span, .pagination ul li a:hover, .pagination a.loadmore-btn,  .dt-sc-alternate-style.dt-sc-post-entry:hover .entry-title h4 a:before, .dt-sc-alternate-style.dt-sc-post-entry .blog-entry .entry-format a:after, .dt-sc-content-overlay-style.dt-sc-post-entry .blog-entry div.entry-author a:hover, .dt-sc-classic-overlay-style.dt-sc-post-entry .blog-entry > .entry-categories > a:hover, .dt-sc-overlap-style.dt-sc-post-entry .blog-entry .entry-format a:after, .dt-related-carousel div[class*="carousel-"] > div, .dt-related-carousel .carousel-pager > a.selected, .dt-related-carousel .carousel-pager > a:hover, .dt-sc-overlay-iii-style.dt-sc-post-entry.entry-list-layout .blog-entry > .entry-thumb:before, .dt-sc-modern-style.dt-sc-post-entry .blog-entry .entry-meta-group div.entry-tags a, .dt-sc-overlay-style.dt-sc-post-entry.entry-cover-layout .blog-entry .entry-details > .entry-tags, .dt-sc-minimal-style.dt-sc-post-entry.entry-grid-layout .blog-entry:after, .dt-sc-title-overlap-style.dt-sc-post-entry .blog-entry.sticky > div.entry-title:before, .dt-sc-title-overlap-style.dt-sc-post-entry .blog-entry:hover > div.entry-title:before, .post-edit-link:hover, .vc_inline-link:hover,ul.commentlist li .reply a:hover,.single-post-header-wrapper > .container .post-categories a, .blog-single-entry .related-article .arrow, .blog-single-entry.post-overlay > .entry-thumb > .entry-format > a,.blog-single-entry.post-overlay > .entry-thumb .share .dt-share-list li a:hover,.blog-single-entry.post-overlay:hover > .entry-title h1:before,.blog-single-entry.post-overlay > .entry-author span,.blog-single-entry.post-overlap > .entry-thumb > .entry-format > a,.blog-single-entry.post-overlap > .entry-comments a:hover i,.blog-single-entry.post-overlap > .entry-author > .author-wrap:hover i,.blog-single-entry.post-overlap > .entry-date > .date-wrap:hover i,.blog-single-entry.post-overlap > .entry-categories > .category-wrap:hover i,.blog-single-entry.post-overlap > .entry-likes-views .dt-sc-like-views > div:hover > i,.blog-single-entry.post-overlay > div.entry-meta-group .entry-author span,.blog-single-entry.post-overlap > div.entry-meta-group .entry-comments a:hover i,.blog-single-entry.post-overlap > div.entry-meta-group .entry-author > .author-wrap:hover i,.blog-single-entry.post-overlap > div.entry-meta-group .entry-date > .date-wrap:hover i,.blog-single-entry.post-overlap > div.entry-meta-group > .entry-categories > .category-wrap:hover i,.blog-single-entry.post-overlap > div.entry-meta-group .entry-likes-views .dt-sc-like-views > div:hover > i,.blog-single-entry.post-breadcrumb-fixed > .dt-post-sticky-wrapper .entry-social-share .share ul li:hover,.blog-single-entry.post-breadcrumb-fixed > .column .commententries #respond h3#reply-title small a:hover,.blog-single-entry.post-breadcrumb-fixed div.entry-meta-group .entry-comments a:hover i,.blog-single-entry.post-breadcrumb-fixed div.entry-meta-group .entry-author > .author-wrap:hover i,.blog-single-entry.post-breadcrumb-fixed div.entry-meta-group .entry-likes-views .dt-sc-like-views > div:hover > i,.blog-single-entry.post-breadcrumb-fixed div.entry-meta-group .entry-date .date-wrap:hover i,.blog-single-entry.post-breadcrumb-fixed .entry-comments a:hover i,.blog-single-entry.post-breadcrumb-fixed .entry-author > .author-wrap:hover i,.blog-single-entry.post-breadcrumb-fixed .entry-likes-views .dt-sc-like-views > div:hover > i,.blog-single-entry.post-breadcrumb-fixed .entry-date .date-wrap:hover i,.single-post-header-wrapper.dt-parallax-bg > .container .post-categories a:hover,.blog-single-entry.post-breadcrumb-parallax > .entry-thumb > .entry-format > a, .blog-single-entry.post-custom-classic div[class*="entry-format"] a, div[class*="metagroup-elements-filled"] div[class*="entry-"], div[class*="meta-elements-filled"], div[class*="metagroup-elements-boxed"] div[class*="entry-"]:hover, div[class*="metagroup-elements-filled"] div[class*="entry-social"]:hover .share > i, div[class*="meta-elements-boxed"]:hover, .blog-single-entry div[class*="meta-elements-filled"]:hover .share > i, .post-custom-modern div.nav-title-wrap > span, .page-link > span, .page-link > a:hover, div[class*="meta-elements"].entry-social-share .share:hover > i, .blog-single-entry .entry-format a, .blog-single-entry div[class*="meta-elements-filled"]:hover,.metagroup-dot-separator div[class*="entry-"]:not(:last-child):before,.post-default>div[class*="entry-meta-group"] div[class*=entry-]:hover,div[class*="metagroup-"] .entry-social-share .share>i,div[class*="metagroup-elements-filled"] div[class*=entry-]:hover,div[class*="metagroup-elements-filled"] div[class*=entry-social] .share>i,div[class*="meta-elements"].entry-social-share .share>i,div[class*="meta-elements-boxed"].entry-social-share .share>i,div[class*="meta-elements-filled"].entry-social-share .share>i, div[class*="meta-elements-filled"]:hover, .blog-single-entry.post-overlap > .entry-author i, .blog-single-entry.post-overlap > .entry-author-bio > .details h3:before, .blog-single-entry.post-overlap > .entry-categories > .category-wrap > i, .blog-single-entry.post-overlap > .entry-comments a i, .blog-single-entry.post-overlap > .entry-date .date-wrap i, .blog-single-entry.post-overlap > .entry-likes-views .dt-sc-like-views > div > i, .blog-single-entry.post-overlap > .entry-social-share .share .dt-share-list li a:hover, .blog-single-entry.post-overlap > .entry-tags a:hover, .blog-single-entry.post-overlap > div.entry-meta-group .entry-author i, .blog-single-entry.post-overlap > div.entry-meta-group .entry-comments a i, .blog-single-entry.post-overlap > div.entry-meta-group .entry-date .date-wrap i, .blog-single-entry.post-overlap > div.entry-meta-group .entry-likes-views .dt-sc-like-views > div > i, .blog-single-entry.post-overlap > div.entry-meta-group .entry-tags a:hover, .blog-single-entry.post-overlap > div.entry-meta-group .share .dt-share-list li a:hover, .blog-single-entry.post-overlap > div.entry-meta-group > .entry-categories > .category-wrap > i, .blog-single-entry.post-custom-classic div[class*="metagroup-"] .entry-social-share:hover .share > i, article[class*="post-custom"].blog-single-entry div.dt-sc-posts-meta-group[class*="metagroup-elements-filled"] .entry-social-share .share:hover > i, .blog-single-entry[class*="post-custom-classic"] div[class*="meta-elements-"].entry-social-share:hover .share { background-color:#ffffff; }.dt-sc-portfolio-sorting a.active-sort, .dt-sc-portfolio-sorting a:hover, .dt-sc-portfolio-sorting a:hover:before, .dt-sc-portfolio-sorting a:hover:after, .dt-sc-portfolio-sorting a.active-sort:before, .dt-sc-portfolio-sorting a.active-sort:after, .portfolio.type2 .image-overlay-details, .portfolio.type2 .image-overlay .links a:hover, .dt-sc-portfolio-sorting.type2, .dt-sc-portfolio-sorting.type2:before, .portfolio.type6 .image-overlay .links a:hover, .portfolio.type7 .image-overlay-details .categories a:before, .portfolio.type7 .image-overlay .links a:hover:before { background-color:#ffffff; }.dt-skin-primary-bg, div[class*="dt-skin-primary-bg-opaque"] .upb_row_bg:before, section[class*="dt-skin-primary-bg-opaque"]:before, ul.side-nav li a:hover:before, ul.side-nav > li.current_page_item > a:before, ul.side-nav > li > ul > li.current_page_item > a:before, ul.side-nav > li > ul > li > ul > li.current_page_item > a:before, .dt-sc-skin-highlight, .two-color-section:before, .dt-sc-readmore-plus-icon:hover:before, .dt-sc-readmore-plus-icon:hover:after, .dt-sc-contact-details-on-map .map-switch-icon, .side-navigation.type2 ul.side-nav > li.current_page_item > a, .side-navigation.type4 ul.side-nav li a:after, .side-navigation.type5 ul.side-nav li:after,

				.dt-sc-counter-wrapper.type1 .dt-sc-counter-inner .dt-sc-counter-title:after, .dt-sc-counter-wrapper.type2:hover .dt-sc-counter-inner .dt-sc-counter-icon-wrapper, .dt-sc-any-carousel-wrapper .swiper-pagination.swiper-pagination-bullets .swiper-pagination-bullet-active,
				.dt-sc-any-carousel-wrapper .swiper-pagination-progressbar .swiper-pagination-progressbar-fill, .dt-sc-any-carousel-wrapper .swiper-scrollbar .swiper-scrollbar-drag,

				.jet-carousel .jet-slick-dots li:hover span, .jet-carousel .jet-slick-dots li.slick-active span, .swiper-scrollbar .swiper-scrollbar-drag, .dt-sc-header-icons-list > div.search-item .dt-sc-search-form-container.search-overlay .dt-sc-search-overlay-form-close { background-color:#ffffff; }.elementor-button.dt-elementor-button { background-color:#ffffff; }.mz-title .mz-title-content h2, .mz-title-content h3.widgettitle, .mz-title .mz-title-content:before, .mz-blog .comments a, .mz-blog div.vc_gitem-post-category-name, .mz-blog .ico-format, .side-navigation-content .dt-sc-wings-heading:after, .animated-twin-lines:after { background-color:#ffffff; }.dt-sc-tabs-vertical-frame-container.type3 ul.dt-sc-tabs-vertical-frame > li > a:hover, .dt-sc-tabs-vertical-frame-container.type3 ul.dt-sc-tabs-vertical-frame > li > a.current, .dt-sc-tabs-vertical-frame-container.type4 ul.dt-sc-tabs-vertical-frame > li > a.current:before { background-color:#ffffff; }.live-chat a, .dt-sc-menu .menu-categories a:before, .dt-sc-training-details-overlay, .custom-navigation .vc_images_carousel .vc_carousel-indicators li,  .dt-sc-procedure-item:hover, ul.dt-sc-vertical-nav > li.active > a, ul.time-slots > li a:hover, #wpsl-search-btn, #wpsl-stores li > p span, #wpsl-stores li > p, #wpsl-stores li > p ~ .wpsl-directions, .dt-sc-toggle-advanced-options span, .slick-dots li.slick-active, .slick-dots li:hover { background-color:#ffffff; }#footer .wpcf7-form.bottom-bordered input[type="submit"]:hover, #footer .wpcf7-form.bottom-bordered button:hover, #footer .wpcf7-form.bottom-bordered input[type="button"]:hover, #footer .wpcf7-form.bottom-bordered input[type="reset"]:hover { border-color:#ffffff; }.tagcloud a:hover, .dt-sc-dark-bg .tagcloud a:hover, .secondary-sidebar .type3 .widgettitle, .secondary-sidebar .type6 .widgettitle, .secondary-sidebar .type13 .widgettitle:before, .secondary-sidebar .type14 .widgettitle, .secondary-sidebar .type16 .widgettitle { border-color:#ffffff; }.pagination ul li span, .pagination ul li a:hover, .blog-entry .entry-social-share .share, .dt-sc-post-entry.entry-cover-layout .blog-entry.sticky, .dt-sc-post-entry.entry-cover-layout .blog-entry .entry-social-share .share, .dt-sc-content-overlay-style.dt-sc-post-entry .blog-entry div.entry-tags a:hover, .dt-sc-classic-style.dt-sc-post-entry .blog-entry.sticky > div.entry-meta-group > div, .dt-sc-classic-overlay-style.dt-sc-post-entry .blog-entry > .entry-categories > a:hover, .dt-sc-overlay-style.dt-sc-post-entry.entry-list-layout .blog-entry .entry-thumb, .dt-sc-overlay-style.dt-sc-post-entry.entry-list-layout.entry-right-thumb .blog-entry .entry-thumb, .dt-sc-overlay-style.dt-sc-post-entry.entry-grid-layout .blog-entry > div.entry-thumb, .dt-sc-minimal-style.dt-sc-post-entry.entry-list-layout .blog-entry.sticky, .dt-sc-minimal-style.dt-sc-post-entry.entry-list-layout .blog-entry.sticky > div.entry-meta-group, .dt-sc-title-overlap-style.dt-sc-post-entry .blog-entry.sticky > div.entry-title:after, .dt-sc-title-overlap-style.dt-sc-post-entry .blog-entry:hover > div.entry-title:after, .blog-single-entry.post-overlay .author span,.commentlist li.comment .reply a,.blog-single-entry.post-overlap > .entry-comments a:hover,.blog-single-entry.post-overlap > .entry-author > .author-wrap:hover,.blog-single-entry.post-overlap > .entry-date > .date-wrap:hover,.blog-single-entry.post-overlap > .entry-categories > .category-wrap:hover,.blog-single-entry.post-overlap > .entry-likes-views .dt-sc-like-views > div:hover,.blog-single-entry.post-overlap > div.entry-meta-group .entry-comments a:hover,.blog-single-entry.post-overlap > div.entry-meta-group .entry-author > .author-wrap:hover,.blog-single-entry.post-overlap > div.entry-meta-group .entry-date > .date-wrap:hover,.blog-single-entry.post-overlap > div.entry-meta-group > .entry-categories > .category-wrap:hover,.blog-single-entry.post-overlap > div.entry-meta-group .entry-likes-views .dt-sc-like-views > div:hover,.blog-single-entry.post-breadcrumb-fixed,.blog-single-entry.post-breadcrumb-fixed div.entry-meta-group .entry-comments a:hover,.blog-single-entry.post-breadcrumb-fixed div.entry-meta-group .entry-author > .author-wrap:hover,.blog-single-entry.post-breadcrumb-fixed div.entry-meta-group .entry-likes-views .dt-sc-like-views > div:hover,.blog-single-entry.post-breadcrumb-fixed div.entry-meta-group .entry-date .date-wrap:hover,.blog-single-entry.post-breadcrumb-fixed .entry-comments a:hover,.blog-single-entry.post-breadcrumb-fixed .entry-author > .author-wrap:hover,.blog-single-entry.post-breadcrumb-fixed .entry-likes-views .dt-sc-like-views > div:hover,.blog-single-entry.post-breadcrumb-fixed .entry-date .date-wrap:hover,.single-post-header-wrapper.dt-parallax-bg > .container .post-categories a:hover, div[class*="metagroup-elements-filled"] div[class*="entry-"], div[class*="meta-elements-filled"], div[class*="metagroup-elements-boxed"] div[class*="entry-"]:hover, div[class*="meta-elements-boxed"]:hover, .dt-related-carousel .carousel-pager > a, .page-link > span, .page-link > a:hover, .page-link a, .page-link > span, .blog-single-entry.post-overlap > .entry-tags a,.blog-single-entry.post-overlap > .entry-social-share .share .dt-share-list li a,.blog-single-entry.post-overlap > .entry-comments a,.blog-single-entry.post-overlap > .entry-likes-views .dt-sc-like-views > div,.blog-single-entry.post-overlap > .entry-tags a,.blog-single-entry.post-overlap > .entry-social-share .share .dt-share-list li a,.blog-single-entry.post-overlap > .entry-comments a,.blog-single-entry.post-overlap > .entry-likes-views .dt-sc-like-views > div,.blog-single-entry.post-overlap > div.entry-meta-group .entry-tags a,.blog-single-entry.post-overlap > div.entry-meta-group .share .dt-share-list li a,.blog-single-entry.post-overlap > div.entry-meta-group:before,.blog-single-entry.post-overlap > div.entry-meta-group:after,.blog-single-entry.post-overlap > div.entry-meta-group .entry-comments a,.blog-single-entry.post-overlap > div.entry-meta-group .entry-likes-views .dt-sc-like-views > div,.blog-single-entry.post-overlap > .entry-related-posts > h4,.blog-single-entry.post-breadcrumb-fixed .entry-comments a,.blog-single-entry.post-breadcrumb-fixed .entry-categories > .category-wrap > a,.blog-single-entry.post-breadcrumb-fixed .entry-tags a,.blog-single-entry.post-breadcrumb-fixed .entry-social-share .share .dt-share-list li a,.blog-single-entry.post-breadcrumb-parallax > .entry-meta-group,.blog-single-entry.post-breadcrumb-parallax > .entry-meta-group:before,.blog-single-entry.post-breadcrumb-parallax > .entry-meta-group:after, .post-custom-minimal.blog-single-entry .write-comment-button a, .blog-single-entry.post-overlap > div.entry-meta-group > .entry-categories > .category-wrap, .blog-single-entry.post-overlap > .entry-categories > .category-wrap, .blog-single-entry.post-overlap > div.entry-meta-group > .entry-author > .author-wrap, .blog-single-entry.post-overlap > .entry-author > .author-wrap, article[class*="post-custom-"].blog-single-entry .entry-social-share > .share { border-color:#ffffff; }.dt-sc-portfolio-sorting a.active-sort, .dt-sc-portfolio-sorting a:hover, .portfolio.type7 .image-overlay .links a:before { border-color:#ffffff; }ul.dt-sc-tabs-vertical > li > a.current, .dt-sc-tabs-vertical-frame-container.type3 ul.dt-sc-tabs-vertical-frame > li > a:hover, .dt-sc-tabs-vertical-frame-container.type3 ul.dt-sc-tabs-vertical-frame > li > a.current, .dt-sc-tabs-vertical-frame-container.type4 ul.dt-sc-tabs-vertical-frame > li > a.current:before, .dt-sc-tabs-vertical-frame-container.type4 ul.dt-sc-tabs-vertical-frame > li > a.current:before { border-color:#ffffff; }.blog-single-entry.post-breadcrumb-fixed .entry-thumb > .entry-format a:after { border-top-color:#ffffff; }.dt-skin-primary-border, carousel-arrows a:hover, ul.dt-sc-vertical-nav, ul.dt-sc-vertical-nav > li:first-child > a,
				.dt-sc-loading:before, .side-navigation.type2 ul.side-nav, .side-navigation.type2 ul.side-nav li, .side-navigation.type2 ul.side-nav li ul, .dt-sc-images-carousel li,
				.dt-sc-counter-wrapper.type2 .dt-sc-counter-inner .dt-sc-counter-icon-wrapper:after, .elementor-button.dt-elementor-button.dt-bordered:hover { border-color:#ffffff; }.dt-sc-up-arrow:before { border-bottom-color:#ffffff; }.dt-sc-tabs-vertical-frame-container.type3 ul.dt-sc-tabs-vertical-frame > li > a.current:before, .dt-sc-event-image-caption:hover .dt-sc-image-content:before, .side-navigation.type2 ul.side-nav > li.current_page_item > a:after, .side-navigation.type2 ul.side-nav > li > ul > li.current_page_item > a:after { border-left-color:#ffffff; }.dt-sc-menu-sorting a.active-sort, .dt-sc-menu .image-overlay .price { border-color:#ffffff; }.error404 .type2 a.dt-sc-back, .error404 .type4 .error-box:before, .error404 .type8 .dt-go-back { background-color:#ffffff; }.error404 h2, .error404 .type5 h2, .error404 .type6 .error-box h2, .error404 .type2 h2, .error404 .type8 h2, .error404 .type8 .dt-go-back:hover i, .error404 .type1 .dt-sc-button:before { color:#ffffff; }.under-construction.type4 .dt-sc-counter-wrapper, .under-construction.type1 .dt-sc-counter-wrapper .counter-icon-wrapper:before, .under-construction.type7 .dt-sc-counter-wrapper { background-color:#ffffff; }.under-construction.type4 .wpb_wrapper > h2 span, .under-construction.type4 .read-more i, .under-construction.type4  .wpb_wrapper >  h4:after, .under-construction.type4 .wpb_wrapper > h4:before, .under-construction.type1 .read-more span.fa, .under-construction.type1 .read-more a:hover, .under-construction.type2 .counter-icon-wrapper .dt-sc-counter-number, .under-construction.type2 h2, .under-construction.type2 .dt-sc-counter-wrapper h3, .under-construction.type2 .mailchimp-newsletter h3,  .under-construction.type7 h2, .under-construction.type7 .mailchimp-newsletter h3, .under-construction.type3 p, .under-construction.type5 h2 span, .under-construction.type5 .dt-sc-counter-number, .under-construction.type5 input[type="email"], .under-construction.type7 .aligncenter .wpb_text_column h2 { color:#ffffff; }#buddypress div.pagination .pagination-links span, #buddypress div.pagination .pagination-links a:hover, #buddypress #group-create-body #group-creation-previous, #item-header-content #item-meta > #item-buttons .group-button, #buddypress div#subnav.item-list-tabs ul li.feed a:hover, #buddypress div.activity-meta a:hover, #buddypress div.item-list-tabs ul li.selected a span, #buddypress .activity-list li.load-more a, #buddypress .activity-list li.load-newest a { background-color:#ffffff; }#buddypress div.pagination .pagination-links span, #buddypress div.pagination .pagination-links a:hover, #buddypress #members-dir-list ul li:hover { border-color:#ffffff; }#members-list.item-list.single-line li h5 span.small a.button, #buddypress div.item-list-tabs ul li.current a, #buddypress #group-create-tabs ul li.current a, #buddypress a.bp-primary-action:hover span, #buddypress div.item-list-tabs ul li.selected a,
				.widget.buddypress div.item-options a:hover, .widget.buddypress div.item-options a.selected, #footer .footer-widgets.dt-sc-dark-bg .widget.buddypress div.item-options a.selected, .widget.widget_bp_core_members_widget div.item .item-title a:hover, .widget.buddypress .bp-login-widget-user-links > div.bp-login-widget-user-link a:hover { color:#ffffff; }#bbpress-forums li.bbp-header, .bbp-submit-wrapper #bbp_topic_submit, .bbp-reply-form #bbp_reply_submit, .bbp-pagination-links a:hover, .bbp-pagination-links span.current, #bbpress-forums #subscription-toggle a.subscription-toggle { background-color:#ffffff; }.bbp-pagination-links a:hover, .bbp-pagination-links span.current { border-color:#ffffff; }.bbp-forums .bbp-body .bbp-forum-info::before { color:#ffffff; }#tribe-bar-views .tribe-bar-views-list .tribe-bar-views-option a:hover, #tribe-bar-views .tribe-bar-views-list .tribe-bar-views-option.tribe-bar-active a:hover, #tribe-bar-form .tribe-bar-submit input[type="submit"], #tribe-bar-views .tribe-bar-views-list li.tribe-bar-active a, .tribe-events-calendar thead th, #tribe-events-content .tribe-events-tooltip h4, .tribe-events-calendar td.tribe-events-present div[id*="tribe-events-daynum-"], .tribe-events-read-more, #tribe-events .tribe-events-button, .tribe-events-button, .tribe-events-calendar td.tribe-events-present div[id*="tribe-events-daynum-"] > a, .tribe-events-back > a, #tribe_events_filters_toggle { background-color:#ffffff; }.tribe-events-list .tribe-events-event-cost span { border-color:#ffffff; }.tribe-grid-header, .tribe-grid-allday .tribe-events-week-allday-single, .tribe-grid-body .tribe-events-week-hourly-single { background-color:#ffffff; }.type1.tribe_events .event-image-wrapper .event-datetime > span, .type3.tribe_events .event-date { background-color:#ffffff; }.type1 .event-schedule, .type1.tribe_events .nav-top-links a:hover, .type1.tribe_events .event-image-wrapper .event-datetime > i, .type1.tribe_events .event-image-wrapper .event-venue > i, .type1.tribe_events h4 a, .type2.tribe_events .date-wrapper p span, .type2.tribe_events h4 a, .type3.tribe_events .right-calc a:hover, .type3.tribe_events .tribe-events-sub-nav li a:hover, .type3.tribe_events .tribe-events-sub-nav li a span, .type4.tribe_events .data-wrapper p span, .type4.tribe_events .data-wrapper p i, .type4.tribe_events .event-organize h4 a, .type4.tribe_events .event-venue h4 a, .type5.tribe_events .event-details h3, .type5.tribe_events .event-organize h3, .type5.tribe_events .event-venue h3, .type5.tribe_events .data-wrapper p span, .data-wrapper p i, .type5.tribe_events .event-organize h4 a, .type5.tribe_events .event-venue h4 a { color:#ffffff; }.dt-sc-event.type1 .dt-sc-event-thumb p, .dt-sc-event.type1 .dt-sc-event-meta:before, .dt-sc-event.type2:hover .dt-sc-event-meta, .dt-sc-event.type3 .dt-sc-event-date, .dt-sc-event.type3:hover .dt-sc-event-meta { background-color:#ffffff; }.dt-sc-event.type4 .dt-sc-event-date:after { border-bottom-color:#ffffff; }.dt-sc-event.type1 .dt-sc-event-meta p span, .dt-sc-event.type1:hover h2.entry-title a, .dt-sc-event.type3:hover h2.entry-title a, .dt-sc-event.type4 .dt-sc-event-date span { color:#ffffff; }.widget.tribe_mini_calendar_widget .tribe-mini-calendar thead.tribe-mini-calendar-nav td,

				.widget.tribe_mini_calendar_widget .tribe-mini-calendar .tribe-events-present, .widget.tribe_mini_calendar_widget .tribe-mini-calendar .tribe-events-has-events.tribe-mini-calendar-today, .tribe-mini-calendar .tribe-events-has-events.tribe-events-present a:hover, .widget.tribe_mini_calendar_widget .tribe-mini-calendar td.tribe-events-has-events.tribe-mini-calendar-today a:hover,

				.dt-sc-dark-bg .widget.tribe_mini_calendar_widget .tribe-mini-calendar .tribe-events-present, .dt-sc-dark-bg .widget.tribe_mini_calendar_widget .tribe-mini-calendar .tribe-events-has-events.tribe-mini-calendar-today, .dt-sc-dark-bg .tribe-mini-calendar .tribe-events-has-events.tribe-events-present a:hover, .dt-sc-dark-bg .widget.tribe_mini_calendar_widget .tribe-mini-calendar td.tribe-events-has-events.tribe-mini-calendar-today a:hover { background-color:#ffffff; }.widget.tribe_mini_calendar_widget .tribe-mini-calendar thead.tribe-mini-calendar-nav td { border-color:#ffffff; }.widget.tribe-events-countdown-widget .tribe-countdown-text a:hover { color:#ffffff; }.woocommerce ul.products li.product .featured-tag:after, .woocommerce ul.products li.product:hover .featured-tag:after, .woocommerce.single-product .featured-tag:after,

				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-brdrfill .yith-wcwl-add-to-wishlist a:hover,
				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.product-button.style-bgfill.hide-button-text .compare:hover,
				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.product-button.style-bgfill.hide-button-text .yith-wcwl-add-to-wishlist a:hover,

				.woocommerce ul.products.product-hover-fade-skinborder li.product:hover .product-wrapper:before,
				.woocommerce ul.products.product-hover-thumb-fade-skinborder li.product:hover .product-thumb .image:before,
				.woocommerce ul.products.product-border-type-thumb.product-border-position-default[class*="product-bordershadow-highlight"] li.product .product-thumb,
				.woocommerce ul.products.product-border-type-default.product-border-position-default[class*="product-bordershadow-highlight"] li.product .product-wrapper,

				.woocommerce ul.products.dt-hifashion-layout li.product:hover .product-wrapper .product-details .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline a:after,
				.woocommerce ul.products.dt-hifashion-layout li.product:hover .product-wrapper .product-details .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline a.button:after,
				.woocommerce ul.products.dt-hifashion-layout li.product:hover .product-wrapper .product-details .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline button:after,
				.woocommerce ul.products.dt-hifashion-layout li.product:hover .product-wrapper .product-details .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline button.button:after,
				.woocommerce ul.products.dt-hifashion-layout li.product:hover .product-wrapper .product-details .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline .button:after,
				.woocommerce nav.woocommerce-pagination ul li a:focus,
				.woocommerce nav.woocommerce-pagination ul li a:hover,
				.woocommerce nav.woocommerce-pagination ul li span.current, .woocommerce nav.woocommerce-pagination ul li .page-numbers.dots { border-color:#ffffff; }.woocommerce ul.products li.product .product-details div[class$="product-buttons-wrapper"] a, .woocommerce ul.products li.product .product-details div[class$="product-buttons-wrapper"] button, .woocommerce ul.products li.product .product-details div[class$="product-buttons-wrapper"] .button,

				.woocommerce .woocommerce-breadcrumb a:hover, .dt-sc-single-product-nav .dt-sc-single-product-nav-btn a:hover span:before, .dt-sc-single-product-nav .dt-sc-single-product-nav-back-btn:hover span:before, .dt-sc-single-product-nav .dt-sc-single-product-nav-back-btn:hover span:after,


				.woocommerce .product .summary .product-button.style-simple .compare:hover,
				.woocommerce .product .summary .product-button.style-simple .dt-wcsg-button:hover,
				.woocommerce .product .summary .product-button.style-simple .yith-wcqv-button:hover,
				.woocommerce .product .summary .product-button.style-simple .yith-wcwl-add-to-wishlist a:hover,

				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper .wc_btn_inline a:hover,
				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper .wc_btn_inline a.button:hover,
				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper .wc_btn_inline button:hover,
				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper .wc_btn_inline button.button,
				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper .wc_btn_inline .button:hover,
				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper .wc_btn_inline .button.alt:hover,
				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper .wc_btn_inline .button.disabled:hover,
				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper .wc_btn_inline .button[disabled]:hover,
				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper .wc_btn_inline .button.alt.disabled:hover,
				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper .wc_btn_inline .button.alt[disabled]:hover,

				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-skin-brdrfill .wc_btn_inline a,
				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-skin-brdrfill .wc_btn_inline a.button,
				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-skin-brdrfill .wc_btn_inline button,
				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-skin-brdrfill .wc_btn_inline button.button,
				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-skin-brdrfill .wc_btn_inline .button,
				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-skin-brdrfill .wc_btn_inline .button.alt,
				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-skin-brdrfill .wc_btn_inline .button.disabled,
				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-skin-brdrfill .wc_btn_inline .button[disabled],
				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-skin-brdrfill .wc_btn_inline .button.alt.disabled,
				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-skin-brdrfill .wc_btn_inline .button.alt[disabled],

				.dt-sc-single-product-share-list li a:hover, .dt-sc-single-product-follow-list li a:hover,
				.woocommerce .product .dt-sc-product-summary .dt-sc-single-product-share-container.style-simple .dt-sc-single-product-share-list li a:hover,
				.woocommerce .product .dt-sc-product-summary .dt-sc-single-product-follow-container.style-simple .dt-sc-single-product-follow-list li a:hover,

				.woocommerce .product .dt-sc-product-summary .dt-sc-single-product-share-container.style-brdrfill .dt-sc-single-product-share-list li a:hover,
				.woocommerce .product .dt-sc-product-summary .dt-sc-single-product-follow-container.style-brdrfill .dt-sc-single-product-follow-list li a:hover,

				.woocommerce .product .dt-sc-product-summary .dt-sc-single-product-share-container.style-skin-brdrfill .dt-sc-single-product-share-list li a,
				.woocommerce .product .dt-sc-product-summary .dt-sc-single-product-follow-container.style-skin-brdrfill .dt-sc-single-product-follow-list li a,

				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-brdrfill .yith-wcwl-add-to-wishlist a:hover,
				.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-bgfill .wc_btn_inline .variations_button .quantity a:hover,

				.woocommerce .cart .quantity > a[class*="arrow"]:hover, .woocommerce-page .cart .quantity > a[class*="arrow"]:hover, .woocommerce.single-product div.product .cart .quantity > a[class*="arrow"]:hover, .woocommerce table.cart td.product-name a:not(.button):hover, .woocommerce-page .woocommerce table.shop_table tbody td .quantity > a:hover, .woocommerce .quantity.quantity-with-plusminus input:not(.qty):hover, .woocommerce-page .quantity.quantity-with-plusminus input:not(.qty):hover,

				.woocommerce div.product .dt-sc-single-product-nav-intro-wrapper .product-nav-intro .product-nav-intro-description a.product-title:hover,
				.woocommerce .woocommerce-MyAccount-content a:hover, .woocommerce .product .summary form.cart .group_table td label a:hover, .woocommerce-page table.shop_table.cart .quantity > a:hover i,

				.woocommerce ul.products.product-thumb-iconsgroup-style-simple li.product .product-thumb .product-buttons-wrapper.product-icons a:hover,
				.woocommerce ul.products.product-thumb-iconsgroup-style-simple li.product .product-thumb .product-buttons-wrapper.product-icons a.button:hover,
				.woocommerce ul.products.product-thumb-iconsgroup-style-simple li.product .product-thumb .product-buttons-wrapper.product-icons button:hover,
				.woocommerce ul.products.product-thumb-iconsgroup-style-simple li.product .product-thumb .product-buttons-wrapper.product-icons button.button:hover,
				.woocommerce ul.products.product-thumb-iconsgroup-style-simple li.product .product-thumb .product-buttons-wrapper.product-icons .button:hover,

				.woocommerce ul.products.product-thumb-buttonelement-style-simple li.product .product-thumb .product-buttons-wrapper.product-button .wc_btn_inline:hover,
				.woocommerce ul.products.product-thumb-buttonelement-style-simple li.product .product-thumb .product-buttons-wrapper.product-button .wc_btn_inline a:hover,
				.woocommerce ul.products.product-thumb-buttonelement-style-simple li.product .product-thumb .product-buttons-wrapper.product-button .wc_btn_inline a.button:hover,
				.woocommerce ul.products.product-thumb-buttonelement-style-simple li.product .product-thumb .product-buttons-wrapper.product-button .wc_btn_inline button:hover,
				.woocommerce ul.products.product-thumb-buttonelement-style-simple li.product .product-thumb .product-buttons-wrapper.product-button .wc_btn_inline button.button:hover,
				.woocommerce ul.products.product-thumb-buttonelement-style-simple li.product .product-thumb .product-buttons-wrapper.product-button .wc_btn_inline .button:hover,

				.woocommerce ul.products.product-content-iconsgroup-style-simple li.product .product-details .product-buttons-wrapper.product-icons a:hover,
				.woocommerce ul.products.product-content-iconsgroup-style-simple li.product .product-details .product-buttons-wrapper.product-icons a.button:hover,
				.woocommerce ul.products.product-content-iconsgroup-style-simple li.product .product-details .product-buttons-wrapper.product-icons button:hover,
				.woocommerce ul.products.product-content-iconsgroup-style-simple li.product .product-details .product-buttons-wrapper.product-icons button.button:hover,
				.woocommerce ul.products.product-content-iconsgroup-style-simple li.product .product-details .product-buttons-wrapper.product-icons .button:hover,

				.woocommerce ul.products.product-content-buttonelement-style-simple li.product .product-details .product-buttons-wrapper.product-button .wc_btn_inline:hover,
				.woocommerce ul.products.product-content-buttonelement-style-simple li.product .product-details .product-buttons-wrapper.product-button .wc_btn_inline a:hover,
				.woocommerce ul.products.product-content-buttonelement-style-simple li.product .product-details .product-buttons-wrapper.product-button .wc_btn_inline a.button:hover,
				.woocommerce ul.products.product-content-buttonelement-style-simple li.product .product-details .product-buttons-wrapper.product-button .wc_btn_inline button:hover,
				.woocommerce ul.products.product-content-buttonelement-style-simple li.product .product-details .product-buttons-wrapper.product-button .wc_btn_inline button.button:hover,
				.woocommerce ul.products.product-content-buttonelement-style-simple li.product .product-details .product-buttons-wrapper.product-button .wc_btn_inline .button:hover,

				.woocommerce ul.products[class*="product-thumb-iconsgroup-style-brdrfill"] li.product .product-thumb .product-buttons-wrapper.product-icons a:hover,
				.woocommerce ul.products[class*="product-thumb-iconsgroup-style-brdrfill"] li.product .product-thumb .product-buttons-wrapper.product-icons a.button:hover,
				.woocommerce ul.products[class*="product-thumb-iconsgroup-style-brdrfill"] li.product .product-thumb .product-buttons-wrapper.product-icons button:hover,
				.woocommerce ul.products[class*="product-thumb-iconsgroup-style-brdrfill"] li.product .product-thumb .product-buttons-wrapper.product-icons button.button:hover,
				.woocommerce ul.products[class*="product-thumb-iconsgroup-style-brdrfill"] li.product .product-thumb .product-buttons-wrapper.product-icons .button:hover,

				.woocommerce ul.products[class*="product-thumb-buttonelement-style-brdrfill"] li.product .product-thumb .product-buttons-wrapper.product-button .wc_btn_inline:hover,
				.woocommerce ul.products[class*="product-thumb-buttonelement-style-brdrfill"] li.product .product-thumb .product-buttons-wrapper.product-button .wc_btn_inline a:hover,
				.woocommerce ul.products[class*="product-thumb-buttonelement-style-brdrfill"] li.product .product-thumb .product-buttons-wrapper.product-button .wc_btn_inline a.button:hover,
				.woocommerce ul.products[class*="product-thumb-buttonelement-style-brdrfill"] li.product .product-thumb .product-buttons-wrapper.product-button .wc_btn_inline button:hover,
				.woocommerce ul.products[class*="product-thumb-buttonelement-style-brdrfill"] li.product .product-thumb .product-buttons-wrapper.product-button .wc_btn_inline button.button:hover,
				.woocommerce ul.products[class*="product-thumb-buttonelement-style-brdrfill"] li.product .product-thumb .product-buttons-wrapper.product-button .wc_btn_inline .button:hover,

				.woocommerce ul.products[class*="product-content-iconsgroup-style-brdrfill"] li.product .product-details .product-buttons-wrapper.product-icons a:hover,
				.woocommerce ul.products[class*="product-content-iconsgroup-style-brdrfill"] li.product .product-details .product-buttons-wrapper.product-icons a.button:hover,
				.woocommerce ul.products[class*="product-content-iconsgroup-style-brdrfill"] li.product .product-details .product-buttons-wrapper.product-icons button:hover,
				.woocommerce ul.products[class*="product-content-iconsgroup-style-brdrfill"] li.product .product-details .product-buttons-wrapper.product-icons button.button:hover,
				.woocommerce ul.products[class*="product-content-iconsgroup-style-brdrfill"] li.product .product-details .product-buttons-wrapper.product-icons .button:hover,

				.woocommerce ul.products[class*="product-content-buttonelement-style-brdrfill"] li.product .product-details .product-buttons-wrapper.product-button .wc_btn_inline:hover,
				.woocommerce ul.products[class*="product-content-buttonelement-style-brdrfill"] li.product .product-details .product-buttons-wrapper.product-button .wc_btn_inline a:hover,
				.woocommerce ul.products[class*="product-content-buttonelement-style-brdrfill"] li.product .product-details .product-buttons-wrapper.product-button .wc_btn_inline a.button:hover,
				.woocommerce ul.products[class*="product-content-buttonelement-style-brdrfill"] li.product .product-details .product-buttons-wrapper.product-button .wc_btn_inline button:hover,
				.woocommerce ul.products[class*="product-content-buttonelement-style-brdrfill"] li.product .product-details .product-buttons-wrapper.product-button .wc_btn_inline button.button:hover,
				.woocommerce ul.products[class*="product-content-buttonelement-style-brdrfill"] li.product .product-details .product-buttons-wrapper.product-button .wc_btn_inline .button:hover,

				.woocommerce ul.products[class*="product-thumb-iconsgroup-style-skinbrdrfill"] li.product .product-thumb .product-buttons-wrapper.product-icons a,
				.woocommerce ul.products[class*="product-thumb-iconsgroup-style-skinbrdrfill"] li.product .product-thumb .product-buttons-wrapper.product-icons a.button,
				.woocommerce ul.products[class*="product-thumb-iconsgroup-style-skinbrdrfill"] li.product .product-thumb .product-buttons-wrapper.product-icons button,
				.woocommerce ul.products[class*="product-thumb-iconsgroup-style-skinbrdrfill"] li.product .product-thumb .product-buttons-wrapper.product-icons button.button,
				.woocommerce ul.products[class*="product-thumb-iconsgroup-style-skinbrdrfill"] li.product .product-thumb .product-buttons-wrapper.product-icons .button,

				.woocommerce ul.products[class*="product-thumb-buttonelement-style-skinbrdrfill"] li.product .product-thumb .product-buttons-wrapper.product-button .wc_btn_inline,
				.woocommerce ul.products[class*="product-thumb-buttonelement-style-skinbrdrfill"] li.product .product-thumb .product-buttons-wrapper.product-button .wc_btn_inline a,
				.woocommerce ul.products[class*="product-thumb-buttonelement-style-skinbrdrfill"] li.product .product-thumb .product-buttons-wrapper.product-button .wc_btn_inline a.button,
				.woocommerce ul.products[class*="product-thumb-buttonelement-style-skinbrdrfill"] li.product .product-thumb .product-buttons-wrapper.product-button .wc_btn_inline button,
				.woocommerce ul.products[class*="product-thumb-buttonelement-style-skinbrdrfill"] li.product .product-thumb .product-buttons-wrapper.product-button .wc_btn_inline button.button,
				.woocommerce ul.products[class*="product-thumb-buttonelement-style-skinbrdrfill"] li.product .product-thumb .product-buttons-wrapper.product-button .wc_btn_inline .button,

				.woocommerce ul.products[class*="product-content-iconsgroup-style-skinbrdrfill"] li.product .product-details .product-buttons-wrapper.product-icons a,
				.woocommerce ul.products[class*="product-content-iconsgroup-style-skinbrdrfill"] li.product .product-details .product-buttons-wrapper.product-icons a.button,
				.woocommerce ul.products[class*="product-content-iconsgroup-style-skinbrdrfill"] li.product .product-details .product-buttons-wrapper.product-icons button,
				.woocommerce ul.products[class*="product-content-iconsgroup-style-skinbrdrfill"] li.product .product-details .product-buttons-wrapper.product-icons button.button,
				.woocommerce ul.products[class*="product-content-iconsgroup-style-skinbrdrfill"] li.product .product-details .product-buttons-wrapper.product-icons .button,

				.woocommerce ul.products[class*="product-content-buttonelement-style-skinbrdrfill"] li.product .product-details .product-buttons-wrapper.product-button .wc_btn_inline,
				.woocommerce ul.products[class*="product-content-buttonelement-style-skinbrdrfill"] li.product .product-details .product-buttons-wrapper.product-button .wc_btn_inline a,
				.woocommerce ul.products[class*="product-content-buttonelement-style-skinbrdrfill"] li.product .product-details .product-buttons-wrapper.product-button .wc_btn_inline a.button,
				.woocommerce ul.products[class*="product-content-buttonelement-style-skinbrdrfill"] li.product .product-details .product-buttons-wrapper.product-button .wc_btn_inline button,
				.woocommerce ul.products[class*="product-content-buttonelement-style-skinbrdrfill"] li.product .product-details .product-buttons-wrapper.product-button .wc_btn_inline button.button,
				.woocommerce ul.products[class*="product-content-buttonelement-style-skinbrdrfill"] li.product .product-details .product-buttons-wrapper.product-button .wc_btn_inline .button,

				.woocommerce ul.products.dt-reebok-layout li.product .product-wrapper .product-details .product-title h5 a:not(:hover),
				.woocommerce nav.woocommerce-pagination ul li a, .woocommerce nav.woocommerce-pagination ul li a, .woocommerce nav.woocommerce-pagination ul li span,
				a.shipping-calculator-button:hover, .woocommerce-form__label-for-checkbox > span::before,
				.woocommerce .woocommerce-shipping-methods input[type="radio"] ~ label::before,
				.woocommerce-page #payment.woocommerce-checkout-payment ul.payment_methods li input[type="radio"] ~ label::before,
				.comment-form-dt-privatepolicy input[type="checkbox"] ~ label::before, .woocommerce div.product .woocommerce-tabs ul.tabs li a:hover, .woocommerce div.product .woocommerce-tabs ul.tabs li.active a, .woocommerce form.login .woocommerce-form-row label:before, .woocommerce form.register .woocommerce-form-row label:before { color:#ffffff; }.dt-inline-modal > h4 { background-color:#ffffff; }.dt-header-menu ul.dt-primary-nav li > a:hover, .dt-header-menu ul.dt-primary-nav li:hover > a,
				.dt-header-menu ul.dt-primary-nav li ul.children li > a:hover, .dt-header-menu ul.dt-primary-nav li ul.children li:hover > a,
				.dt-header-menu ul.dt-primary-nav li ul.sub-menu li > a:hover, .dt-header-menu ul.dt-primary-nav li ul.sub-menu li:hover > a,

				.dt-header-menu ul.dt-primary-nav li.current-menu-item > a, .dt-header-menu ul.dt-primary-nav li.current-page-item > a, .dt-header-menu ul.dt-primary-nav li.current-menu-ancestor > a, .dt-header-menu ul.dt-primary-nav li.current-page-ancestor > a,

				.dt-header-menu ul.dt-primary-nav li.current_menu_item > a, .dt-header-menu ul.dt-primary-nav li.current_page_item > a, .dt-header-menu ul.dt-primary-nav li.current_menu_ancestor > a, .dt-header-menu ul.dt-primary-nav li.current_page_ancestor > a,

				.dt-header-menu ul.dt-primary-nav li ul.children li.current-menu-item > a, .dt-header-menu ul.dt-primary-nav li ul.children li.current-page-item > a, .dt-header-menu ul.dt-primary-nav li ul.children li.current-menu-ancestor > a, .dt-header-menu ul.dt-primary-nav li ul.children li.current-page-ancestor > a,

				.dt-header-menu ul.dt-primary-nav li ul.children li.current_menu_item > a, .dt-header-menu ul.dt-primary-nav li ul.children li.current_page_item > a, .dt-header-menu ul.dt-primary-nav li ul.children li.current_menu_ancestor > a, .dt-header-menu ul.dt-primary-nav li ul.children li.current_page_ancestor > a,

				.dt-header-menu ul.dt-primary-nav li ul.sub-menu li.current-menu-item > a, .dt-header-menu ul.dt-primary-nav li ul.sub-menu li.current-page-item > a, .dt-header-menu ul.dt-primary-nav li ul.sub-menu li.current-menu-ancestor > a, .dt-header-menu ul.dt-primary-nav li ul.sub-menu li.current-page-ancestor > a,

				.dt-header-menu ul.dt-primary-nav li ul.sub-menu li.current_menu_item > a, .dt-header-menu ul.dt-primary-nav li ul.sub-menu li.current_page_item > a, .dt-header-menu ul.dt-primary-nav li ul.sub-menu li.current_menu_ancestor > a, .dt-header-menu ul.dt-primary-nav li ul.sub-menu li.current_page_ancestor > a,

				.mobile-menu ul.dt-primary-nav li > a:hover, .mobile-menu ul.dt-primary-nav li:hover > a, .mobile-menu ul.dt-primary-nav li ul.children li > a:hover, .mobile-menu ul.dt-primary-nav li ul.children li:hover > a, .mobile-menu ul.dt-primary-nav li ul.sub-menu li > a:hover, .mobile-menu ul.dt-primary-nav li ul.sub-menu li:hover > a,

				.mobile-menu ul.dt-primary-nav li.current-menu-item > a, .mobile-menu ul.dt-primary-nav li.current-page-item > a, .mobile-menu ul.dt-primary-nav li.current-menu-ancestor > a, .mobile-menu ul.dt-primary-nav li.current-page-ancestor > a,

				.mobile-menu ul.dt-primary-nav li.current_menu_item > a, .mobile-menu ul.dt-primary-nav li.current_page_item > a, .mobile-menu ul.dt-primary-nav li.current_menu_ancestor > a, .mobile-menu ul.dt-primary-nav li.current_page_ancestor > a,

				.mobile-menu ul.dt-primary-nav li ul.children li.current-menu-item > a, .mobile-menu ul.dt-primary-nav li ul.children li.current-page-item > a, .mobile-menu ul.dt-primary-nav li ul.children li.current-menu-ancestor > a, .mobile-menu ul.dt-primary-nav li ul.children li.current-page-ancestor > a,

				.mobile-menu ul.dt-primary-nav li ul.children li.current_menu_item > a, .mobile-menu ul.dt-primary-nav li ul.children li.current_page_item > a, .mobile-menu ul.dt-primary-nav li ul.children li.current_menu_ancestor > a, .mobile-menu ul.dt-primary-nav li ul.children li.current_page_ancestor > a,

				.mobile-menu ul.dt-primary-nav li ul.sub-menu li.current-menu-item > a, .mobile-menu ul.dt-primary-nav li ul.sub-menu li.current-page-item > a, .mobile-menu ul.dt-primary-nav li ul.sub-menu li.current-menu-ancestor > a, .mobile-menu ul.dt-primary-nav li ul.sub-menu li.current-page-ancestor > a,

				.mobile-menu ul.dt-primary-nav li ul.sub-menu li.current_menu_item > a, .mobile-menu ul.dt-primary-nav li ul.sub-menu li.current_page_item > a, .mobile-menu ul.dt-primary-nav li ul.sub-menu li.current_menu_ancestor > a, .mobile-menu ul.dt-primary-nav li ul.sub-menu li.current_page_ancestor > a,

				.menu-icons-wrapper .overlay-search #searchform:before,

				.elementor-element.elementor-widget-image-box:hover .elementor-image-box-wrapper .elementor-image-box-content .elementor-image-box-title { color:#ffa35a; }.dt-skin-secondary-color, .elementor-element .dt-skin-secondary-color .elementor-heading-title, .commententries ul.commentlist li .reply a.comment-reply-login:hover, .blog-single-entry.post-overlap > .entry-meta-group > .entry-categories > .category-wrap > a:hover, .blog-single-entry.post-overlap > .entry-categories > .category-wrap > a:hover, .blog-single-entry.post-overlap > .entry-meta-group .entry-likes-views .dt-sc-like-views > div > a:hover, .blog-single-entry.post-overlap > .entry-meta-group > .entry-author > .author-wrap > a:hover, .blog-single-entry.post-overlap > .entry-author > .author-wrap > a:hover, .blog-single-entry[class*="post-custom-classic"] .entry-post-navigation > div > .nav-title-wrap h3 a:hover, .post-custom-minimal.blog-single-entry .entry-post-navigation > .post-prev-link h3 a:hover, .dt-sc-header-icons-list > div.loginlogout-item a:hover i,

			.dt-advanced-carousel-wrapper:hover .slick-arrow:hover, .dt-advanced-carousel-wrapper:hover .slick-arrow:focus, .dt-advanced-carousel-item-wrapper.slick-current.slick-active .testimonial-wrapper .author-name .elementor-heading-title, .dt-advanced-carousel-item-wrapper .testimonial-wrapper:hover .author-name .elementor-heading-title, .header-contact-info .elementor-icon-box-wrapper:hover .elementor-icon-box-content .elementor-icon-box-title, .header-contact-info .elementor-icon-box-wrapper:hover .elementor-icon-box-content .elementor-icon-box-title a, .footer-social-share .elementor-social-icon:hover i, .elementor-element .elementor-jet-pricing-table .pricing-table:hover .pricing-table__title, .side-navigation.type3 ul.side-nav>li.current_page_item>a, .side-navigation.type3 ul.side-nav>li.current_page_item>a:before, .side-navigation.type3 ul.side-nav>li:hover>a, .side-navigation.type3 ul.side-nav>li:hover>a:before, .elementor-element.contact-info .elementor-icon-box-title, .elementor-element.contact-info .elementor-icon-box-icon span, .elementor-element.contact-info .elementor-icon-box-content .elementor-icon-box-description a:hover, .side-navigation.type4 ul.side-nav li.current_page_item a, .side-navigation.type4 ul.side-nav li:hover a, .blog-single-entry.post-custom-classic .entry-categories a, .blog-single-entry.post-custom-classic .entry-meta-group .entry-author a:hover, .dt-sc-content-overlay-style.dt-sc-post-entry .blog-entry:hover .entry-title h4 a, .post-nav-container.type3 div:hover *,

			body .blog-single-entry ul li .comment-body .comment-author a:hover, body .blog-single-entry ul li .comment-body .comment-content a:hover, .dtportfolio-item .details-holder .categories a, .dtportfolio-item .details-holder h2:hover a, .woocommerce .woocommerce-MyAccount-content a:not(.button):hover,

			.secondary-sidebar .widget ul li > a:hover, .secondary-sidebar .widget ul li > span > a:hover, .secondary-sidebar .widget .recent-posts-widget li .entry-title h4 a:hover, .secondary-sidebar .widget .recent-posts-widget li .entry-meta a:hover, .dt-sc-post-entry.dt-sc-content-overlay-style .blog-entry .entry-button a.dt-sc-button:hover,

			.header-contact-info .elementor-icon-box-wrapper .elementor-icon-box-content .elementor-icon-box-description a:hover, .comment-metadata a:hover, .woocommerce.single-product div.product form.cart div.quantity:not(.quantity-with-plusminus) > a > i:hover, .woocommerce .product .summary .product_meta > span a:hover, .commententries .nav-links > div a:hover, .blog-single-entry .entry-body tbody th a:hover, ul.time-table > li:hover > span, ul.time-table > li.selected > span, .dt-sc-service-item:hover .service-details h3 a, .dt-sc-person-item:hover .person-details h3 a, .woocommerce-checkout #payment ul.payment_methods li a:hover, .woocommerce-MyAccount-navigation > ul li a:hover, .menu-item .active-tab .jet-tabs__label-text, .mobile-menu .menu-item .active-tab .jet-tabs__label-text, .dt-sc-iconbox-wrapper:hover .dt-sc-iconbox-description h3 a { color:#ffa35a; }.dt-skin-secondary-bg, div[class*="dt-skin-secondary-bg-opaque"] .upb_row_bg:before, section[class*="dt-skin-secondary-bg-opaque"]:before, input[type="submit"]:hover, input[type="button"]:hover, input[type="reset"]:hover, button[type="button"]:hover, .button:hover, a.button:hover, .mz-blog .comments a:hover, .mz-blog div.vc_gitem-post-category-name:hover,  .dt-sc-infinite-portfolio-load-more:hover,.side-navigation.type2 ul.side-nav li a:before, .side-navigation.type2 ul.side-nav > li.current_page_item > a:before, .side-navigation.type2 ul.side-nav > li > ul > li.current_page_item > a:before, .side-navigation.type2 ul.side-nav > li > ul > li > ul > li.current_page_item > a:before, .slick-dots li, .dt-related-carousel .carousel-pager > a, .dt-related-carousel div[class*=carousel-] > div:hover, #wpsl-stores li > p ~ .wpsl-directions:hover, /* New */ .intro-section .elementor-column-wrap.elementor-element-populated .elementor-widget-button a.elementor-button:hover, .dt-sc-button:hover, .dt-sc-button:focus, div[class*="entry-"].dt-sc-content-overlay-style.dt-sc-post-entry .blog-entry div.entry-meta-group > div:not(:last-child):before, ul.time-table > li ul.time-slots > li a:hover, ul.time-table > li ul.time-slots > li a.selected, ul.time-table > li ul.time-slots > li a.selected:hover, ul.time-slots > li a:hover, .dt-sc-schedule-progress.dt-sc-current-step .dt-sc-progress-step span,

			.dt-sc-post-entry .blog-entry .entry-button a.dt-sc-button:hover, .dt-sc-overlap-style.dt-sc-post-entry .blog-entry .entry-format a:hover:after, .dt-sc-content-overlay-style.dt-sc-post-entry .blog-entry > div.entry-author > a, .dt-sc-content-overlay-style.dt-sc-post-entry .blog-entry > div.entry-likes-views .dt-sc-like-views > div, .dt-sc-content-overlay-style.dt-sc-post-entry .blog-entry div.entry-comments > a, .dt-sc-content-overlay-style.dt-sc-post-entry .blog-entry div.entry-categories a:hover, .dt-sc-content-overlay-style.dt-sc-post-entry .blog-entry div.entry-likes-views .dt-sc-like-views > div, .dt-sc-content-overlay-style.dt-sc-post-entry .blog-entry div.entry-author a, .dt-sc-simple-withbg-style.dt-sc-post-entry .blog-entry .entry-button a.dt-sc-button:hover, .dt-sc-mobilephone-style.dt-sc-post-entry.entry-cover-layout .blog-entry div.entry-format a, .dt-sc-mobilephone-style.dt-sc-post-entry.entry-cover-layout .blog-entry.sticky div.entry-format a, .dt-sc-mobilephone-style.dt-sc-post-entry.entry-cover-layout .blog-entry .entry-button a.dt-sc-button:hover, div.dt-sc-posts-meta-group[class*="metagroup-elements-filled"] div[class*="entry-"]:hover, article[class*="post-custom"].blog-single-entry div.dt-sc-posts-meta-group[class*="metagroup-elements-filled"] .entry-social-share .share > i, .blog-single-entry.post-overlay div[class*="meta-elements-"].entry-social-share:hover .share i, .blog-single-entry.post-overlay div[class*="meta-elements-filled"].entry-social-share .share i, .blog-single-entry.post-overlap div[class*="meta-elements-"].entry-social-share:hover .share i, .blog-single-entry.post-overlap div[class*="meta-elements-filled"].entry-social-share .share i, article[class*="custom-"].blog-single-entry div[class*="meta-elements-"].entry-social-share .share i, .elementor-button.dt-elementor-button:hover, .elementor-button.dt-elementor-button.dt-bordered:hover, #toTop, .dt-sc-header-icons-list > div.search-item .dt-sc-search-form-container.search-overlay .dt-sc-search-overlay-form-close:hover, .elementor-element.elementor-widget-button .elementor-widget-container a.elementor-button:hover, inputinput[type="submit"]:hover, input[type="button"]:hover, input[type="reset"]:hover, button[type="button"]:hover, .button:hover, a.button:hover, span#toTopHover,

			#searchform:hover:before, .wp-block-button:not(.is-style-outline) .wp-block-button__link:hover, .tagcloud a:hover { background-color:#ffa35a; }.woocommerce ul.products li.product .product-buttons-wrapper.product-button .wc_inline_buttons .wc_btn_inline, .woocommerce ul.products li.product .product-buttons-wrapper.product-icons a, .woocommerce ul.products li.product .product-buttons-wrapper.product-icons button, .woocommerce ul.products li.product .product-buttons-wrapper.product-icons .button, .woocommerce ul.products li.product .product-buttons-wrapper.product-icons a.button,

			.woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, .woocommerce #respond input#submit.alt, .woocommerce .wishlist_table .add_to_cart.button, .woocommerce .yith-wcwl-popup-button a.add_to_wishlist, .woocommerce .wishlist_table a.ask-an-estimate-button, .woocommerce .wishlist-title a.show-title-form, .woocommerce .hidden-title-form a.hide-title-form, .woocommerce .yith-wcwl-wishlist-new button, .woocommerce .wishlist_manage_table a.create-new-wishlist, .woocommerce .wishlist_manage_table button.submit-wishlist-changes, .woocommerce .yith-wcwl-wishlist-search-form button.wishlist-search-button, .woocommerce .cart input.button, .woocommerce .shop_table th, .woocommerce div.product .woocommerce-tabs ul.tabs li.active a:after, .woocommerce-page a.button, .woocommerce-page button.button, .woocommerce-page button, .woocommerce-page input.button, .woocommerce-page input[type=button], .woocommerce-page input[type=submit], .woocommerce-page #respond input#submit,
			.woocommerce-page a.button.alt, .woocommerce-page button.button.alt, .woocommerce-page input.button.alt, .woocommerce-page #respond input#submit.alt, .woocommerce-page .wishlist_table .add_to_cart.button, .woocommerce-page .yith-wcwl-popup-button a.add_to_wishlist, .woocommerce-page .wishlist_table a.ask-an-estimate-button, .woocommerce-page .wishlist-title a.show-title-form, .woocommerce-page .hidden-title-form a.hide-title-form, .woocommerce-page .yith-wcwl-wishlist-new button, .woocommerce-page .wishlist_manage_table a.create-new-wishlist, .woocommerce-page .wishlist_manage_table button.submit-wishlist-changes, .woocommerce-page .yith-wcwl-wishlist-search-form button.wishlist-search-button, .woocommerce-page .cart input.button,

			.woocommerce-page .shop_table th, .woocommerce-page div.product .woocommerce-tabs ul.tabs li.active a:after, .woocommerce ul.products li.product .featured-tag, .woocommerce ul.products li.product:hover .featured-tag, .woocommerce.single-product .featured-tag, .woocommerce .widget_price_filter .price_slider_wrapper .ui-widget-content, .woocommerce ul.products li.product .dt-default .product-buttons-wrapper .wc_inline_buttons > .wc_btn_inline a:hover, .woocommerce .view-mode a:hover, .woocommerce .view-mode a.active, .swiper-button-prev, .swiper-button-next, .woocommerce ul.products li.product .dt-default .product-buttons-wrapper a.added_to_cart.wc-forward,

			.woocommerce .product .summary a.button:hover, .woocommerce .product .summary button.button:hover,
			.woocommerce .product .summary button:hover, .woocommerce .product .summary .button:hover,
			.woocommerce .product .summary .compare:hover, .woocommerce .product .summary .dt-wcsg-button:hover,
			.woocommerce .product .summary .yith-wcqv-button:hover, .woocommerce .product .summary .yith-wcwl-add-to-wishlist a:hover,

			.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-skin-bgfill .wc_btn_inline a,
			.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-skin-bgfill .wc_btn_inline a.button,
			.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-skin-bgfill .wc_btn_inline button,
			.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-skin-bgfill .wc_btn_inline button.button,
			.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-skin-bgfill .wc_btn_inline .button.alt,
			.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-skin-bgfill .wc_btn_inline .button.disabled,
			.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-skin-bgfill .wc_btn_inline .button[disabled],
			.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-skin-bgfill .wc_btn_inline .button.alt.disabled,
			.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-skin-bgfill .wc_btn_inline .button.alt[disabled],

			.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-bgfill .wc_btn_inline a:hover,
			.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-bgfill .wc_btn_inline a.button:hover,
			.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-bgfill .wc_btn_inline button:hover,
			.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-bgfill .wc_btn_inline button.button:hover,
			.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-bgfill .wc_btn_inline .button.alt:hover,
			.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-bgfill .wc_btn_inline .button.disabled:hover,
			.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-bgfill .wc_btn_inline .button[disabled]:hover,
			.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-bgfill .wc_btn_inline .button.alt.disabled:hover,
			.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.style-bgfill .wc_btn_inline .button.alt[disabled]:hover,

			.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.product-button.style-bgfill.hide-button-text .compare:hover,
			.woocommerce .product .dt-sc-product-summary .product-buttons-wrapper.product-button.style-bgfill.hide-button-text .yith-wcwl-add-to-wishlist a:hover,

			.woocommerce .product .dt-sc-product-summary .dt-sc-single-product-share-container.style-bgfill .dt-sc-single-product-share-list li a:hover,
			.woocommerce .product .dt-sc-product-summary .dt-sc-single-product-follow-container.style-bgfill .dt-sc-single-product-follow-list li a:hover,

			.dt-sc-single-product-share-container.style-bgfill .dt-sc-single-product-share-list li a:hover,
			.dt-sc-single-product-follow-container.style-bgfill .dt-sc-single-product-follow-list li a:hover,

			.dt-sc-single-product-share-container.style-skin-bgfill .dt-sc-single-product-share-list li a,
			.dt-sc-single-product-follow-container.style-skin-bgfill .dt-sc-single-product-follow-list li a,

			.woocommerce div.product .dt-sc-product-tabs .woocommerce-tabs ul.tabs li a:before, .woocommerce div.product .dt-sc-product-tabs .woocommerce-tabs ul.tabs li a:after,

			.woocommerce .product > .summary form.cart div.quantity ~ .single_add_to_cart_button:hover, .dt-sc-shop-single-sticky-addtocart-section a.added_to_cart.wc-forward, .woocommerce-page .woocommerce .dt-sc-cart-coupon-holder .coupon .button:hover, .woocommerce-page .woocommerce .cart-collaterals .cart_totals .wc-proceed-to-checkout a:hover, .woocommerce-account .woocommerce .woocommerce-MyAccount-content button:hover, .woocommerce form.login .button:hover, .woocommerce .wishlist_table td.product-add-to-cart a:hover, .woocommerce .cart-collaterals table.shop_table tr td .woocommerce-shipping-calculator button:hover, .woocommerce-checkout-header .woocommerce-checkout-header-coupon .checkout_coupon .form-row-last .button:hover, .woocommerce-checkout #payment div.form-row.place-order > #place_order:hover,

			.dt-sc-shop-menu-icon ul.cart_list li a.remove:hover,
			.dt-sc-product-pagination ul li a:hover, .dt-sc-product-pagination ul li span.current,
			.dt-sc-product-pagination .prev-post a:hover, .dt-sc-product-pagination .next-post a:hover,

			.woocommerce ul.products.dt-redart-layout[class*="product-thumb-iconsgroup-style-skinbgfill"] li.product .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline a:after,
			.woocommerce ul.products.dt-redart-layout[class*="product-thumb-iconsgroup-style-skinbgfill"] li.product .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline a.button:after,
			.woocommerce ul.products.dt-redart-layout[class*="product-thumb-iconsgroup-style-skinbgfill"] li.product .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline button:after,
			.woocommerce ul.products.dt-redart-layout[class*="product-thumb-iconsgroup-style-skinbgfill"] li.product .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline button.button:after,
			.woocommerce ul.products.dt-redart-layout[class*="product-thumb-iconsgroup-style-skinbgfill"] li.product .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline .button:after,

			.woocommerce ul.products.dt-petworld-layout[class*="product-thumb-iconsgroup-style-skinbgfill"] li.product .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline a:hover,
			.woocommerce ul.products.dt-petworld-layout[class*="product-thumb-iconsgroup-style-skinbgfill"] li.product .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline a.button:hover,
			.woocommerce ul.products.dt-petworld-layout[class*="product-thumb-iconsgroup-style-skinbgfill"] li.product .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline button:hover,
			.woocommerce ul.products.dt-petworld-layout[class*="product-thumb-iconsgroup-style-skinbgfill"] li.product .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline button.button:hover,
			.woocommerce ul.products.dt-petworld-layout[class*="product-thumb-iconsgroup-style-skinbgfill"] li.product .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline .button:hover,

			.woocommerce ul.products.dt-spalab-layout[class*="product-content-iconsgroup-style-skinbrdrfill"] li.product .product-details .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline a:hover:after,
			.woocommerce ul.products.dt-spalab-layout[class*="product-content-iconsgroup-style-skinbrdrfill"] li.product .product-details .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline a.button:hover:after,
			.woocommerce ul.products.dt-spalab-layout[class*="product-content-iconsgroup-style-skinbrdrfill"] li.product .product-details .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline button:hover:after,
			.woocommerce ul.products.dt-spalab-layout[class*="product-content-iconsgroup-style-skinbrdrfill"] li.product .product-details .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline button.button:hover:after,
			.woocommerce ul.products.dt-spalab-layout[class*="product-content-iconsgroup-style-skinbrdrfill"] li.product .product-details .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline .button:hover:after,

			.woocommerce ul.products.dt-hifashion-layout li.product:hover .product-wrapper .product-details .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline a,
			.woocommerce ul.products.dt-hifashion-layout li.product:hover .product-wrapper .product-details .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline a.button,
			.woocommerce ul.products.dt-hifashion-layout li.product:hover .product-wrapper .product-details .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline button,
			.woocommerce ul.products.dt-hifashion-layout li.product:hover .product-wrapper .product-details .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline button.button,
			.woocommerce ul.products.dt-hifashion-layout li.product:hover .product-wrapper .product-details .product-buttons-wrapper.product-icons .wc_inline_buttons > .wc_btn_inline .button,

			.woocommerce ul.products.dt-petworld-layout li.product .product-price .price,

			.woocommerce ul.products.dt-breezewedding-layout li.product .product-thumb-content .product-element-group-wrapper .product-title h5 a,
			.woocommerce ul.products.dt-breezewedding-layout li.product .product-thumb-content .product-element-group-wrapper .product-price, .woocommerce-cart-form .actions.dt-sc-cart-button button:hover, .dt-sc-product-summary .product-buttons-wrapper.style-simple form.cart div.quantity ~ button, .dt-sc-product-summary .product-buttons-wrapper.style-simple form.cart div.quantity ~ button.button, .dt-sc-product-summary .product-buttons-wrapper.style-simple form.cart div.quantity ~ .button:hover, .dt-sc-product-summary .product-buttons-wrapper.style-simple form.cart div.quantity ~ .button.alt:hover { background-color:#ffa35a; }.woocommerce ul.products.dt-augury-default li.product .product-thumb .product-buttons-wrapper.product-icons a:hover,
			.woocommerce ul.products.dt-augury-default li.product .product-thumb .product-buttons-wrapper.product-icons a.button:hover,
			.woocommerce ul.products.dt-augury-default li.product .product-thumb .product-buttons-wrapper.product-icons button:hover,
			.woocommerce ul.products.dt-augury-default li.product .product-thumb .product-buttons-wrapper.product-icons button.button:hover,
			.woocommerce ul.products.dt-augury-default li.product .product-thumb .product-buttons-wrapper.product-icons .button:hover,

			.woocommerce ul.products.dt-augury-default[class*="product-content-buttonelement-style-brdrfill"] li.product .product-details .product-buttons-wrapper.product-button .wc_btn_inline:hover { background-color:#ffa35a !important; }.dt-sc-simple-style.dt-sc-post-entry .blog-entry:hover .entry-button a.dt-sc-button:hover span, .elementor-element.our-services-box:hover .elementor-button-wrapper a.elementor-button, .dt-advanced-carousel-item-wrapper.slick-current.slick-active .testimonial-wrapper .author-name .elementor-heading-title:after, .dt-advanced-carousel-item-wrapper .testimonial-wrapper:hover .author-name .elementor-heading-title:after, .elementor-element .elementor-jet-pricing-table .pricing-table:hover .pricing-table__action a, .pagination a.loadmore-btn.more-items:hover { background-color:#ffa35a; }.dt-skin-secondary-border, .side-navigation.type5 ul.side-nav, .side-navigation.type5 ul.side-nav li a, .side-navigation.type5 ul.side-nav li ul, /* New */ .intro-section .elementor-column-wrap.elementor-element-populated:hover .elementor-widget-button a.elementor-button, .dt-sc-simple-style.dt-sc-post-entry .blog-entry:hover .entry-button a.dt-sc-button span,.active-centered .dt-sc-simple-style.dt-sc-post-entry.entry-grid-layout:nth-child(3) .blog-entry .entry-button a.dt-sc-button span, .fullwidth-icon-carousel .elementor-column-gap-extended>.elementor-row>.elementor-column>.elementor-element-populated .elementor-widget-button a.elementor-button:hover, .fullwidth-icon-carousel .elementor-column-gap-extended>.elementor-row>.elementor-column>.elementor-element-populated:hover .elementor-widget-button a.elementor-button, .elementor-button.dt-elementor-button.dt-bordered:hover, .elementor-element.elementor-widget-button .elementor-widget-container a.elementor-button:hover, input[type="submit"]:hover, input[type="button"]:hover, input[type="reset"]:hover, button[type="button"]:hover, .button:hover, a.button:hover, .no-header-menu ul li ul.children, .dt-header-menu ul.dt-primary-nav li ul.sub-menu, .woocommerce ul.products.dt-augury-default[class*="product-content-buttonelement-style-brdrfill"] li.product .product-details .product-buttons-wrapper.product-button .wc_btn_inline:hover, .widget #searchform:hover input[type="submit"], .dt-sc-product-summary .product-buttons-wrapper.style-simple form.cart div.quantity ~ button, .dt-sc-product-summary .product-buttons-wrapper.style-simple form.cart div.quantity ~ button.button, .dt-sc-product-summary .product-buttons-wrapper.style-simple form.cart div.quantity ~ .button:hover, .dt-sc-product-summary .product-buttons-wrapper.style-simple form.cart div.quantity ~ .button.alt:hover, .woocommerce .product .summary .product-button.style-simple .yith-wcwl-add-to-wishlist a:hover, .dt-sc-product-summary .product-buttons-wrapper.style-simple .wc_btn_inline a:hover, .dt-sc-product-summary .product-buttons-wrapper.style-simple .wc_btn_inline a.button:hover, .woocommerce .product .summary .product-button.style-simple .yith-wcwl-add-to-wishlist a:hover, .dt-sc-product-summary .product-buttons-wrapper.style-simple .wc_btn_inline a:hover, .dt-sc-product-summary .product-buttons-wrapper.style-simple .wc_btn_inline a.button:hover, .woocommerce #review_form #respond .form-submit input:hover, .dt-sc-button:hover, .dt-sc-button:focus, .dt-sc-schedule-progress.dt-sc-current-step .dt-sc-progress-step span, .loadmore-btn.more-items:hover, .woocommerce.single-product .images .featured-tag:after, .dt-sc-product-image-gallery-container .featured-tag:after { border-color:#ffa35a; }.error404 .type2 a.dt-sc-back:hover { background-color:#ffa35a; }#item-header-content #item-meta > #item-buttons .group-button:hover, #buddypress .activity-list li.load-more a:hover, #buddypress .activity-list li.load-newest a:hover { background-color:#ffa35a; }#bbpress-forums #subscription-toggle a.subscription-toggle:hover, .bbp-submit-wrapper #bbp_topic_submit:hover { background-color:#ffa35a; }#tribe-bar-form .tribe-bar-submit input[type="submit"]:hover, .tribe-events-read-more:hover, #tribe-events .tribe-events-button:hover, .tribe-events-button:hover, .tribe-events-back > a:hover, .datepicker thead tr:first-child th:hover, .datepicker tfoot tr th:hover, #tribe_events_filters_toggle:hover, .tribe-events-grid .tribe-grid-header .tribe-week-today, .tribe-grid-body div[id*="tribe-events-event-"]:hover { background-color:#ffa35a; }.tribe-grid-header .tribe-week-today { background-color:#ffa35a; }.woocommerce ul.products li.product .product-buttons-wrapper.product-icons .wc_inline_buttons .wc_btn_inline a:hover, .woocommerce ul.products li.product .product-buttons-wrapper.product-icons .wc_inline_buttons .wc_btn_inline button:hover,

				.woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce button:hover, .woocommerce input.button:hover, .woocommerce input[type=button]:hover, .woocommerce input[type=submit]:hover, .woocommerce #respond input#submit:hover,

				.woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce input.button.alt:hover, .woocommerce #respond input#submit.alt:hover, .woocommerce .wishlist_table .add_to_cart.button:hover, .woocommerce .yith-wcwl-popup-button a.add_to_wishlist:hover, .woocommerce .wishlist_table a.ask-an-estimate-button:hover, .woocommerce .wishlist-title a.show-title-form:hover, .woocommerce .hidden-title-form a.hide-title-form:hover, .woocommerce .yith-wcwl-wishlist-new button:hover, .woocommerce .wishlist_manage_table a.create-new-wishlist:hover, .woocommerce .wishlist_manage_table button.submit-wishlist-changes:hover, .woocommerce .yith-wcwl-wishlist-search-form button.wishlist-search-button:hover, .woocommerce .cart input.button:hover,

				.woocommerce-page a.button:hover, .woocommerce-page button.button:hover, .woocommerce-page button:hover, .woocommerce-page input.button:hover, .woocommerce-page input[type=button]:hover, .woocommerce-page input[type=submit]:hover, .woocommerce-page #respond input#submit:hover, .woocommerce-page a.button.alt:hover, .woocommerce-page button.button.alt:hover, .woocommerce-page input.button.alt:hover, .woocommerce-page #respond input#submit.alt:hover, .woocommerce-page .wishlist_table .add_to_cart.button:hover, .woocommerce-page .yith-wcwl-popup-button a.add_to_wishlist:hover, .woocommerce-page .wishlist_table a.ask-an-estimate-button:hover, .woocommerce-page .wishlist-title a.show-title-form:hover, .woocommerce-page .hidden-title-form a.hide-title-form:hover, .woocommerce-page .yith-wcwl-wishlist-new button:hover, .woocommerce-page .wishlist_manage_table a.create-new-wishlist:hover, .woocommerce-page .wishlist_manage_table button.submit-wishlist-changes:hover, .woocommerce-page .yith-wcwl-wishlist-search-form button.wishlist-search-button:hover, .woocommerce-page .cart input.button:hover,

				.woocommerce a.button.disabled:hover, .woocommerce a.button:disabled:hover, .woocommerce a.button:disabled[disabled]:hover, .woocommerce button.button.disabled:hover, .woocommerce button.button:disabled:hover, .woocommerce button.button:disabled[disabled]:hover, .woocommerce input.button.disabled:hover, .woocommerce input.button:disabled:hover, .woocommerce input.button:disabled[disabled]:hover, .woocommerce #respond input#submit.disabled:hover, .woocommerce #respond input#submit:disabled:hover, .woocommerce #respond input#submit:disabled[disabled]:hover,

				.woocommerce a.button.alt.disabled, .woocommerce a.button.alt[disabled]:disabled, .woocommerce button.button.alt.disabled, .woocommerce button.button.alt:disabled, .woocommerce button.button.alt[disabled]:disabled, .woocommerce input.button.alt.disabled, .woocommerce input.button.alt:disabled, .woocommerce input.button.alt[disabled]:disabled, .woocommerce #respond input#submit.alt.disabled, .woocommerce #respond input#submit.alt:disabled, .woocommerce #respond input#submit.alt[disabled]:disabled,

				.woocommerce a.button.alt.disabled:hover, .woocommerce a.button.alt[disabled]:disabled:hover, .woocommerce button.button.alt.disabled:hover, .woocommerce button.button.alt:disabled:hover, .woocommerce button.button.alt[disabled]:disabled:hover, .woocommerce input.button.alt.disabled:hover, .woocommerce input.button.alt:disabled:hover, .woocommerce input.button.alt[disabled]:disabled:hover, .woocommerce #respond input#submit.alt.disabled:hover, .woocommerce #respond input#submit.alt:disabled:hover, .woocommerce #respond input#submit.alt[disabled]:disabled:hover, .commentlist li.comment .reply a:hover { background-color:#ffa35a; }.our-services-box:hover .elementor-button-wrapper a.elementor-button, .elementor-element .header-author .elementor-image a:hover img, .woocommerce ul.products.product-overlay-dark-bgcolor[class*="product-thumb-iconsgroup-style-brdrfill"] li.product .product-thumb .product-buttons-wrapper.product-icons a:hover, .commentlist li.comment .reply a:hover { border-color:#ffa35a; }.dt-skin-tertiary-color { color:#ffffff; }.elementor-widget-icon-box.elementor-view-stacked.ico-type1.alter .elementor-icon, .elementor-widget-image-box.ico-type1.alter .elementor-image-box-img { background-color:#ffffff; }.dt-skin-tertiary-border { border-color:#ffffff; }.dt-skin-tertiary-bg, div[class*="dt-skin-tertiary-bg-opaque"] .upb_row_bg:before, section[class*="dt-skin-tertiary-bg-opaque"]:before, .side-navigation.type1 ul.side-nav > li.current_page_item > a, .side-navigation.type1 ul.side-nav > li > ul > li.current_page_item > a, .side-navigation.type1 ul.side-nav > li > ul > li > ul > li.current_page_item > a, .dt-sc-shop-single-sticky-addtocart-section a.added_to_cart.wc-forward:hover { background-color:#ffffff; }.dt-skin-tertiary-border, .elementor-widget-dt-counter .dt-sc-counter-wrapper.type2 .dt-sc-counter-inner { border-color:#ffffff; }
</style>
<style id='augury-customiser-inline-inline-css' type='text/css'>
body, .woocommerce ul.products li .product-wrapper, .woocommerce-tabs .panel, .select2-results, .woocommerce table .quantity .qty, .select2-dropdown .select2-search .select2-search__field, .dt-sc-schedule-progress .dt-sc-progress-step span, .dt-sc-goback-box .appointment-goback { background-color:#030303;}
body { color:#a3a1a1;}
a { color:#ffffff;}
a:hover { color:#ffa35a;}
body {font-family:Josefin Sans,'Josefin Sans', sans-serif;font-weight:300;font-style:normal;text-transform:none;font-size:25px;line-height:36px;}
.no-header-menu ul li a, .dt-header-menu .dt-primary-nav li a { color:#ffffff;}
h1 { color:#ffffff;}
h2 { color:#ffffff;}
h3 { color:#ffffff;}
h4 { color:#ffffff;}
h5 { color:#ffffff;}
h6 { color:#ffffff;}
.no-header-menu ul li a, .dt-header-menu .dt-primary-nav li a {font-family:Josefin Sans,'Josefin Sans', sans-serif;font-weight:600;font-style:normal;text-transform:uppercase;font-size:15px;}
h1 {font-family:Josefin Sans,'Josefin Sans', sans-serif;font-weight:600;font-style:normal;font-size:60px;line-height:1.5em;}
h2 {font-family:Josefin Sans,'Josefin Sans', sans-serif;font-weight:600;font-style:normal;font-size:55px;line-height:68px;}
h3 {font-family:Josefin Sans,'Josefin Sans', sans-serif;font-weight:600;font-style:normal;font-size:38px;}
h4 {font-family:Josefin Sans,'Josefin Sans', sans-serif;font-weight:400;font-style:normal;font-size:28px;}
h5 {font-family:Josefin Sans,'Josefin Sans', sans-serif;font-weight:700;font-style:normal;font-size:22px;}
h6 {font-family:Josefin Sans,'Josefin Sans', sans-serif;font-weight:700;font-style:normal;font-size:18px;}
input[type="text"], input[type="password"], input[type="email"], input[type="url"], input[type="tel"], input[type="number"], input[type="range"], input[type="date"], textarea, input.text, input[type="search"], select, textarea, .form-calender-icon input[type="text"], .select2-container--default .select2-selection--single .select2-selection__rendered, .select2-container--default .select2-selection--single .select2-selection__placeholder{font-family:Josefin Sans,'Josefin Sans', sans-serif;font-weight:400;font-style:normal;}
#main-menu ul.menu > li > a, .dt-sc-portfolio-sorting a, .minimal .dt-sc-price p, .dt-sc-bar-text, .pagination, .dt-sc-any-carousel-wrapper .swiper-slide .dt-swiper-content-title, .dt-sc-any-carousel-wrapper .slick-slide .dt-slick-content-title, .woocommerce div.product .dt-sc-product-tabs .woocommerce-tabs ul.tabs li a, .woocommerce #review_form #respond .comment-reply-title{font-family:Josefin Sans,'Josefin Sans', sans-serif;font-weight:700;font-style:normal;}
.secondary-sidebar .widgettitle, .secondary-sidebar .widgettitle > a, .secondary-sidebar .type2 .widgettitle, .secondary-sidebar .type10 .widgettitle, .secondary-sidebar .type10 .widgettitle > a, .secondary-sidebar .type17 .widget-title-wrapper .widget-title-content h2, .secondary-sidebar .type17 .widget-title-content h3.widgettitle, .secondary-sidebar .type17 .widget-title-content h3.widgettitle > a, .secondary-sidebar .type14 .widgettitle, .secondary-sidebar .type15 .widgettitle, .mz-stripe-title .mz-stripe-title-content h3.widgettitle { color:#ffffff }
.secondary-sidebar .widget { color:#ffffff;}
.secondary-sidebar .widget ul li > a, .secondary-sidebar .widget ul li > span > a, .secondary-sidebar .widget .recent-posts-widget li .entry-title h4 a, .secondary-sidebar .widget .recent-posts-widget li .entry-meta a { color:#ffffff;}
.secondary-sidebar .widget ul li > a:hover, .secondary-sidebar .widget ul li > span > a:hover, .secondary-sidebar .widget .recent-posts-widget li .entry-title h4 a:hover, .secondary-sidebar .widget .recent-posts-widget li .entry-meta a:hover { color:#ffa35a;}
.secondary-sidebar .widgettitle {font-family:Josefin Sans,'Josefin Sans', sans-serif;font-weight:600;font-style:normal;}
.secondary-sidebar .widget{font-family:Josefin Sans,'Josefin Sans', sans-serif;font-weight:300;font-style:normal;}
div.footer-widgets .widgettitle, #footer .widgettitle { color:#ffffff;}
#footer, .footer-copyright, div.footer-widgets .widget { color:#ffffff;}
.footer-widgets a, #footer a { color:#ffffff;}
.footer-widgets a:hover, #footer a:hover { color:#000000;}
div.footer-widgets .widgettitle, #footer .widgettitle {font-family:Josefin Sans,'Josefin Sans', sans-serif;font-weight:700;font-style:normal;font-size:25px;line-height:36px;}
#footer, .footer-copyright, div.footer-widgets .widget {font-family:Josefin Sans,'Josefin Sans', sans-serif;font-weight:300;font-style:normal;font-size:25px;line-height:36px;}
.site-title {font-family:Josefin Sans,'Josefin Sans', sans-serif;font-weight:600;font-style:normal;font-size:36px;line-height:60px;}
.site-tag-line {font-family:Josefin Sans,'Josefin Sans', sans-serif;font-weight:400;font-style:normal;}
.main-title-section-wrapper .main-title-section-bg {background-image: url(https://dtaugury.wpengine.com/wp-content/uploads/2020/01/breadcrumb.jpg);background-position:center center;background-size:auto;background-repeat:no-repeat;background-attachment:scroll;}.main-title-section-wrapper .main-title-section-bg:after { background-color:rgba(0,0,0,0)}
.main-title-section h1, .dark-bg-breadcrumb .main-title-section h1 { color:#ffffff;}.breadcrumb span.current, .dark-bg-breadcrumb .breadcrumb span.current { color:#ffffff;}.breadcrumb a, .dark-bg-breadcrumb .breadcrumb a, .dark-bg-breadcrumb .breadcrumb span:not(.current) { color:#ffffff;}.breadcrumb a:hover, .dark-bg-breadcrumb .breadcrumb a:hover { color:#ffa35a;}
.main-title-section h1 {font-family:Josefin Sans,'Josefin Sans', sans-serif;font-weight:600;font-style:normal;text-transform:none;font-size:60px;line-height:68px;}
.breadcrumb {font-family:Josefin Sans,'Josefin Sans', sans-serif;font-weight:inherit;font-style:normal;font-size:18px;}

</style>
<link rel='stylesheet' id='052f9f08db4c06ac39b7b026bb6eb41f-css' href='//fonts.googleapis.com/css?family=Josefin+Sans:300&#038;subset=latin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='d2ff107d8548ad953e54e261eba4ae88-css' href='//fonts.googleapis.com/css?family=Josefin+Sans:600&#038;subset=latin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='663106d79f3666b296514044d615e164-css' href='//fonts.googleapis.com/css?family=Josefin+Sans:400&#038;subset=latin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='cbcb0fa46944024be16c50a27c2a69e9-css' href='//fonts.googleapis.com/css?family=Josefin+Sans:700&#038;subset=latin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='aed640b78de56ff408960ee13ed0a313-css' href='//fonts.googleapis.com/css?family=Josefin+Sans&#038;subset=latin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='12eb8c354fb70896a233f5f25c7e399e-css' href='//fonts.googleapis.com/css?family=Josefin+Sans:inherit&#038;subset=latin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css' href='https://fonts.googleapis.com/css?family=Josefin+Sans%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;display=auto&#038;ver=6.3' type='text/css' media='all' />
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin><script type='text/javascript' id='jquery-core-js-extra'>
/* <![CDATA[ */
var dttheme_urls = {"theme_base_url":"https:\/\/dtaugury.wpengine.com\/wp-content\/themes\/augury","framework_base_url":"https:\/\/dtaugury.wpengine.com\/wp-content\/themes\/augury\/framework\/","ajaxurl":"https:\/\/dtaugury.wpengine.com\/wp-admin\/admin-ajax.php","url":"https:\/\/dtaugury.wpengine.com","isRTL":"","loadingbar":"disable","advOptions":"Show Advanced Options","wpnonce":"36ae91b9ca","enable_ajax_addtocart":"","enable_totop":"1","disable_mouse_animation":""};
/* ]]> */
</script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.0' id='jquery-core-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1' id='jquery-migrate-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/modernizr.custom.js?ver=6.3' id='modernizr-custom-js'></script>
<link rel="https://api.w.org/" href="https://dtaugury.wpengine.com/wp-json/" /><link rel="alternate" type="application/json" href="https://dtaugury.wpengine.com/wp-json/wp/v2/pages/20398" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://dtaugury.wpengine.com/xmlrpc.php?rsd" />
<link rel="canonical" href="https://dtaugury.wpengine.com/" />
<link rel='shortlink' href='https://dtaugury.wpengine.com/' />
<link rel="alternate" type="application/json+oembed" href="https://dtaugury.wpengine.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fdtaugury.wpengine.com%2F" />
<link rel="alternate" type="text/xml+oembed" href="https://dtaugury.wpengine.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fdtaugury.wpengine.com%2F&#038;format=xml" />

        <script type="text/javascript">
            var jQueryMigrateHelperHasSentDowngrade = false;

			window.onerror = function( msg, url, line, col, error ) {
				// Break out early, do not processing if a downgrade reqeust was already sent.
				if ( jQueryMigrateHelperHasSentDowngrade ) {
					return true;
                }

				var xhr = new XMLHttpRequest();
				var nonce = 'd0e064d8d0';
				var jQueryFunctions = [
					'andSelf',
					'browser',
					'live',
					'boxModel',
					'support.boxModel',
					'size',
					'swap',
					'clean',
					'sub',
                ];
				var match_pattern = /\)\.(.+?) is not a function/;
                var erroredFunction = msg.match( match_pattern );

                // If there was no matching functions, do not try to downgrade.
                if ( typeof erroredFunction !== 'object' || typeof erroredFunction[1] === "undefined" || -1 === jQueryFunctions.indexOf( erroredFunction[1] ) ) {
                    return true;
                }

                // Set that we've now attempted a downgrade request.
                jQueryMigrateHelperHasSentDowngrade = true;

				xhr.open( 'POST', 'https://dtaugury.wpengine.com/wp-admin/admin-ajax.php' );
				xhr.setRequestHeader( 'Content-Type', 'application/x-www-form-urlencoded' );
				xhr.onload = function () {
					var response,
                        reload = false;

					if ( 200 === xhr.status ) {
                        try {
                        	response = JSON.parse( xhr.response );

                        	reload = response.data.reload;
                        } catch ( e ) {
                        	reload = false;
                        }
                    }

					// Automatically reload the page if a deprecation caused an automatic downgrade, ensure visitors get the best possible experience.
					if ( reload ) {
						location.reload();
                    }
				};

				xhr.send( encodeURI( 'action=jquery-migrate-downgrade-version&_wpnonce=' + nonce ) );

				// Suppress error alerts in older browsers
				return true;
			}
        </script>

			<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<meta name="generator" content="Elementor 3.14.1; features: a11y_improvements, additional_custom_breakpoints; settings: css_print_method-external, google_font-enabled, font_display-auto">
<meta name="generator" content="Powered by Slider Revolution 6.6.13 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/cropped-favicon-100x100.png" sizes="32x32" />
<link rel="icon" href="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/cropped-favicon-300x300.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/cropped-favicon-300x300.png" />
<meta name="msapplication-TileImage" content="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/cropped-favicon-300x300.png" />
<script>function setREVStartSize(e){
			//window.requestAnimationFrame(function() {
				window.RSIW = window.RSIW===undefined ? window.innerWidth : window.RSIW;
				window.RSIH = window.RSIH===undefined ? window.innerHeight : window.RSIH;
				try {
					var pw = document.getElementById(e.c).parentNode.offsetWidth,
						newh;
					pw = pw===0 || isNaN(pw) || (e.l=="fullwidth" || e.layout=="fullwidth") ? window.RSIW : pw;
					e.tabw = e.tabw===undefined ? 0 : parseInt(e.tabw);
					e.thumbw = e.thumbw===undefined ? 0 : parseInt(e.thumbw);
					e.tabh = e.tabh===undefined ? 0 : parseInt(e.tabh);
					e.thumbh = e.thumbh===undefined ? 0 : parseInt(e.thumbh);
					e.tabhide = e.tabhide===undefined ? 0 : parseInt(e.tabhide);
					e.thumbhide = e.thumbhide===undefined ? 0 : parseInt(e.thumbhide);
					e.mh = e.mh===undefined || e.mh=="" || e.mh==="auto" ? 0 : parseInt(e.mh,0);
					if(e.layout==="fullscreen" || e.l==="fullscreen")
						newh = Math.max(e.mh,window.RSIH);
					else{
						e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
						for (var i in e.rl) if (e.gw[i]===undefined || e.gw[i]===0) e.gw[i] = e.gw[i-1];
						e.gh = e.el===undefined || e.el==="" || (Array.isArray(e.el) && e.el.length==0)? e.gh : e.el;
						e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
						for (var i in e.rl) if (e.gh[i]===undefined || e.gh[i]===0) e.gh[i] = e.gh[i-1];

						var nl = new Array(e.rl.length),
							ix = 0,
							sl;
						e.tabw = e.tabhide>=pw ? 0 : e.tabw;
						e.thumbw = e.thumbhide>=pw ? 0 : e.thumbw;
						e.tabh = e.tabhide>=pw ? 0 : e.tabh;
						e.thumbh = e.thumbhide>=pw ? 0 : e.thumbh;
						for (var i in e.rl) nl[i] = e.rl[i]<window.RSIW ? 0 : e.rl[i];
						sl = nl[0];
						for (var i in nl) if (sl>nl[i] && nl[i]>0) { sl = nl[i]; ix=i;}
						var m = pw>(e.gw[ix]+e.tabw+e.thumbw) ? 1 : (pw-(e.tabw+e.thumbw)) / (e.gw[ix]);
						newh =  (e.gh[ix] * m) + (e.tabh + e.thumbh);
					}
					var el = document.getElementById(e.c);
					if (el!==null && el) el.style.height = newh+"px";
					el = document.getElementById(e.c+"_wrapper");
					if (el!==null && el) {
						el.style.height = newh+"px";
						el.style.display = "block";
					}
				} catch(e){
					console.log("Failure at Presize of Slider:" + e)
				}
			//});
		  };</script>
<style id='augury-custom-inline-inline-css' type='text/css'>

div#dt-1aab21f img { width:210px;}
@media only screen and (max-width: 767px) {
div#dt-1aab21f img { width:210px; }
}
</style>
<style>.elementor-20488 .elementor-element.elementor-element-39a37cc8 .elementor-repeater-item-7ee6690.jet-parallax-section__layout .jet-parallax-section__image{background-size:auto;}.elementor-20488 .elementor-element.elementor-element-73dfe88f.elementor-position-right .elementor-image-box-img{margin-left:0px;}.elementor-20488 .elementor-element.elementor-element-73dfe88f.elementor-position-left .elementor-image-box-img{margin-right:0px;}.elementor-20488 .elementor-element.elementor-element-73dfe88f.elementor-position-top .elementor-image-box-img{margin-bottom:0px;}.elementor-20488 .elementor-element.elementor-element-73dfe88f .elementor-image-box-wrapper .elementor-image-box-img{width:100%;}.elementor-20488 .elementor-element.elementor-element-73dfe88f .elementor-image-box-img img{transition-duration:0.3s;}.elementor-20488 .elementor-element.elementor-element-73dfe88f .elementor-image-box-title{margin-bottom:20px;color:#000000;font-size:22px;font-weight:600;}.elementor-20488 .elementor-element.elementor-element-73dfe88f .elementor-image-box-description{color:#626161;font-size:15px;font-weight:600;line-height:20px;}.elementor-20488 .elementor-element.elementor-element-73dfe88f > .elementor-widget-container{padding:35px 50px 35px 50px;}.elementor-20488 .elementor-element.elementor-element-7011684d .elementor-button{font-size:20px;fill:#FFFFFF;color:#FFFFFF;background-color:rgba(2, 1, 1, 0);border-style:solid;border-width:2px 2px 2px 2px;border-color:#2A2A2A;border-radius:50px 50px 50px 50px;padding:15px 35px 12px 35px;}.elementor-20488 .elementor-element.elementor-element-7011684d .elementor-button:hover, .elementor-20488 .elementor-element.elementor-element-7011684d .elementor-button:focus{color:#000000;background-color:#FFA35A;}.elementor-20488 .elementor-element.elementor-element-7011684d .elementor-button:hover svg, .elementor-20488 .elementor-element.elementor-element-7011684d .elementor-button:focus svg{fill:#000000;}.elementor-20488 .elementor-element.elementor-element-7011684d > .elementor-widget-container{margin:25px 0px 0px 0px;}@media(max-width:767px){.elementor-20488 .elementor-element.elementor-element-73dfe88f .elementor-image-box-img{margin-bottom:0px;}}</style>
<style>.elementor-25218 .elementor-element.elementor-element-39a37cc8 .elementor-repeater-item-7ee6690.jet-parallax-section__layout .jet-parallax-section__image{background-size:auto;}.elementor-25218 .elementor-element.elementor-element-73dfe88f.elementor-position-right .elementor-image-box-img{margin-left:0px;}.elementor-25218 .elementor-element.elementor-element-73dfe88f.elementor-position-left .elementor-image-box-img{margin-right:0px;}.elementor-25218 .elementor-element.elementor-element-73dfe88f.elementor-position-top .elementor-image-box-img{margin-bottom:0px;}.elementor-25218 .elementor-element.elementor-element-73dfe88f .elementor-image-box-wrapper .elementor-image-box-img{width:100%;}.elementor-25218 .elementor-element.elementor-element-73dfe88f .elementor-image-box-img img{transition-duration:0.3s;}.elementor-25218 .elementor-element.elementor-element-73dfe88f .elementor-image-box-title{margin-bottom:20px;color:#000000;font-size:22px;font-weight:600;}.elementor-25218 .elementor-element.elementor-element-73dfe88f .elementor-image-box-description{color:#626161;font-size:15px;font-weight:600;line-height:20px;}.elementor-25218 .elementor-element.elementor-element-73dfe88f > .elementor-widget-container{padding:35px 50px 35px 50px;}.elementor-25218 .elementor-element.elementor-element-7011684d .elementor-button{font-size:20px;fill:#FFFFFF;color:#FFFFFF;background-color:rgba(2, 1, 1, 0);border-style:solid;border-width:2px 2px 2px 2px;border-color:#2A2A2A;border-radius:50px 50px 50px 50px;padding:15px 35px 12px 35px;}.elementor-25218 .elementor-element.elementor-element-7011684d .elementor-button:hover, .elementor-25218 .elementor-element.elementor-element-7011684d .elementor-button:focus{color:#000000;background-color:#FFA35A;}.elementor-25218 .elementor-element.elementor-element-7011684d .elementor-button:hover svg, .elementor-25218 .elementor-element.elementor-element-7011684d .elementor-button:focus svg{fill:#000000;}.elementor-25218 .elementor-element.elementor-element-7011684d > .elementor-widget-container{margin:25px 0px 0px 0px;}@media(max-width:767px){.elementor-25218 .elementor-element.elementor-element-73dfe88f .elementor-image-box-img{margin-bottom:0px;}}</style>
<style>.elementor-25219 .elementor-element.elementor-element-39a37cc8 .elementor-repeater-item-7ee6690.jet-parallax-section__layout .jet-parallax-section__image{background-size:auto;}.elementor-25219 .elementor-element.elementor-element-73dfe88f.elementor-position-right .elementor-image-box-img{margin-left:0px;}.elementor-25219 .elementor-element.elementor-element-73dfe88f.elementor-position-left .elementor-image-box-img{margin-right:0px;}.elementor-25219 .elementor-element.elementor-element-73dfe88f.elementor-position-top .elementor-image-box-img{margin-bottom:0px;}.elementor-25219 .elementor-element.elementor-element-73dfe88f .elementor-image-box-wrapper .elementor-image-box-img{width:100%;}.elementor-25219 .elementor-element.elementor-element-73dfe88f .elementor-image-box-img img{transition-duration:0.3s;}.elementor-25219 .elementor-element.elementor-element-73dfe88f .elementor-image-box-title{margin-bottom:20px;color:#000000;font-size:22px;font-weight:600;}.elementor-25219 .elementor-element.elementor-element-73dfe88f .elementor-image-box-description{color:#626161;font-size:15px;font-weight:600;line-height:20px;}.elementor-25219 .elementor-element.elementor-element-73dfe88f > .elementor-widget-container{padding:35px 50px 35px 50px;}.elementor-25219 .elementor-element.elementor-element-7011684d .elementor-button{font-size:20px;fill:#FFFFFF;color:#FFFFFF;background-color:rgba(2, 1, 1, 0);border-style:solid;border-width:2px 2px 2px 2px;border-color:#2A2A2A;border-radius:50px 50px 50px 50px;padding:15px 35px 12px 35px;}.elementor-25219 .elementor-element.elementor-element-7011684d .elementor-button:hover, .elementor-25219 .elementor-element.elementor-element-7011684d .elementor-button:focus{color:#000000;background-color:#FFA35A;}.elementor-25219 .elementor-element.elementor-element-7011684d .elementor-button:hover svg, .elementor-25219 .elementor-element.elementor-element-7011684d .elementor-button:focus svg{fill:#000000;}.elementor-25219 .elementor-element.elementor-element-7011684d > .elementor-widget-container{margin:25px 0px 0px 0px;}@media(max-width:767px){.elementor-25219 .elementor-element.elementor-element-73dfe88f .elementor-image-box-img{margin-bottom:0px;}}</style>
<style>.elementor-25220 .elementor-element.elementor-element-39a37cc8 .elementor-repeater-item-7ee6690.jet-parallax-section__layout .jet-parallax-section__image{background-size:auto;}.elementor-25220 .elementor-element.elementor-element-73dfe88f.elementor-position-right .elementor-image-box-img{margin-left:0px;}.elementor-25220 .elementor-element.elementor-element-73dfe88f.elementor-position-left .elementor-image-box-img{margin-right:0px;}.elementor-25220 .elementor-element.elementor-element-73dfe88f.elementor-position-top .elementor-image-box-img{margin-bottom:0px;}.elementor-25220 .elementor-element.elementor-element-73dfe88f .elementor-image-box-wrapper .elementor-image-box-img{width:100%;}.elementor-25220 .elementor-element.elementor-element-73dfe88f .elementor-image-box-img img{transition-duration:0.3s;}.elementor-25220 .elementor-element.elementor-element-73dfe88f .elementor-image-box-title{margin-bottom:20px;color:#000000;font-size:22px;font-weight:600;}.elementor-25220 .elementor-element.elementor-element-73dfe88f .elementor-image-box-description{color:#626161;font-size:15px;font-weight:600;line-height:20px;}.elementor-25220 .elementor-element.elementor-element-73dfe88f > .elementor-widget-container{padding:35px 50px 35px 50px;}.elementor-25220 .elementor-element.elementor-element-7011684d .elementor-button{font-size:20px;fill:#FFFFFF;color:#FFFFFF;background-color:rgba(2, 1, 1, 0);border-style:solid;border-width:2px 2px 2px 2px;border-color:#2A2A2A;border-radius:50px 50px 50px 50px;padding:15px 35px 12px 35px;}.elementor-25220 .elementor-element.elementor-element-7011684d .elementor-button:hover, .elementor-25220 .elementor-element.elementor-element-7011684d .elementor-button:focus{color:#000000;background-color:#FFA35A;}.elementor-25220 .elementor-element.elementor-element-7011684d .elementor-button:hover svg, .elementor-25220 .elementor-element.elementor-element-7011684d .elementor-button:focus svg{fill:#000000;}.elementor-25220 .elementor-element.elementor-element-7011684d > .elementor-widget-container{margin:25px 0px 0px 0px;}@media(max-width:767px){.elementor-25220 .elementor-element.elementor-element-73dfe88f .elementor-image-box-img{margin-bottom:0px;}}</style>
<style>.elementor-20526 .elementor-element.elementor-element-269803ef .elementor-repeater-item-7dfc0a4.jet-parallax-section__layout .jet-parallax-section__image{background-size:auto;}.elementor-20526 .elementor-element.elementor-element-c6a9fdc{text-align:center;}.elementor-20526 .elementor-element.elementor-element-c6a9fdc img{border-radius:50% 50% 50% 50%;}.elementor-20526 .elementor-element.elementor-element-10d86c14{text-align:center;color:#FFFFFF;font-size:20px;line-height:30px;}.elementor-20526 .elementor-element.elementor-element-6cd2492{text-align:center;}.elementor-20526 .elementor-element.elementor-element-6cd2492 .elementor-heading-title{font-size:25px;}.elementor-20526 .elementor-element.elementor-element-243a7356 .elementor-icon-list-icon i{color:#FFFFFF;transition:color 0.3s;}.elementor-20526 .elementor-element.elementor-element-243a7356 .elementor-icon-list-icon svg{fill:#FFFFFF;transition:fill 0.3s;}.elementor-20526 .elementor-element.elementor-element-243a7356 .elementor-icon-list-item:hover .elementor-icon-list-icon i{color:#FFFFFF;}.elementor-20526 .elementor-element.elementor-element-243a7356 .elementor-icon-list-item:hover .elementor-icon-list-icon svg{fill:#FFFFFF;}.elementor-20526 .elementor-element.elementor-element-243a7356{--e-icon-list-icon-size:18px;--e-icon-list-icon-align:center;--e-icon-list-icon-margin:0 calc(var(--e-icon-list-icon-size, 1em) * 0.125);--icon-vertical-offset:0px;}.elementor-20526 .elementor-element.elementor-element-243a7356 .elementor-icon-list-icon{padding-right:8px;}.elementor-20526 .elementor-element.elementor-element-243a7356 .elementor-icon-list-item > .elementor-icon-list-text, .elementor-20526 .elementor-element.elementor-element-243a7356 .elementor-icon-list-item > a{font-size:16px;font-weight:300;text-transform:uppercase;}.elementor-20526 .elementor-element.elementor-element-243a7356 .elementor-icon-list-text{color:#FFFFFF;transition:color 0.3s;}.elementor-20526 .elementor-element.elementor-element-243a7356 .elementor-icon-list-item:hover .elementor-icon-list-text{color:#FFFFFF;}</style>
<style>.elementor-25203 .elementor-element.elementor-element-269803ef .elementor-repeater-item-7dfc0a4.jet-parallax-section__layout .jet-parallax-section__image{background-size:auto;}.elementor-25203 .elementor-element.elementor-element-c6a9fdc{text-align:center;}.elementor-25203 .elementor-element.elementor-element-c6a9fdc img{border-radius:50% 50% 50% 50%;}.elementor-25203 .elementor-element.elementor-element-10d86c14{text-align:center;color:#FFFFFF;font-size:20px;line-height:30px;}.elementor-25203 .elementor-element.elementor-element-6cd2492{text-align:center;}.elementor-25203 .elementor-element.elementor-element-6cd2492 .elementor-heading-title{font-size:25px;}.elementor-25203 .elementor-element.elementor-element-243a7356 .elementor-icon-list-icon i{color:#FFFFFF;transition:color 0.3s;}.elementor-25203 .elementor-element.elementor-element-243a7356 .elementor-icon-list-icon svg{fill:#FFFFFF;transition:fill 0.3s;}.elementor-25203 .elementor-element.elementor-element-243a7356 .elementor-icon-list-item:hover .elementor-icon-list-icon i{color:#FFFFFF;}.elementor-25203 .elementor-element.elementor-element-243a7356 .elementor-icon-list-item:hover .elementor-icon-list-icon svg{fill:#FFFFFF;}.elementor-25203 .elementor-element.elementor-element-243a7356{--e-icon-list-icon-size:18px;--e-icon-list-icon-align:center;--e-icon-list-icon-margin:0 calc(var(--e-icon-list-icon-size, 1em) * 0.125);--icon-vertical-offset:0px;}.elementor-25203 .elementor-element.elementor-element-243a7356 .elementor-icon-list-icon{padding-right:8px;}.elementor-25203 .elementor-element.elementor-element-243a7356 .elementor-icon-list-item > .elementor-icon-list-text, .elementor-25203 .elementor-element.elementor-element-243a7356 .elementor-icon-list-item > a{font-size:16px;font-weight:300;text-transform:uppercase;}.elementor-25203 .elementor-element.elementor-element-243a7356 .elementor-icon-list-text{color:#FFFFFF;transition:color 0.3s;}.elementor-25203 .elementor-element.elementor-element-243a7356 .elementor-icon-list-item:hover .elementor-icon-list-text{color:#FFFFFF;}</style>
<style>.elementor-25204 .elementor-element.elementor-element-269803ef .elementor-repeater-item-7dfc0a4.jet-parallax-section__layout .jet-parallax-section__image{background-size:auto;}.elementor-25204 .elementor-element.elementor-element-c6a9fdc{text-align:center;}.elementor-25204 .elementor-element.elementor-element-c6a9fdc img{border-radius:50% 50% 50% 50%;}.elementor-25204 .elementor-element.elementor-element-10d86c14{text-align:center;color:#FFFFFF;font-size:20px;line-height:30px;}.elementor-25204 .elementor-element.elementor-element-6cd2492{text-align:center;}.elementor-25204 .elementor-element.elementor-element-6cd2492 .elementor-heading-title{font-size:25px;}.elementor-25204 .elementor-element.elementor-element-243a7356 .elementor-icon-list-icon i{color:#FFFFFF;transition:color 0.3s;}.elementor-25204 .elementor-element.elementor-element-243a7356 .elementor-icon-list-icon svg{fill:#FFFFFF;transition:fill 0.3s;}.elementor-25204 .elementor-element.elementor-element-243a7356 .elementor-icon-list-item:hover .elementor-icon-list-icon i{color:#FFFFFF;}.elementor-25204 .elementor-element.elementor-element-243a7356 .elementor-icon-list-item:hover .elementor-icon-list-icon svg{fill:#FFFFFF;}.elementor-25204 .elementor-element.elementor-element-243a7356{--e-icon-list-icon-size:18px;--e-icon-list-icon-align:center;--e-icon-list-icon-margin:0 calc(var(--e-icon-list-icon-size, 1em) * 0.125);--icon-vertical-offset:0px;}.elementor-25204 .elementor-element.elementor-element-243a7356 .elementor-icon-list-icon{padding-right:8px;}.elementor-25204 .elementor-element.elementor-element-243a7356 .elementor-icon-list-item > .elementor-icon-list-text, .elementor-25204 .elementor-element.elementor-element-243a7356 .elementor-icon-list-item > a{font-size:16px;font-weight:300;text-transform:uppercase;}.elementor-25204 .elementor-element.elementor-element-243a7356 .elementor-icon-list-text{color:#FFFFFF;transition:color 0.3s;}.elementor-25204 .elementor-element.elementor-element-243a7356 .elementor-icon-list-item:hover .elementor-icon-list-text{color:#FFFFFF;}</style>
<style>.elementor-25232 .elementor-element.elementor-element-269803ef .elementor-repeater-item-7dfc0a4.jet-parallax-section__layout .jet-parallax-section__image{background-size:auto;}.elementor-25232 .elementor-element.elementor-element-c6a9fdc{text-align:center;}.elementor-25232 .elementor-element.elementor-element-c6a9fdc img{border-radius:50% 50% 50% 50%;}.elementor-25232 .elementor-element.elementor-element-10d86c14{text-align:center;color:#FFFFFF;font-size:20px;line-height:30px;}.elementor-25232 .elementor-element.elementor-element-6cd2492{text-align:center;}.elementor-25232 .elementor-element.elementor-element-6cd2492 .elementor-heading-title{font-size:25px;}.elementor-25232 .elementor-element.elementor-element-243a7356 .elementor-icon-list-icon i{color:#FFFFFF;transition:color 0.3s;}.elementor-25232 .elementor-element.elementor-element-243a7356 .elementor-icon-list-icon svg{fill:#FFFFFF;transition:fill 0.3s;}.elementor-25232 .elementor-element.elementor-element-243a7356 .elementor-icon-list-item:hover .elementor-icon-list-icon i{color:#FFFFFF;}.elementor-25232 .elementor-element.elementor-element-243a7356 .elementor-icon-list-item:hover .elementor-icon-list-icon svg{fill:#FFFFFF;}.elementor-25232 .elementor-element.elementor-element-243a7356{--e-icon-list-icon-size:18px;--e-icon-list-icon-align:center;--e-icon-list-icon-margin:0 calc(var(--e-icon-list-icon-size, 1em) * 0.125);--icon-vertical-offset:0px;}.elementor-25232 .elementor-element.elementor-element-243a7356 .elementor-icon-list-icon{padding-right:8px;}.elementor-25232 .elementor-element.elementor-element-243a7356 .elementor-icon-list-item > .elementor-icon-list-text, .elementor-25232 .elementor-element.elementor-element-243a7356 .elementor-icon-list-item > a{font-size:16px;font-weight:300;text-transform:uppercase;}.elementor-25232 .elementor-element.elementor-element-243a7356 .elementor-icon-list-text{color:#FFFFFF;transition:color 0.3s;}.elementor-25232 .elementor-element.elementor-element-243a7356 .elementor-icon-list-item:hover .elementor-icon-list-text{color:#FFFFFF;}</style></head>

<body class="home page-template-default page page-id-20398 wp-embed-responsive theme-augury woocommerce-no-js layout-wide page-with-slider no-breadcrumb elementor-default elementor-kit-25447 elementor-page elementor-page-20398">
    <div class="circle-cursor circle-cursor--outer"></div>
	<div class="circle-cursor circle-cursor--inner"></div>

    <!-- **Wrapper** -->
    <div class="wrapper">

        <!-- ** Inner Wrapper ** -->
        <div class="inner-wrapper">

            <!-- ** Header Wrapper ** -->
<div id="header-wrapper" class="header-top-absolute">

    <!-- **Header** -->
    <header id="header">

        <div class="container"><div id="header-20376" class="dt-header-tpl header-20376">		<div data-elementor-type="wp-post" data-elementor-id="20376" class="elementor elementor-20376">
						<div class="elementor-inner">
				<div class="elementor-section-wrap">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-967d606 elementor-section-content-middle elementor-section-stretched header-top-section elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="967d606" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;9e4bd5c&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;],&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;}],&quot;background_background&quot;:&quot;classic&quot;,&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-20 elementor-top-column elementor-element elementor-element-ae9f314" data-id="ae9f314" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-1aab21f elementor-widget elementor-widget-dt-logo" data-id="1aab21f" data-element_type="widget" data-widget_type="dt-logo.default">
				<div class="elementor-widget-container">
			<div id="dt-1aab21f" class="dt-logo-container logo-align-left">  <a href="https://dtaugury.wpengine.com/" rel="home"><img width="336" height="100" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/01/logo-1.png" class="attachment-full size-full" alt="" decoding="async" srcset="https://dtaugury.wpengine.com/wp-content/uploads/2020/01/logo-1.png 336w, https://dtaugury.wpengine.com/wp-content/uploads/2020/01/logo-1-300x89.png 300w" sizes="(max-width: 336px) 100vw, 336px" /></a></div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-20 elementor-top-column elementor-element elementor-element-ade9608 hide-res-sm" data-id="ade9608" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-d291e16 elementor-view-framed elementor-position-left header-contact-info elementor-shape-circle elementor-mobile-position-top elementor-vertical-align-top elementor-widget elementor-widget-icon-box" data-id="d291e16" data-element_type="widget" data-widget_type="icon-box.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-box-wrapper">
						<div class="elementor-icon-box-icon">
				<a class="elementor-icon elementor-animation-" href="https://dtaugury.wpengine.com/contact-us/">
				<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 350 500" style="enable-background:new 0 0 350 500;" xml:space="preserve">
<g transform="translate(0,-952.36218)">
	<path d="M174.9,952.4c-77-0.5-148,51.1-168.9,129.5c-4.7,17.7-5.9,35.1-5.8,51.8c0.3,59.2,31.8,110.3,67.4,159.9   c35.6,49.6,75.7,98.5,97.1,151.9c2.4,5.8,9,8.5,14.8,6.1c2.7-1.2,4.9-3.3,6-6.1c21.4-53.4,61.5-102.3,97.1-151.9   c35.6-49.6,67.1-100.7,67.4-159.9c0.1-16.7-1.1-34.1-5.8-51.8c-20.9-78.3-91.9-130-168.9-129.5C175.1,952.4,175,952.4,174.9,952.4z    M174.9,975.1c0.1,0,0.2,0,0.4,0c67-0.6,128.8,44.2,147,112.6c4,15,5.2,30.4,5.1,45.9c-0.2,51-28.2,97.8-63.2,146.6   c-30.5,42.5-65.2,86.2-89.1,135.2c-24-48.9-58.6-92.7-89.1-135.2c-35-48.7-62.9-95.6-63.2-146.6c-0.1-15.4,1.1-30.9,5.1-45.9   C46.1,1019.3,107.8,974.6,174.9,975.1z M174.7,1054.1c-39.9-0.1-72.6,32.8-72.6,72.9c0.1,40.2,32.8,72.9,72.7,72.9   c39.9,0.1,72.4-32.6,72.4-72.7C247.2,1087,214.6,1054.1,174.7,1054.1z M174.7,1076.9c27.7,0,49.9,22.5,50,50.3   c0,27.9-22.3,50-50,50c-27.7,0-49.9-22.3-50-50.2C124.7,1099.2,147,1076.8,174.7,1076.9z"></path>
</g>
</svg>				</a>
			</div>
						<div class="elementor-icon-box-content">
				<h3 class="elementor-icon-box-title">
					<a href="https://dtaugury.wpengine.com/contact-us/" >
						Reach Us					</a>
				</h3>
									<p class="elementor-icon-box-description">
						113, JA Street, USA					</p>
							</div>
		</div>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-20 elementor-top-column elementor-element elementor-element-9d6d8b9 hide-res-sm" data-id="9d6d8b9" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-24e37b9 elementor-view-framed elementor-position-left header-contact-info elementor-shape-circle elementor-mobile-position-top elementor-vertical-align-top elementor-widget elementor-widget-icon-box" data-id="24e37b9" data-element_type="widget" data-widget_type="icon-box.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-box-wrapper">
						<div class="elementor-icon-box-icon">
				<a class="elementor-icon elementor-animation-" href="https://dtaugury.wpengine.com/contact-us/">
				<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 500 500" style="enable-background:new 0 0 500 500;" xml:space="preserve">
<style type="text/css">
	.st0{display:none;}
	.st1{display:inline;}
</style>
<g class="st0">
	<g transform="translate(0,-952.36218)" class="st1">
		<path d="M265.2,951.4c-77.6-0.5-149.1,51.1-170.2,129.5c-4.8,17.7-6,35.1-5.9,51.8c0.3,59.2,32.1,110.3,67.9,159.9    c35.9,49.6,76.3,98.5,97.8,151.9c2.4,5.8,9.1,8.5,14.9,6.1c2.7-1.2,4.9-3.3,6.1-6.1c21.5-53.4,62-102.3,97.8-151.9    c35.9-49.6,67.7-100.7,67.9-159.9c0.1-16.7-1.1-34.1-5.9-51.8c-21.1-78.3-92.6-130-170.2-129.5    C265.4,951.4,265.3,951.4,265.2,951.4z M265.2,974.1c0.1,0,0.2,0,0.4,0c67.5-0.6,129.7,44.2,148.2,112.6c4,15,5.2,30.4,5.2,45.9    c-0.3,51-28.4,97.8-63.7,146.6c-30.7,42.5-65.7,86.2-89.8,135.2c-24.2-48.9-59.1-92.7-89.8-135.2c-35.2-48.7-63.4-95.6-63.7-146.6    c-0.1-15.4,1.1-30.9,5.2-45.9C135.5,1018.3,197.6,973.6,265.2,974.1z M265,1053.1c-40.2-0.1-73.2,32.8-73.1,72.9    c0.1,40.2,33.1,72.9,73.3,72.9c40.2,0.1,73-32.6,72.9-72.7C338.1,1086,305.2,1053.1,265,1053.1z M265,1075.9    c27.9,0,50.3,22.5,50.3,50.3c0,27.9-22.4,50-50.3,50c-27.9,0-50.3-22.3-50.3-50.2C214.7,1098.2,237.1,1075.8,265,1075.9z"></path>
	</g>
</g>
<g>
	<path d="M343.4,498c-65.2,0-137-40.6-219.3-122.8c-80.9-80.8-122-155.8-122-222.8c0-43.2,16.8-81.9,50-115   c14.8-14.7,32.7-26.1,52.4-33.2C117.3-0.4,131.6,4,139.6,15l62.2,86.4c9.3,13,6.9,31.1-5.5,41.2l-49.4,38.7c-2.7,2-3.5,5.8-1.8,8.7   c20.6,33.2,45,63.9,72.8,91.4c27.5,27.8,58.3,52.2,91.6,72.7c2.9,1.7,6.7,1,8.8-1.8l38.5-49.1c10.1-12.6,28.3-15.1,41.4-5.7   l86.6,62.1c11.1,7.9,15.5,22.3,10.8,35.1c-3.6,9.8-8.3,19.3-13.9,28.1c-5.6,8.7-12,16.8-19.4,24.1c-3.9,3.9-8.1,7.6-12.5,11.1   C416.1,484.6,380.8,498,343.4,498z M113.9,35.9c-14.4,5.5-27.6,14-38.5,24.8c-26.8,26.7-40.3,57.6-40.3,91.6   c0,58,37.8,125.1,112.3,199.4c150,149.7,229.6,121.5,282.1,80.2c3.3-2.6,6.5-5.5,9.6-8.5c5.6-5.6,10.6-11.8,14.8-18.5   c4-6.3,7.3-13,10-19.9L381,325.9l-36.8,46.8c-12.4,15.9-34.7,20-51.9,9.6h0c-35.5-21.9-68.4-47.9-97.7-77.5   c-29.7-29.3-55.7-62-77.7-97.5c-10.4-17.2-6.3-39.5,9.6-51.9l46.9-36.7L113.9,35.9z"></path>
</g>
</svg>				</a>
			</div>
						<div class="elementor-icon-box-content">
				<h3 class="elementor-icon-box-title">
					<a href="https://dtaugury.wpengine.com/contact-us/" >
						Talk to Astrologers					</a>
				</h3>
									<p class="elementor-icon-box-description">
						<a href="tel:+12025550181">+1-202-555-0181</a>					</p>
							</div>
		</div>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-20 elementor-top-column elementor-element elementor-element-71ffb9b" data-id="71ffb9b" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-df1e196 elementor-align-center elementor-widget elementor-widget-button" data-id="df1e196" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-button-link elementor-size-sm" href="https://dtaugury.wpengine.com/appointment/%20%20" target="_blank">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">Appointments</span>
		</span>
					</a>
		</div>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-20 elementor-top-column elementor-element elementor-element-2020208 dt-sc-dropbar-section" data-id="2020208" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-21dbe73 header-author elementor-widget elementor-widget-image" data-id="21dbe73" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
													<a href="https://dtaugury.wpengine.com/appointment/">
							<img src="https://dtaugury.wpengine.com/wp-content/uploads/2020/01/author-img.jpg" title="author-img" alt="author-img" loading="lazy" />								</a>
														</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-9402cb7 jet-dropbar-position-bottom-center dt-sc-dropbar elementor-widget elementor-widget-jet-dropbar" data-id="9402cb7" data-element_type="widget" data-widget_type="jet-dropbar.default">
				<div class="elementor-widget-container">
			<div class="elementor-jet-dropbar jet-elements">
<div class="jet-dropbar jet-dropbar--slide-up-effect" data-settings="{&quot;mode&quot;:&quot;hover&quot;,&quot;hide_delay&quot;:500}">
	<div class="jet-dropbar__inner">
<button class="jet-dropbar__button"><span class="jet-dropbar__button-text">Dropbar</span></button>
<div class="jet-dropbar__content-wrapper">
	<div class="jet-dropbar__content">		<div data-elementor-type="page" data-elementor-id="20488" class="elementor elementor-20488">
						<div class="elementor-inner">
				<div class="elementor-section-wrap">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-39a37cc8 our-services-box elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="39a37cc8" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;7ee6690&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;],&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-581d7ade" data-id="581d7ade" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-73dfe88f dt-sc-smooth-transition elementor-position-top elementor-vertical-align-top elementor-widget elementor-widget-image-box" data-id="73dfe88f" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img src="https://dtaugury.wpengine.com/wp-content/uploads/2020/01/services-icon1.png" title="services-icon1" alt="services-icon1" loading="lazy" /></figure><div class="elementor-image-box-content"><h3 class="elementor-image-box-title">Personal Consultation</h3><p class="elementor-image-box-description">Contrary to popular belief, Lorem Ipsum is not simply random text</p></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-7011684d elementor-align-center elementor-widget elementor-widget-button" data-id="7011684d" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-button-link elementor-size-sm" href="https://dtaugury.wpengine.com/our-services/personal-consultation/">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">View More</span>
		</span>
					</a>
		</div>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
									</div>
			</div>
					</div>
		</div>
</div></div>
</div>
</div>		</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-c711845 header-menu-section elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="c711845" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;a590fcb&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;],&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-fdd57b3" data-id="fdd57b3" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-9038a32 elementor-align-center elementor-widget elementor-widget-dt-header-menu" data-id="9038a32" data-element_type="widget" data-widget_type="dt-header-menu.default">
				<div class="elementor-widget-container">
			<div class="dt-header-menu" data-menu="16"><div class="menu-container"><ul id="menu-main-menu" class="dt-primary-nav" data-menu="16"> <li class="close-nav"></li> <li id="menu-item-20400" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-20398 current_page_item menu-item-20400 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/" aria-current="page"><span>Home</span></a></li>
<li id="menu-item-25187" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25187 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/about-me/"><span>Pages</span></a>
<ul class="sub-menu is-hidden animate dt_fadeInLeft" data-animation="animate dt_fadeInLeft">
<li class="close-nav"></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>	<li id="menu-item-20585" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20585 menu-item-depth-1"><a href="https://dtaugury.wpengine.com/about-me/"><span>About Me</span></a></li>
	<li id="menu-item-20637" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20637 menu-item-depth-1"><a href="https://dtaugury.wpengine.com/team/"><span>Our Team</span></a></li>
	<li id="menu-item-20710" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-20710 menu-item-depth-1"><a href="https://dtaugury.wpengine.com/our-services/"><span>Our Services</span></a>
	<ul class="sub-menu is-hidden animate dt_fadeInLeft" data-animation="animate dt_fadeInLeft">
<li class="close-nav"></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>		<li id="menu-item-25406" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25406 menu-item-depth-2"><a href="https://dtaugury.wpengine.com/our-services/personal-consultation/"><span>Zodiac Consultation</span></a></li>
		<li id="menu-item-25407" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25407 menu-item-depth-2"><a href="https://dtaugury.wpengine.com/our-services/face-reading/"><span>Face Reading</span></a></li>
		<li id="menu-item-25408" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25408 menu-item-depth-2"><a href="https://dtaugury.wpengine.com/our-services/kundli-dosha/"><span>Kundli Dosha</span></a></li>
		<li id="menu-item-25409" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25409 menu-item-depth-2"><a href="https://dtaugury.wpengine.com/our-services/daily-horoscope/"><span>Daily Horoscope</span></a></li>
		<li id="menu-item-25410" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25410 menu-item-depth-2"><a href="https://dtaugury.wpengine.com/our-services/gem-stone/"><span>Gem &#038; Stone</span></a></li>
		<li id="menu-item-25411" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25411 menu-item-depth-2"><a href="https://dtaugury.wpengine.com/our-services/manglik-dosha/"><span>Manglik Dosha</span></a></li>
	</ul>
</li>
</ul>
</li>
<li id="menu-item-20715" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children has-mega-menu menu-item-20715 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/"><span>Forecast</span></a>
<ul class="sub-menu is-hidden animate dt_fadeInLeft" data-animation="animate dt_fadeInLeft">
<li class="close-nav"></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>	<li id="menu-item-25499" class="menu-item menu-item-type-post_type menu-item-object-dt_mega_menus menu-item-25499 menu-item-depth-1">		<div data-elementor-type="wp-post" data-elementor-id="25493" class="elementor elementor-25493">
						<div class="elementor-inner">
				<div class="elementor-section-wrap">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-22b58ec elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="22b58ec" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;a72431a&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;],&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-4fa1dee" data-id="4fa1dee" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-0592a2a elementor-widget elementor-widget-jet-tabs" data-id="0592a2a" data-element_type="widget" data-settings="{&quot;tabs_position&quot;:&quot;top&quot;}" data-widget_type="jet-tabs.default">
				<div class="elementor-widget-container">
					<div class="jet-tabs jet-tabs-position-top jet-tabs-move-up-effect " data-settings="{&quot;activeIndex&quot;:0,&quot;event&quot;:&quot;click&quot;,&quot;autoSwitch&quot;:false,&quot;autoSwitchDelay&quot;:3000,&quot;ajaxTemplate&quot;:false,&quot;tabsPosition&quot;:&quot;top&quot;,&quot;switchScrolling&quot;:false,&quot;switchScrollingOffset&quot;:0}" role="tablist">
			<div class="jet-tabs__control-wrapper">
				<div id="jet-tabs-control-5841" class="jet-tabs__control jet-tabs__control-icon-left elementor-menu-anchor active-tab" data-tab="1" tabindex="0" role="tab" aria-controls="jet-tabs-content-5841" aria-expanded="true" data-template-id="25498"><div class="jet-tabs__control-inner"><div class="jet-tabs__label-icon jet-tabs-icon"><i class="fas fa-arrow-circle-right"></i></div><div class="jet-tabs__label-text">Daily Forecast</div></div></div><div id="jet-tabs-control-5842" class="jet-tabs__control jet-tabs__control-icon-left elementor-menu-anchor " data-tab="2" tabindex="0" role="tab" aria-controls="jet-tabs-content-5842" aria-expanded="false" data-template-id="25498"><div class="jet-tabs__control-inner"><div class="jet-tabs__label-icon jet-tabs-icon"><i class="fas fa-arrow-circle-right"></i></div><div class="jet-tabs__label-text">Weekly Forecast</div></div></div><div id="jet-tabs-control-5843" class="jet-tabs__control jet-tabs__control-icon-left elementor-menu-anchor " data-tab="3" tabindex="0" role="tab" aria-controls="jet-tabs-content-5843" aria-expanded="false" data-template-id="25498"><div class="jet-tabs__control-inner"><div class="jet-tabs__label-icon jet-tabs-icon"><i class="fas fa-arrow-circle-right"></i></div><div class="jet-tabs__label-text">Monthly Forecast</div></div></div>			</div>
			<div class="jet-tabs__content-wrapper">
				<div id="jet-tabs-content-5841" class="jet-tabs__content active-content" data-tab="1" role="tabpanel" aria-hidden="false" data-template-id="25498">		<div data-elementor-type="section" data-elementor-id="25498" class="elementor elementor-25498">
						<div class="elementor-inner">
				<div class="elementor-section-wrap">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-de2eff1 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="de2eff1" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;bb9a648&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;],&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-47337a4" data-id="47337a4" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-1db6614 elementor-widget elementor-widget-wp-widget-nav_menu" data-id="1db6614" data-element_type="widget" data-widget_type="wp-widget-nav_menu.default">
				<div class="elementor-widget-container">
			<div class="menu-zodiacs-i-container"><ul id="menu-zodiacs-i" class="dt-primary-nav"><li id="menu-item-25416" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25416 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/aries/">Aries</a></li>
<li id="menu-item-25417" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25417 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/taurus/">Taurus</a></li>
<li id="menu-item-25418" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25418 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/gemini/">Gemini</a></li>
</ul></div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-9c981ac" data-id="9c981ac" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-056b20a elementor-widget elementor-widget-wp-widget-nav_menu" data-id="056b20a" data-element_type="widget" data-widget_type="wp-widget-nav_menu.default">
				<div class="elementor-widget-container">
			<div class="menu-zodiacs-ii-container"><ul id="menu-zodiacs-ii" class="dt-primary-nav"><li id="menu-item-25431" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25431 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/cancer/">Cancer</a></li>
<li id="menu-item-25420" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25420 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/leo/">Leo</a></li>
<li id="menu-item-25421" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25421 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/virgo/">Virgo</a></li>
</ul></div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-8303fab" data-id="8303fab" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-2c2f838 elementor-widget elementor-widget-wp-widget-nav_menu" data-id="2c2f838" data-element_type="widget" data-widget_type="wp-widget-nav_menu.default">
				<div class="elementor-widget-container">
			<div class="menu-zodiacs-iii-container"><ul id="menu-zodiacs-iii" class="dt-primary-nav"><li id="menu-item-25432" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25432 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/libra/">Libra</a></li>
<li id="menu-item-25433" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25433 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/scorpio/">Scorpio</a></li>
<li id="menu-item-25434" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25434 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/sagnittarius/">Sagnittarius</a></li>
</ul></div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-3c2a3a4" data-id="3c2a3a4" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-964ae64 elementor-widget elementor-widget-wp-widget-nav_menu" data-id="964ae64" data-element_type="widget" data-widget_type="wp-widget-nav_menu.default">
				<div class="elementor-widget-container">
			<div class="menu-zodiacs-iv-container"><ul id="menu-zodiacs-iv" class="dt-primary-nav"><li id="menu-item-25435" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25435 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/capricorn/">Capricorn</a></li>
<li id="menu-item-25436" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25436 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/aquarius/">Aquarius</a></li>
<li id="menu-item-25437" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25437 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/pisces/">Pisces</a></li>
</ul></div>		</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
									</div>
			</div>
					</div>
		</div><div id="jet-tabs-content-5842" class="jet-tabs__content " data-tab="2" role="tabpanel" aria-hidden="true" data-template-id="25498">		<div data-elementor-type="section" data-elementor-id="25498" class="elementor elementor-25498">
						<div class="elementor-inner">
				<div class="elementor-section-wrap">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-de2eff1 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="de2eff1" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;bb9a648&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;],&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-47337a4" data-id="47337a4" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-1db6614 elementor-widget elementor-widget-wp-widget-nav_menu" data-id="1db6614" data-element_type="widget" data-widget_type="wp-widget-nav_menu.default">
				<div class="elementor-widget-container">
			<div class="menu-zodiacs-i-container"><ul id="menu-zodiacs-i-1" class="dt-primary-nav"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25416 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/aries/">Aries</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25417 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/taurus/">Taurus</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25418 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/gemini/">Gemini</a></li>
</ul></div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-9c981ac" data-id="9c981ac" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-056b20a elementor-widget elementor-widget-wp-widget-nav_menu" data-id="056b20a" data-element_type="widget" data-widget_type="wp-widget-nav_menu.default">
				<div class="elementor-widget-container">
			<div class="menu-zodiacs-ii-container"><ul id="menu-zodiacs-ii-1" class="dt-primary-nav"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25431 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/cancer/">Cancer</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25420 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/leo/">Leo</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25421 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/virgo/">Virgo</a></li>
</ul></div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-8303fab" data-id="8303fab" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-2c2f838 elementor-widget elementor-widget-wp-widget-nav_menu" data-id="2c2f838" data-element_type="widget" data-widget_type="wp-widget-nav_menu.default">
				<div class="elementor-widget-container">
			<div class="menu-zodiacs-iii-container"><ul id="menu-zodiacs-iii-1" class="dt-primary-nav"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25432 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/libra/">Libra</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25433 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/scorpio/">Scorpio</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25434 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/sagnittarius/">Sagnittarius</a></li>
</ul></div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-3c2a3a4" data-id="3c2a3a4" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-964ae64 elementor-widget elementor-widget-wp-widget-nav_menu" data-id="964ae64" data-element_type="widget" data-widget_type="wp-widget-nav_menu.default">
				<div class="elementor-widget-container">
			<div class="menu-zodiacs-iv-container"><ul id="menu-zodiacs-iv-1" class="dt-primary-nav"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25435 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/capricorn/">Capricorn</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25436 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/aquarius/">Aquarius</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25437 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/pisces/">Pisces</a></li>
</ul></div>		</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
									</div>
			</div>
					</div>
		</div><div id="jet-tabs-content-5843" class="jet-tabs__content " data-tab="3" role="tabpanel" aria-hidden="true" data-template-id="25498">		<div data-elementor-type="section" data-elementor-id="25498" class="elementor elementor-25498">
						<div class="elementor-inner">
				<div class="elementor-section-wrap">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-de2eff1 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="de2eff1" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;bb9a648&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;],&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-47337a4" data-id="47337a4" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-1db6614 elementor-widget elementor-widget-wp-widget-nav_menu" data-id="1db6614" data-element_type="widget" data-widget_type="wp-widget-nav_menu.default">
				<div class="elementor-widget-container">
			<div class="menu-zodiacs-i-container"><ul id="menu-zodiacs-i-2" class="dt-primary-nav"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25416 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/aries/">Aries</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25417 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/taurus/">Taurus</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25418 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/gemini/">Gemini</a></li>
</ul></div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-9c981ac" data-id="9c981ac" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-056b20a elementor-widget elementor-widget-wp-widget-nav_menu" data-id="056b20a" data-element_type="widget" data-widget_type="wp-widget-nav_menu.default">
				<div class="elementor-widget-container">
			<div class="menu-zodiacs-ii-container"><ul id="menu-zodiacs-ii-2" class="dt-primary-nav"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25431 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/cancer/">Cancer</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25420 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/leo/">Leo</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25421 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/virgo/">Virgo</a></li>
</ul></div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-8303fab" data-id="8303fab" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-2c2f838 elementor-widget elementor-widget-wp-widget-nav_menu" data-id="2c2f838" data-element_type="widget" data-widget_type="wp-widget-nav_menu.default">
				<div class="elementor-widget-container">
			<div class="menu-zodiacs-iii-container"><ul id="menu-zodiacs-iii-2" class="dt-primary-nav"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25432 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/libra/">Libra</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25433 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/scorpio/">Scorpio</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25434 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/sagnittarius/">Sagnittarius</a></li>
</ul></div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-3c2a3a4" data-id="3c2a3a4" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-964ae64 elementor-widget elementor-widget-wp-widget-nav_menu" data-id="964ae64" data-element_type="widget" data-widget_type="wp-widget-nav_menu.default">
				<div class="elementor-widget-container">
			<div class="menu-zodiacs-iv-container"><ul id="menu-zodiacs-iv-2" class="dt-primary-nav"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25435 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/capricorn/">Capricorn</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25436 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/aquarius/">Aquarius</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25437 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/forecast/pisces/">Pisces</a></li>
</ul></div>		</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
									</div>
			</div>
					</div>
		</div>			</div>
		</div>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
									</div>
			</div>
					</div>
		</li>
</ul>
</li>
<li id="menu-item-25184" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-25184 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/case-studies/"><span>Case Studies</span></a>
<ul class="sub-menu is-hidden animate dt_fadeInLeft" data-animation="animate dt_fadeInLeft">
<li class="close-nav"></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>	<li id="menu-item-25444" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25444 menu-item-depth-1"><a href="https://dtaugury.wpengine.com/case-studies/"><span>Case Studies Listing</span></a></li>
	<li id="menu-item-24713" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-24713 menu-item-depth-1"><a href="https://dtaugury.wpengine.com/blog/portfolios/astrology-study/"><span>Case Single</span></a></li>
</ul>
</li>
<li id="menu-item-24657" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-24657 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/blog/"><span>Blog</span></a>
<ul class="sub-menu is-hidden animate dt_fadeInLeft" data-animation="animate dt_fadeInLeft">
<li class="close-nav"></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>	<li id="menu-item-25438" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25438 menu-item-depth-1"><a href="https://dtaugury.wpengine.com/blog/"><span>Blog &#8211; Listing</span></a></li>
	<li id="menu-item-25439" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-25439 menu-item-depth-1"><a href="https://dtaugury.wpengine.com/blog/beliefs-of-primitive-people/"><span>Single &#8211; Left Sidebar</span></a></li>
	<li id="menu-item-25443" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-25443 menu-item-depth-1"><a href="https://dtaugury.wpengine.com/blog/astrology-and-religion/"><span>Single &#8211; Right Sidebar</span></a></li>
	<li id="menu-item-25442" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-25442 menu-item-depth-1"><a href="https://dtaugury.wpengine.com/blog/the-astrological-systems/"><span>Single &#8211; Fullwidth</span></a></li>
</ul>
</li>
<li id="menu-item-25196" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-25196 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/shop/"><span>Shop</span></a>
<ul class="sub-menu is-hidden animate dt_fadeInLeft" data-animation="animate dt_fadeInLeft">
<li class="close-nav"></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>	<li id="menu-item-25445" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25445 menu-item-depth-1"><a href="https://dtaugury.wpengine.com/shop/"><span>Products</span></a></li>
	<li id="menu-item-25200" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25200 menu-item-depth-1"><a href="https://dtaugury.wpengine.com/cart/"><span>Cart</span></a></li>
	<li id="menu-item-25199" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25199 menu-item-depth-1"><a href="https://dtaugury.wpengine.com/checkout/"><span>Checkout</span></a></li>
	<li id="menu-item-25198" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25198 menu-item-depth-1"><a href="https://dtaugury.wpengine.com/my-account/"><span>My account</span></a></li>
</ul>
</li>
<li id="menu-item-20937" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-20937 menu-item-depth-0"><a href="https://dtaugury.wpengine.com/contact-us/"><span>Contact Us</span></a>
<ul class="sub-menu is-hidden animate dt_fadeInLeft" data-animation="animate dt_fadeInLeft">
<li class="close-nav"></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>	<li id="menu-item-25467" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25467 menu-item-depth-1"><a href="https://dtaugury.wpengine.com/contact-us/"><span>Contact Us</span></a></li>
	<li id="menu-item-25414" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25414 menu-item-depth-1"><a href="https://dtaugury.wpengine.com/appointment/"><span>Appointment</span></a></li>
	<li id="menu-item-25413" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25413 menu-item-depth-1"><a href="https://dtaugury.wpengine.com/appointment-ii/"><span>Appointment  II</span></a></li>
	<li id="menu-item-25412" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25412 menu-item-depth-1"><a href="https://dtaugury.wpengine.com/reservation-form/"><span>Appointment  III</span></a></li>
</ul>
</li>
 </ul> <div class="sub-menu-overlay"></div></div><div class="mobile-nav-container mobile-nav-offcanvas-right" data-menu="16"><div class="menu-trigger menu-trigger-icon" data-menu="16"><i></i><span>Menu</span></div><div class="mobile-menu" data-menu="16"></div><div class="overlay"></div></div></div>		</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-cb483d7 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="cb483d7" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;1d1377f&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;],&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-723dc16" data-id="723dc16" data-element_type="column">
			<div class="elementor-column-wrap">
							<div class="elementor-widget-wrap">
								</div>
					</div>
		</div>
								</div>
					</div>
		</section>
									</div>
			</div>
					</div>
		</div>        </div>
    </header><!-- **Header - End ** -->

    <!-- ** Slider ** -->
    <div id="slider">  <div id="dt-sc-rev-slider" class="dt-sc-main-slider">
			<!-- START homeslider REVOLUTION SLIDER 6.6.13 --><p class="rs-p-wp-fix"></p>
			<rs-module-wrap id="rev_slider_1_1_wrapper" data-source="gallery" style="visibility:hidden;background:transparent;padding:0;margin:0px auto;margin-top:0;margin-bottom:0;">
				<rs-module id="rev_slider_1_1" style="" data-version="6.6.13">
					<rs-slides style="overflow: hidden; position: absolute;">
						<rs-slide style="position: absolute;" data-key="rs-1" data-title="Slide" data-anim="ms:1000;r:0;" data-in="o:0;" data-out="a:false;">
							<img src="//dtaugury.wpengine.com/wp-content/plugins/revslider/public/assets/assets/dummy.png" alt="Slide" title="Home" class="rev-slidebg tp-rs-img rs-lazyload" data-lazyload="//dtaugury.wpengine.com/wp-content/plugins/revslider/public/assets/assets/transparent.png" data-no-retina>
<!--
							--><rs-layer
								id="slider-1-slide-1-layer-0"
								data-type="text"
								data-xy="x:c;y:m;"
								data-text="w:normal;s:55,40,30,18;l:68,50,37,22;"
								data-dim="w:1920px,1414px,1074px,662px;h:920px,788px,610px,722px;"
								data-rsp_o="off"
								data-rsp_bd="off"
								data-blendmode="multiply"
								data-frame_999="o:0;st:w;sR:8700;"
								style="z-index:8;font-family:'Roboto';"
							><div class="stars"></div><br />
<div class="twinkling">  </div>
							</rs-layer><!--

							--><rs-layer
								id="slider-1-slide-1-layer-2"
								data-type="image"
								data-rsp_ch="on"
								data-xy="x:r;xo:-340px,-250px,-195px,-120px;y:m;yo:0,0,-19px,-11px;"
								data-text="w:normal;s:20,14,10,6;l:0,18,13,8;"
								data-dim="w:1139px,839px,637px,393px;h:907px,668px,507px,312px;"
								data-frame_0_mask="u:t;"
								data-frame_1="e:power4.inOut;sp:2300;"
								data-frame_999="o:0;st:w;sR:6700;"
								style="z-index:9;background-blend-mode:screen;"
							><img src="//dtaugury.wpengine.com/wp-content/plugins/revslider/public/assets/assets/dummy.png" alt="Image" class="tp-rs-img rs-lazyload" width="1139" height="907" data-lazyload="//dtaugury.wpengine.com/wp-content/uploads/2018/02/mystic-image5.png" data-no-retina>
							</rs-layer><!--

							--><rs-layer
								id="slider-1-slide-1-layer-3"
								data-type="text"
								data-color="#fff"
								data-xy="x:c;y:m;yo:65px,30px,-7px,30px;"
								data-text="w:normal,normal,normal,normal;s:55,50,40,40;l:68,68,50,46;fw:600;a:center;"
								data-dim="w:745px,659px,483px,336px;minh:0px,none,none,none;"
								data-rsp_bd="off"
								data-frame_0="x:-100%;"
								data-frame_0_mask="u:t;"
								data-frame_1="st:2150;sp:1000;sR:2150;"
								data-frame_1_mask="u:t;"
								data-frame_999="o:0;st:w;sR:5850;"
								style="z-index:10;font-family:'Josefin Sans';"
							>Your path is illuminated by a road-map of stars.
							</rs-layer><!--

							--><rs-layer
								id="slider-1-slide-1-layer-4"
								data-type="text"
								data-xy="x:c;y:m;yo:-84px,-112px,-140px,-132px;"
								data-text="w:normal;s:25,25,23,24;l:36,26,38,36;fw:300;a:left,left,center,center;"
								data-basealign="slide"
								data-rsp_bd="off"
								data-frame_0="y:50;"
								data-frame_1="st:1280;sp:1000;sR:1280;"
								data-frame_999="o:0;st:w;sR:6720;"
								style="z-index:11;font-family:'Josefin Sans';"
							>Predict Future
							</rs-layer><!--

							--><rs-layer
								id="slider-1-slide-1-layer-5"
								data-type="text"
								data-color="#a3a1a1"
								data-xy="x:c;xo:0,30px,22px,13px;y:t,t,t,m;yo:480px,422px,313px,0;"
								data-text="w:normal;s:25,25,18,11;l:36,34,25,15;fw:300;a:center;"
								data-dim="w:558px,467px,354px,218px;minh:0px,none,none,none;"
								data-vbility="f,f,f,f"
								data-rsp_bd="off"
								data-frame_0="y:-100%;"
								data-frame_0_mask="u:t;"
								data-frame_1="st:3000;sp:1200;sR:3000;"
								data-frame_1_mask="u:t;"
								data-frame_999="o:0;st:w;sR:4800;"
								style="z-index:12;font-family:'Josefin Sans';"
							>Get your future predictions & forecasts perfect from the will of God.
							</rs-layer><!--

							--><a
								id="slider-1-slide-1-layer-6"
								class="rs-layer rev-btn"
								href="http://dtaugury.wpengine.com/about-me/" target="_self" rel="nofollow"
								data-type="button"
								data-xy="x:c;y:m;yo:195px,170px,127px,133px;"
								data-text="w:normal;s:20,25,23,24;l:47,50,50,50;fw:300;a:left,left,center,center;"
								data-dim="minh:0px,none,none,none;"
								data-vbility="t,t,t,f"
								data-rsp_bd="off"
								data-padding="r:30,28,28,28;l:30,28,28,28;"
								data-border="bos:solid;boc:rgba(255,255,255,0.35);bow:1px,1px,1px,1px;bor:25px,25px,25px,25px;"
								data-frame_0="y:50;"
								data-frame_1="st:3090;sp:1000;sR:3090;"
								data-frame_999="o:0;st:w;sR:4910;"
								data-frame_hover="c:#000;bgc:#ffa35a;boc:#ffa35a;bor:25px,25px,25px,25px;bos:solid;bow:1px,1px,1px,1px;sp:100ms;e:power1.inOut;"
								style="z-index:13;background-color:rgba(0,0,0,0);font-family:'Josefin Sans';"
							>Discover More
							</a><!--
-->						</rs-slide>
					</rs-slides>
				</rs-module>
				<script>
					setREVStartSize({c: 'rev_slider_1_1',rl:[1240,1024,778,480],el:[800,550,500,450],gw:[1390,1024,778,480],gh:[800,550,500,450],type:'standard',justify:'',layout:'fullwidth',mh:"0"});if (window.RS_MODULES!==undefined && window.RS_MODULES.modules!==undefined && window.RS_MODULES.modules["revslider11"]!==undefined) {window.RS_MODULES.modules["revslider11"].once = false;window.revapi1 = undefined;if (window.RS_MODULES.checkMinimal!==undefined) window.RS_MODULES.checkMinimal()}
				</script>
			</rs-module-wrap>
			<!-- END REVOLUTION SLIDER -->
  </div></div><!-- ** Slider End ** -->

    <!-- ** Breadcrumb ** -->
    <!-- ** Breadcrumb End ** -->
</div><!-- ** Header Wrapper - End ** -->

<!-- **Main** -->
<div id="main">

    <!-- ** Container ** -->
    <div class="container">
        <!-- Primary -->
        <section id="primary" class="content-full-width">	<!-- #post-20398 -->
<div id="post-20398" class="post-20398 page type-page status-publish hentry">
		<div data-elementor-type="wp-page" data-elementor-id="20398" class="elementor elementor-20398">
						<div class="elementor-inner">
				<div class="elementor-section-wrap">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-6b56aff elementor-section-content-middle elementor-section-stretched moon-sign-section elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="6b56aff" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;https:\/\/dtaugury.wpengine.com\/wp-content\/uploads\/2020\/01\/moon-phasing1.png&quot;,&quot;id&quot;:20444,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;750b093&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:10,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;zoom&quot;,&quot;jet_parallax_layout_bg_x&quot;:0,&quot;jet_parallax_layout_bg_y&quot;:70,&quot;jet_parallax_layout_bg_size&quot;:&quot;contain&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:null,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}],&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-ee411a9" data-id="ee411a9" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-cfce6c9 animate-rotate img1 elementor-absolute elementor-widget elementor-widget-image" data-id="cfce6c9" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
												<img decoding="async" fetchpriority="high" width="693" height="627" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/01/moon-sign-1-1.png" class="attachment-full size-full wp-image-20513" alt="" srcset="https://dtaugury.wpengine.com/wp-content/uploads/2020/01/moon-sign-1-1.png 693w, https://dtaugury.wpengine.com/wp-content/uploads/2020/01/moon-sign-1-1-300x271.png 300w, https://dtaugury.wpengine.com/wp-content/uploads/2020/01/moon-sign-1-1-540x489.png 540w" sizes="(max-width: 693px) 100vw, 693px" />														</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-5dfd8ef animate-rotate-reverse img2 elementor-absolute elementor-widget elementor-widget-image" data-id="5dfd8ef" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
												<img decoding="async" width="516" height="517" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/01/moon-sign-3.png" class="attachment-full size-full wp-image-20512" alt="" srcset="https://dtaugury.wpengine.com/wp-content/uploads/2020/01/moon-sign-3.png 516w, https://dtaugury.wpengine.com/wp-content/uploads/2020/01/moon-sign-3-150x150.png 150w, https://dtaugury.wpengine.com/wp-content/uploads/2020/01/moon-sign-3-300x300.png 300w, https://dtaugury.wpengine.com/wp-content/uploads/2020/01/moon-sign-3-450x450.png 450w, https://dtaugury.wpengine.com/wp-content/uploads/2020/01/moon-sign-3-420x420.png 420w, https://dtaugury.wpengine.com/wp-content/uploads/2020/01/moon-sign-3-100x100.png 100w" sizes="(max-width: 516px) 100vw, 516px" />														</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-17b6f10 elementor-widget elementor-widget-image" data-id="17b6f10" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
												<img decoding="async" width="564" height="564" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/moon-inverse1.png" class="attachment-full size-full wp-image-25490" alt="" srcset="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/moon-inverse1.png 564w, https://dtaugury.wpengine.com/wp-content/uploads/2020/02/moon-inverse1-300x300.png 300w, https://dtaugury.wpengine.com/wp-content/uploads/2020/02/moon-inverse1-150x150.png 150w, https://dtaugury.wpengine.com/wp-content/uploads/2020/02/moon-inverse1-450x450.png 450w, https://dtaugury.wpengine.com/wp-content/uploads/2020/02/moon-inverse1-420x420.png 420w, https://dtaugury.wpengine.com/wp-content/uploads/2020/02/moon-inverse1-540x540.png 540w, https://dtaugury.wpengine.com/wp-content/uploads/2020/02/moon-inverse1-205x205.png 205w, https://dtaugury.wpengine.com/wp-content/uploads/2020/02/moon-inverse1-100x100.png 100w" sizes="(max-width: 564px) 100vw, 564px" />														</div>
						</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-7096027" data-id="7096027" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-6ff3b6c dt-skin-secondary-color elementor-widget elementor-widget-heading" data-id="6ff3b6c" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h4 class="elementor-heading-title elementor-size-default">Lorem Ipsum</h4>		</div>
				</div>
				<div class="elementor-element elementor-element-3e76fa27 elementor-widget elementor-widget-heading" data-id="3e76fa27" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">What we do</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-5a1f542 elementor-widget elementor-widget-text-editor" data-id="5a1f542" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis.</p>					</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-829d038 elementor-align-left elementor-widget elementor-widget-button" data-id="829d038" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-button-link elementor-size-sm" href="https://dtaugury.wpengine.com/about-me/" target="_blank">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">Learn More</span>
		</span>
					</a>
		</div>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-b1fe580 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="b1fe580" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;3e16bd6&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-731414d" data-id="731414d" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-ae17e8d elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="ae17e8d" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;0d382a6&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-e88d666" data-id="e88d666" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-b148c7f dt-skin-secondary-color elementor-widget elementor-widget-heading" data-id="b148c7f" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h4 class="elementor-heading-title elementor-size-default">Lorem Ipsum</h4>		</div>
				</div>
				<div class="elementor-element elementor-element-b1bda54 elementor-widget elementor-widget-heading" data-id="b1bda54" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Choose Your Zodiac Sign</h2>		</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-50c980a elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="50c980a" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;0d382a6&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-383d6c1" data-id="383d6c1" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-5038b01 elementor-widget elementor-widget-text-editor" data-id="5038b01" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
				Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.					</div>
						</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-c1dbb05" data-id="c1dbb05" data-element_type="column">
			<div class="elementor-column-wrap">
							<div class="elementor-widget-wrap">
								</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-517f8dd elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="517f8dd" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;0d382a6&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-90b71c0" data-id="90b71c0" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-6e6250f elementor-widget elementor-widget-spacer" data-id="6e6250f" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-bb37020 zodiac-sign-wrapper elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="bb37020" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;0d382a6&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-67de41b dt-col-sm-4" data-id="67de41b" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-f597090 aligncenter elementor-widget elementor-widget-dt-iconbox" data-id="f597090" data-element_type="widget" data-widget_type="dt-iconbox.default">
				<div class="elementor-widget-container">
			<div class="dt-sc-iconbox-wrapper "><div class="dt-sc-iconbox-container"><div class="iconbox-bg"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg1.png" alt="20756"/></div><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-icon1.png" alt="20877" /><div class="iconbox-hover"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg1-1.png" alt="20757" /></div></div><div class="dt-sc-iconbox-description"><h3><a href="https://dtaugury.wpengine.com/forecast/aries/" title="Aries">Aries</a></h3><h4>Apr 05-May 20</h4></div></div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-a2f5f89 dt-col-sm-4" data-id="a2f5f89" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-b506093 aligncenter elementor-widget elementor-widget-dt-iconbox" data-id="b506093" data-element_type="widget" data-widget_type="dt-iconbox.default">
				<div class="elementor-widget-container">
			<div class="dt-sc-iconbox-wrapper "><div class="dt-sc-iconbox-container"><div class="iconbox-bg"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg2.png" alt="20854"/></div><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-icon2.png" alt="20878" /><div class="iconbox-hover"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg2-1.png" alt="20855" /></div></div><div class="dt-sc-iconbox-description"><h3><a href="https://dtaugury.wpengine.com/forecast/taurus/" title="Taurus">Taurus</a></h3><h4>Jan 12-Feb 17</h4></div></div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-30c9ffa dt-col-sm-4" data-id="30c9ffa" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-20c02c5 aligncenter elementor-widget elementor-widget-dt-iconbox" data-id="20c02c5" data-element_type="widget" data-widget_type="dt-iconbox.default">
				<div class="elementor-widget-container">
			<div class="dt-sc-iconbox-wrapper "><div class="dt-sc-iconbox-container"><div class="iconbox-bg"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg3.png" alt="20856"/></div><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-icon3.png" alt="20879" /><div class="iconbox-hover"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg3-1.png" alt="20857" /></div></div><div class="dt-sc-iconbox-description"><h3><a href="https://dtaugury.wpengine.com/forecast/gemini/" title="Gemini">Gemini</a></h3><h4>Mar 20-May 23</h4></div></div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-db4a0fe dt-col-sm-4" data-id="db4a0fe" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-0200365 aligncenter elementor-widget elementor-widget-dt-iconbox" data-id="0200365" data-element_type="widget" data-widget_type="dt-iconbox.default">
				<div class="elementor-widget-container">
			<div class="dt-sc-iconbox-wrapper "><div class="dt-sc-iconbox-container"><div class="iconbox-bg"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg4.png" alt="20858"/></div><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-icon4.png" alt="20880" /><div class="iconbox-hover"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg4-1.png" alt="20859" /></div></div><div class="dt-sc-iconbox-description"><h3><a href="https://dtaugury.wpengine.com/forecast/cancer/" title="Cancer">Cancer</a></h3><h4>Aug 22-Oct 20</h4></div></div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-3bc1a18 dt-col-sm-4" data-id="3bc1a18" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-e3ee78d aligncenter elementor-widget elementor-widget-dt-iconbox" data-id="e3ee78d" data-element_type="widget" data-widget_type="dt-iconbox.default">
				<div class="elementor-widget-container">
			<div class="dt-sc-iconbox-wrapper "><div class="dt-sc-iconbox-container"><div class="iconbox-bg"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg5.png" alt="20860"/></div><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-icon5.png" alt="20881" /><div class="iconbox-hover"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg5-1.png" alt="20861" /></div></div><div class="dt-sc-iconbox-description"><h3><a href="https://dtaugury.wpengine.com/forecast/leo/" title="Leo">Leo</a></h3><h4>Jun 22-Jul 20</h4></div></div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-164cfbc dt-col-sm-4" data-id="164cfbc" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-1aecbe4 aligncenter elementor-widget elementor-widget-dt-iconbox" data-id="1aecbe4" data-element_type="widget" data-widget_type="dt-iconbox.default">
				<div class="elementor-widget-container">
			<div class="dt-sc-iconbox-wrapper "><div class="dt-sc-iconbox-container"><div class="iconbox-bg"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg6.png" alt="20862"/></div><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-icon6.png" alt="20882" /><div class="iconbox-hover"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg6-1.png" alt="20863" /></div></div><div class="dt-sc-iconbox-description"><h3><a href="https://dtaugury.wpengine.com/forecast/virgo/" title="Virgo">Virgo</a></h3><h4>Aug 22-Sep 20</h4></div></div>		</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-97201ab zodiac-sign-wrapper elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="97201ab" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;0d382a6&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;quot;tablet&quot;]}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-c18b0fb dt-col-sm-4" data-id="c18b0fb" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-59738c1 aligncenter elementor-widget elementor-widget-dt-iconbox" data-id="59738c1" data-element_type="widget" data-widget_type="dt-iconbox.default">
				<div class="elementor-widget-container">
			<div class="dt-sc-iconbox-wrapper "><div class="dt-sc-iconbox-container"><div class="iconbox-bg"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg7.png" alt="20864"/></div><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-icon7.png" alt="20883" /><div class="iconbox-hover"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg7-1.png" alt="20865" /></div></div><div class="dt-sc-iconbox-description"><h3><a href="https://dtaugury.wpengine.com/forecast/libra/" title="Libra">Libra</a></h3><h4>Oct 27-Nov 10</h4></div></div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-be53784 dt-col-sm-4" data-id="be53784" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-ce34165 aligncenter elementor-widget elementor-widget-dt-iconbox" data-id="ce34165" data-element_type="widget" data-widget_type="dt-iconbox.default">
				<div class="elementor-widget-container">
			<div class="dt-sc-iconbox-wrapper "><div class="dt-sc-iconbox-container"><div class="iconbox-bg"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg8.png" alt="20866"/></div><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-icon8.png" alt="20884" /><div class="iconbox-hover"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg8-1.png" alt="20867" /></div></div><div class="dt-sc-iconbox-description"><h3><a href="https://dtaugury.wpengine.com/forecast/scorpio/" title="Scorpio">Scorpio</a></h3><h4>Dec 12-Jan 20</h4></div></div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-e825753 dt-col-sm-4" data-id="e825753" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-16f7386 aligncenter elementor-widget elementor-widget-dt-iconbox" data-id="16f7386" data-element_type="widget" data-widget_type="dt-iconbox.default">
				<div class="elementor-widget-container">
			<div class="dt-sc-iconbox-wrapper "><div class="dt-sc-iconbox-container"><div class="iconbox-bg"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg9.png" alt="20868"/></div><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-icon9.png" alt="20885" /><div class="iconbox-hover"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg9-1.png" alt="20869" /></div></div><div class="dt-sc-iconbox-description"><h3><a href="https://dtaugury.wpengine.com/forecast/sagnittarius/" title="Sagnittarius">Sagnittarius</a></h3><h4>Feb 22-Mar 20</h4></div></div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-54be715 dt-col-sm-4" data-id="54be715" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-68c02c5 aligncenter elementor-widget elementor-widget-dt-iconbox" data-id="68c02c5" data-element_type="widget" data-widget_type="dt-iconbox.default">
				<div class="elementor-widget-container">
			<div class="dt-sc-iconbox-wrapper "><div class="dt-sc-iconbox-container"><div class="iconbox-bg"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg10.png" alt="20870"/></div><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-icon10.png" alt="20886" /><div class="iconbox-hover"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg10-1.png" alt="20871" /></div></div><div class="dt-sc-iconbox-description"><h3><a href="https://dtaugury.wpengine.com/forecast/capricorn/" title="Capricorn">Capricorn</a></h3><h4>Apr 18-May 20</h4></div></div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-6c6488a dt-col-sm-4" data-id="6c6488a" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-b784976 aligncenter elementor-widget elementor-widget-dt-iconbox" data-id="b784976" data-element_type="widget" data-widget_type="dt-iconbox.default">
				<div class="elementor-widget-container">
			<div class="dt-sc-iconbox-wrapper "><div class="dt-sc-iconbox-container"><div class="iconbox-bg"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg11.png" alt="20872"/></div><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-icon11.png" alt="20887" /><div class="iconbox-hover"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg11-1.png" alt="20873" /></div></div><div class="dt-sc-iconbox-description"><h3><a href="https://dtaugury.wpengine.com/forecast/aquarius/" title="Aquarius">Aquarius</a></h3><h4>Jun 22-Jul 16</h4></div></div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-fa889c4 dt-col-sm-4" data-id="fa889c4" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-0231c69 aligncenter elementor-widget elementor-widget-dt-iconbox" data-id="0231c69" data-element_type="widget" data-widget_type="dt-iconbox.default">
				<div class="elementor-widget-container">
			<div class="dt-sc-iconbox-wrapper "><div class="dt-sc-iconbox-container"><div class="iconbox-bg"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg12.png" alt="20874"/></div><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-icon12.png" alt="20888" /><div class="iconbox-hover"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/zodiac-bg12-1.png" alt="20875" /></div></div><div class="dt-sc-iconbox-description"><h3><a href="https://dtaugury.wpengine.com/forecast/pisces/" title="Pisces">Pisces</a></h3><h4>Aug 22-Sep 20</h4></div></div>		</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-d775afc our-services-section elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="d775afc" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;3e16bd6&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
						<div class="elementor-container elementor-column-gap-extended">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-f0ff0de" data-id="f0ff0de" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-586d458 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="586d458" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;0d382a6&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-395da82" data-id="395da82" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-51d11ed animate-rotate elementor-absolute elementor-widget elementor-widget-image" data-id="51d11ed" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
												<img decoding="async" loading="lazy" width="919" height="940" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/01/chakra.png" class="attachment-full size-full wp-image-20514" alt="" srcset="https://dtaugury.wpengine.com/wp-content/uploads/2020/01/chakra.png 919w, https://dtaugury.wpengine.com/wp-content/uploads/2020/01/chakra-293x300.png 293w, https://dtaugury.wpengine.com/wp-content/uploads/2020/01/chakra-768x786.png 768w, https://dtaugury.wpengine.com/wp-content/uploads/2020/01/chakra-750x767.png 750w, https://dtaugury.wpengine.com/wp-content/uploads/2020/01/chakra-540x552.png 540w" sizes="(max-width: 919px) 100vw, 919px" />														</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-79e4e83 dt-skin-secondary-color elementor-widget elementor-widget-heading" data-id="79e4e83" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h4 class="elementor-heading-title elementor-size-default">Lorem Ipsum</h4>		</div>
				</div>
				<div class="elementor-element elementor-element-6b8fb85 elementor-widget elementor-widget-heading" data-id="6b8fb85" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Our Services</h2>		</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-d676024 title-bottom-content-wrapper elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="d676024" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;0d382a6&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-9f206e3" data-id="9f206e3" data-element_type="column">
			<div class="elementor-column-wrap">
							<div class="elementor-widget-wrap">
								</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-f394de4" data-id="f394de4" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-aee2470 elementor-widget elementor-widget-text-editor" data-id="aee2470" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.</p>					</div>
						</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-ced742d" data-id="ced742d" data-element_type="column">
			<div class="elementor-column-wrap">
							<div class="elementor-widget-wrap">
								</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<div class="elementor-element elementor-element-18d4521 elementor-widget elementor-widget-dt-advanced-carousel" data-id="18d4521" data-element_type="widget" data-settings="{&quot;dot_style&quot;:&quot;slick-dots style-4&quot;,&quot;slider_type&quot;:&quot;horizontal&quot;,&quot;slide_to_scroll&quot;:&quot;single&quot;,&quot;infinite_loop&quot;:&quot;yes&quot;,&quot;autoplay&quot;:&quot;yes&quot;,&quot;draggable&quot;:&quot;yes&quot;,&quot;touch_move&quot;:&quot;yes&quot;,&quot;adaptive_height&quot;:&quot;yes&quot;,&quot;pauseohover&quot;:&quot;yes&quot;,&quot;navigation&quot;:&quot;yes&quot;}" data-widget_type="dt-advanced-carousel.default">
				<div class="elementor-widget-container">
			<div class='dt-advanced-carousel-wrapper' data-settings='{"centerMode":false,"adaptiveHeight":true,"arrows":false,"autoplay":true,"dots":true,"dotsClass":"slick-dots style-4","draggable":true,"swipe":true,"infinite":true,"pauseOnDotsHover":true,"pauseOnFocus":false,"pauseOnHover":true,"slidesToScroll":1,"slidesToShow":3,"speed":300,"touchMove":true,"vertical":false,"desktopSlidesToShow":3,"desktopSlidesToScroll":1,"tabletSlidesToShow":null,"tabletSlidesToScroll":1,"mobileSlidesToShow":null,"mobileSlidesToScroll":1}'><div class="dt-advanced-carousel-item-wrapper">		<div data-elementor-type="page" data-elementor-id="20488" class="elementor elementor-20488">
						<div class="elementor-inner">
				<div class="elementor-section-wrap">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-39a37cc8 our-services-box elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="39a37cc8" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;7ee6690&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;],&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-581d7ade" data-id="581d7ade" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-73dfe88f dt-sc-smooth-transition elementor-position-top elementor-vertical-align-top elementor-widget elementor-widget-image-box" data-id="73dfe88f" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/01/services-icon1.png" title="services-icon1" alt="services-icon1" loading="lazy" /></figure><div class="elementor-image-box-content"><h3 class="elementor-image-box-title">Personal Consultation</h3><p class="elementor-image-box-description">Contrary to popular belief, Lorem Ipsum is not simply random text</p></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-7011684d elementor-align-center elementor-widget elementor-widget-button" data-id="7011684d" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-button-link elementor-size-sm" href="https://dtaugury.wpengine.com/our-services/personal-consultation/">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">View More</span>
		</span>
					</a>
		</div>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
									</div>
			</div>
					</div>
		</div><div class="dt-advanced-carousel-item-wrapper">		<div data-elementor-type="page" data-elementor-id="25218" class="elementor elementor-25218">
						<div class="elementor-inner">
				<div class="elementor-section-wrap">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-39a37cc8 our-services-box elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="39a37cc8" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;7ee6690&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;],&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-581d7ade" data-id="581d7ade" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-73dfe88f dt-sc-smooth-transition elementor-position-top elementor-vertical-align-top elementor-widget elementor-widget-image-box" data-id="73dfe88f" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/services-icon2.png" title="services-icon2" alt="services-icon2" loading="lazy" /></figure><div class="elementor-image-box-content"><h3 class="elementor-image-box-title">Kundli Dosha</h3><p class="elementor-image-box-description">Contrary to popular belief, Lorem Ipsum is not simply random text</p></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-7011684d elementor-align-center elementor-widget elementor-widget-button" data-id="7011684d" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-button-link elementor-size-sm" href="https://dtaugury.wpengine.com/our-services/daily-horoscope/">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">View More</span>
		</span>
					</a>
		</div>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
									</div>
			</div>
					</div>
		</div><div class="dt-advanced-carousel-item-wrapper">		<div data-elementor-type="page" data-elementor-id="25219" class="elementor elementor-25219">
						<div class="elementor-inner">
				<div class="elementor-section-wrap">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-39a37cc8 our-services-box elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="39a37cc8" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;7ee6690&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;],&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-581d7ade" data-id="581d7ade" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-73dfe88f dt-sc-smooth-transition elementor-position-top elementor-vertical-align-top elementor-widget elementor-widget-image-box" data-id="73dfe88f" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/services-icon3.png" title="services-icon3" alt="services-icon3" loading="lazy" /></figure><div class="elementor-image-box-content"><h3 class="elementor-image-box-title">Face Reading</h3><p class="elementor-image-box-description">Contrary to popular belief, Lorem Ipsum is not simply random text</p></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-7011684d elementor-align-center elementor-widget elementor-widget-button" data-id="7011684d" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-button-link elementor-size-sm" href="https://dtaugury.wpengine.com/our-services/kundli-dosha/">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">View More</span>
		</span>
					</a>
		</div>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
									</div>
			</div>
					</div>
		</div><div class="dt-advanced-carousel-item-wrapper">		<div data-elementor-type="page" data-elementor-id="25220" class="elementor elementor-25220">
						<div class="elementor-inner">
				<div class="elementor-section-wrap">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-39a37cc8 our-services-box elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="39a37cc8" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;7ee6690&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;],&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-581d7ade" data-id="581d7ade" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-73dfe88f dt-sc-smooth-transition elementor-position-top elementor-vertical-align-top elementor-widget elementor-widget-image-box" data-id="73dfe88f" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/services-icon4.png" title="services-icon4" alt="services-icon4" loading="lazy" /></figure><div class="elementor-image-box-content"><h3 class="elementor-image-box-title">Daily Horoscope</h3><p class="elementor-image-box-description">Contrary to popular belief, Lorem Ipsum is not simply random text</p></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-7011684d elementor-align-center elementor-widget elementor-widget-button" data-id="7011684d" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-button-link elementor-size-sm" href="https://dtaugury.wpengine.com/our-services/face-reading/">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">View More</span>
		</span>
					</a>
		</div>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
									</div>
			</div>
					</div>
		</div></div>		</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-2d423dc elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="2d423dc" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;f50855a&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-590c190" data-id="590c190" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-1c6afd6 section-divider elementor-widget elementor-widget-spacer" data-id="1c6afd6" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-c11e42e elementor-section-stretched elementor-section-full_width counter-section elementor-section-height-default elementor-section-height-default" data-id="c11e42e" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;db2d9cc&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-20 elementor-top-column elementor-element elementor-element-67388af dt-col-sm-4" data-id="67388af" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-8916b8b hide-after elementor-widget elementor-widget-counter" data-id="8916b8b" data-element_type="widget" data-widget_type="counter.default">
				<div class="elementor-widget-container">
					<div class="elementor-counter">
			<div class="elementor-counter-number-wrapper">
				<span class="elementor-counter-number-prefix"></span>
				<span class="elementor-counter-number" data-duration="2000" data-to-value="99" data-from-value="0" data-delimiter=",">0</span>
				<span class="elementor-counter-number-suffix">+</span>
			</div>
							<div class="elementor-counter-title">Trusted by <br>Million Clients</div>
					</div>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-20 elementor-top-column elementor-element elementor-element-81e1694 dt-col-sm-4" data-id="81e1694" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-f288b51 elementor-widget elementor-widget-counter" data-id="f288b51" data-element_type="widget" data-widget_type="counter.default">
				<div class="elementor-widget-container">
					<div class="elementor-counter">
			<div class="elementor-counter-number-wrapper">
				<span class="elementor-counter-number-prefix"></span>
				<span class="elementor-counter-number" data-duration="2000" data-to-value="45" data-from-value="0" data-delimiter=",">0</span>
				<span class="elementor-counter-number-suffix"></span>
			</div>
							<div class="elementor-counter-title">Years of <br>Experience</div>
					</div>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-20 elementor-top-column elementor-element elementor-element-5bb8773 dt-col-sm-4" data-id="5bb8773" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-cb57658 elementor-widget elementor-widget-counter" data-id="cb57658" data-element_type="widget" data-widget_type="counter.default">
				<div class="elementor-widget-container">
					<div class="elementor-counter">
			<div class="elementor-counter-number-wrapper">
				<span class="elementor-counter-number-prefix"></span>
				<span class="elementor-counter-number" data-duration="2000" data-to-value="50" data-from-value="0" data-delimiter=",">0</span>
				<span class="elementor-counter-number-suffix"></span>
			</div>
							<div class="elementor-counter-title">Types of <br>Horoscopes</div>
					</div>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-20 elementor-top-column elementor-element elementor-element-2cbee3e dt-col-sm-4 dt-col-sm-offset-2" data-id="2cbee3e" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-e2bcded elementor-widget elementor-widget-counter" data-id="e2bcded" data-element_type="widget" data-widget_type="counter.default">
				<div class="elementor-widget-container">
					<div class="elementor-counter">
			<div class="elementor-counter-number-wrapper">
				<span class="elementor-counter-number-prefix"></span>
				<span class="elementor-counter-number" data-duration="2000" data-to-value="99" data-from-value="0" data-delimiter=",">0</span>
				<span class="elementor-counter-number-suffix">+</span>
			</div>
							<div class="elementor-counter-title">Qualified <br>Astrologers</div>
					</div>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-20 elementor-top-column elementor-element elementor-element-3e46809 dt-col-sm-4" data-id="3e46809" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-19f458c last elementor-widget elementor-widget-counter" data-id="19f458c" data-element_type="widget" data-widget_type="counter.default">
				<div class="elementor-widget-container">
					<div class="elementor-counter">
			<div class="elementor-counter-number-wrapper">
				<span class="elementor-counter-number-prefix"></span>
				<span class="elementor-counter-number" data-duration="2000" data-to-value="86" data-from-value="0" data-delimiter=",">0</span>
				<span class="elementor-counter-number-suffix"></span>
			</div>
							<div class="elementor-counter-title">Success <br>Horoscope</div>
					</div>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-6f8eb4f elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="6f8eb4f" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;7cc03f3&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-449b48a" data-id="449b48a" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-a846109 section-divider elementor-widget elementor-widget-spacer" data-id="a846109" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-9219d12 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="9219d12" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;3e16bd6&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-4c731c0" data-id="4c731c0" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-1ebafb8 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="1ebafb8" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;0d382a6&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-c600bd2" data-id="c600bd2" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="jet-parallax-widget elementor-element elementor-element-849593b elementor-widget__width-auto elementor-absolute elementor-widget elementor-widget-image" data-jet-tricks-settings="{&quot;parallax&quot;:&quot;true&quot;,&quot;invert&quot;:&quot;false&quot;,&quot;speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;stickyOn&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}" data-id="849593b" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
												<img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/01/dark-moon-1.png" title="dark-moon" alt="dark-moon" loading="lazy" />														</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-dc83678 dt-skin-secondary-color elementor-widget elementor-widget-heading" data-id="dc83678" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h4 class="elementor-heading-title elementor-size-default">Lorem Ipsum</h4>		</div>
				</div>
				<div class="elementor-element elementor-element-b8f8bb7 elementor-widget elementor-widget-heading" data-id="b8f8bb7" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">What My Client Says</h2>		</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-edaa091 title-bottom-content-wrapper elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="edaa091" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;0d382a6&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-2d46f8f" data-id="2d46f8f" data-element_type="column">
			<div class="elementor-column-wrap">
							<div class="elementor-widget-wrap">
								</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-ae346ed" data-id="ae346ed" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-fd696af elementor-widget elementor-widget-text-editor" data-id="fd696af" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.</p>					</div>
						</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-2dce2ef" data-id="2dce2ef" data-element_type="column">
			<div class="elementor-column-wrap">
							<div class="elementor-widget-wrap">
								</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-2a0601f elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="2a0601f" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;0d382a6&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-c57d7b8" data-id="c57d7b8" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-1f04d7b testimonial-carousel elementor-widget elementor-widget-dt-advanced-carousel" data-id="1f04d7b" data-element_type="widget" data-settings="{&quot;slider_type&quot;:&quot;horizontal&quot;,&quot;slide_to_scroll&quot;:&quot;single&quot;,&quot;infinite_loop&quot;:&quot;yes&quot;,&quot;autoplay&quot;:&quot;yes&quot;,&quot;centermode&quot;:&quot;yes&quot;,&quot;draggable&quot;:&quot;yes&quot;,&quot;touch_move&quot;:&quot;yes&quot;,&quot;adaptive_height&quot;:&quot;yes&quot;,&quot;pauseohover&quot;:&quot;yes&quot;,&quot;arrows&quot;:&quot;yes&quot;,&quot;arrow_style&quot;:&quot;default&quot;}" data-widget_type="dt-advanced-carousel.default">
				<div class="elementor-widget-container">
			<div class='dt-advanced-carousel-wrapper' data-settings='{"centerMode":true,"adaptiveHeight":true,"arrows":true,"autoplay":true,"dots":false,"dotsClass":"slick-dots","draggable":true,"swipe":true,"infinite":true,"pauseOnDotsHover":true,"pauseOnFocus":false,"pauseOnHover":true,"slidesToScroll":1,"slidesToShow":3,"speed":300,"touchMove":true,"vertical":false,"desktopSlidesToShow":3,"desktopSlidesToScroll":1,"tabletSlidesToShow":null,"tabletSlidesToScroll":1,"mobileSlidesToShow":null,"mobileSlidesToScroll":1,"nextArrow":"<button type=\"button\" class=\"default slick-next\"> <span class=\"fas fa-chevron-right\"><\/span> <\/button>","prevArrow":"<button type=\"button\" class=\"default slick-prev\"> <span class=\"fas fa-chevron-left\"><\/span> <\/button>"}'><div class="dt-advanced-carousel-item-wrapper">		<div data-elementor-type="page" data-elementor-id="20526" class="elementor elementor-20526">
						<div class="elementor-inner">
				<div class="elementor-section-wrap">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-269803ef testimonial-wrapper elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="269803ef" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;7dfc0a4&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;],&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2a273259" data-id="2a273259" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-c6a9fdc testimonial-author elementor-widget elementor-widget-image" data-id="c6a9fdc" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
												<img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/01/author1.jpg" title="author1" alt="author1" loading="lazy" />														</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-10d86c14 elementor-widget elementor-widget-text-editor" data-id="10d86c14" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>					</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-6cd2492 author-name elementor-widget elementor-widget-heading" data-id="6cd2492" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h4 class="elementor-heading-title elementor-size-default">Ana Cerel</h4>		</div>
				</div>
				<div class="elementor-element elementor-element-243a7356 elementor-icon-list--layout-inline elementor-align-center elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="243a7356" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items elementor-inline-items">
							<li class="elementor-icon-list-item elementor-inline-item">
											<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 150 150" style="enable-background:new 0 0 150 150;" xml:space="preserve">
<circle style="fill:#FFFFFF;" cx="75" cy="75" r="22.3"></circle>
<g>
	<path style="fill:#FFFFFF;" d="M75,148.7c-40.6,0-73.7-33.1-73.7-73.7C1.3,34.4,34.4,1.3,75,1.3c40.6,0,73.7,33.1,73.7,73.7   C148.7,115.6,115.6,148.7,75,148.7z M75,14.7c-33.2,0-60.3,27.1-60.3,60.3c0,33.3,27.1,60.3,60.3,60.3c33.3,0,60.3-27,60.3-60.3   C135.3,41.8,108.3,14.7,75,14.7z"></path>
</g>
</svg>						</span>
										<span class="elementor-icon-list-text">Leo</span>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 150 150" style="enable-background:new 0 0 150 150;" xml:space="preserve">
<path style="fill:#FFFFFF;" d="M84.1,150V54.2h36.8L75,0L29.2,54.2h36.8V150L84.1,150L84.1,150z"></path>
</svg>						</span>
										<span class="elementor-icon-list-text">Virgo</span>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 150 150" style="enable-background:new 0 0 150 150;" xml:space="preserve">
<path style="fill:#FFFFFF;" d="M54.4,1.8c41.2,9.5,74.7,50.7,55,86.4c-20.2,36.6-63.3,43.1-99.1,23.4c-3.3-1.8-7-3.3-10.1-5.1  c8.8,17.8,24,31.5,42.7,38.3c39.9,15.4,84.8-3.3,102-42.4c15.1-37.9-3.4-80.9-41.3-96c-1-0.4-2.1-0.8-3.1-1.2  C85.6-0.3,69.7-1.5,54.4,1.8z"></path>
</svg>						</span>
										<span class="elementor-icon-list-text">Aries</span>
									</li>
						</ul>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
									</div>
			</div>
					</div>
		</div><div class="dt-advanced-carousel-item-wrapper">		<div data-elementor-type="page" data-elementor-id="25203" class="elementor elementor-25203">
						<div class="elementor-inner">
				<div class="elementor-section-wrap">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-269803ef testimonial-wrapper elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="269803ef" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;7dfc0a4&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;],&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2a273259" data-id="2a273259" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-c6a9fdc testimonial-author elementor-widget elementor-widget-image" data-id="c6a9fdc" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
												<img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/author2.jpg" title="author2" alt="author2" loading="lazy" />														</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-10d86c14 elementor-widget elementor-widget-text-editor" data-id="10d86c14" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>					</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-6cd2492 author-name elementor-widget elementor-widget-heading" data-id="6cd2492" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h4 class="elementor-heading-title elementor-size-default">Albi Rebin</h4>		</div>
				</div>
				<div class="elementor-element elementor-element-243a7356 elementor-icon-list--layout-inline elementor-align-center elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="243a7356" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items elementor-inline-items">
							<li class="elementor-icon-list-item elementor-inline-item">
											<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 150 150" style="enable-background:new 0 0 150 150;" xml:space="preserve">
<circle style="fill:#FFFFFF;" cx="75" cy="75" r="22.3"></circle>
<g>
	<path style="fill:#FFFFFF;" d="M75,148.7c-40.6,0-73.7-33.1-73.7-73.7C1.3,34.4,34.4,1.3,75,1.3c40.6,0,73.7,33.1,73.7,73.7   C148.7,115.6,115.6,148.7,75,148.7z M75,14.7c-33.2,0-60.3,27.1-60.3,60.3c0,33.3,27.1,60.3,60.3,60.3c33.3,0,60.3-27,60.3-60.3   C135.3,41.8,108.3,14.7,75,14.7z"></path>
</g>
</svg>						</span>
										<span class="elementor-icon-list-text">Leo</span>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 150 150" style="enable-background:new 0 0 150 150;" xml:space="preserve">
<path style="fill:#FFFFFF;" d="M84.1,150V54.2h36.8L75,0L29.2,54.2h36.8V150L84.1,150L84.1,150z"></path>
</svg>						</span>
										<span class="elementor-icon-list-text">Virgo</span>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 150 150" style="enable-background:new 0 0 150 150;" xml:space="preserve">
<path style="fill:#FFFFFF;" d="M54.4,1.8c41.2,9.5,74.7,50.7,55,86.4c-20.2,36.6-63.3,43.1-99.1,23.4c-3.3-1.8-7-3.3-10.1-5.1  c8.8,17.8,24,31.5,42.7,38.3c39.9,15.4,84.8-3.3,102-42.4c15.1-37.9-3.4-80.9-41.3-96c-1-0.4-2.1-0.8-3.1-1.2  C85.6-0.3,69.7-1.5,54.4,1.8z"></path>
</svg>						</span>
										<span class="elementor-icon-list-text">Aries</span>
									</li>
						</ul>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
									</div>
			</div>
					</div>
		</div><div class="dt-advanced-carousel-item-wrapper">		<div data-elementor-type="page" data-elementor-id="25204" class="elementor elementor-25204">
						<div class="elementor-inner">
				<div class="elementor-section-wrap">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-269803ef testimonial-wrapper elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="269803ef" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;7dfc0a4&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;],&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2a273259" data-id="2a273259" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-c6a9fdc testimonial-author elementor-widget elementor-widget-image" data-id="c6a9fdc" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
												<img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/author3.jpg" title="author3" alt="author3" loading="lazy" />														</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-10d86c14 elementor-widget elementor-widget-text-editor" data-id="10d86c14" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>					</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-6cd2492 author-name elementor-widget elementor-widget-heading" data-id="6cd2492" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h4 class="elementor-heading-title elementor-size-default">Cerel Jorge</h4>		</div>
				</div>
				<div class="elementor-element elementor-element-243a7356 elementor-icon-list--layout-inline elementor-align-center elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="243a7356" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items elementor-inline-items">
							<li class="elementor-icon-list-item elementor-inline-item">
											<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 150 150" style="enable-background:new 0 0 150 150;" xml:space="preserve">
<circle style="fill:#FFFFFF;" cx="75" cy="75" r="22.3"></circle>
<g>
	<path style="fill:#FFFFFF;" d="M75,148.7c-40.6,0-73.7-33.1-73.7-73.7C1.3,34.4,34.4,1.3,75,1.3c40.6,0,73.7,33.1,73.7,73.7   C148.7,115.6,115.6,148.7,75,148.7z M75,14.7c-33.2,0-60.3,27.1-60.3,60.3c0,33.3,27.1,60.3,60.3,60.3c33.3,0,60.3-27,60.3-60.3   C135.3,41.8,108.3,14.7,75,14.7z"></path>
</g>
</svg>						</span>
										<span class="elementor-icon-list-text">Leo</span>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 150 150" style="enable-background:new 0 0 150 150;" xml:space="preserve">
<path style="fill:#FFFFFF;" d="M84.1,150V54.2h36.8L75,0L29.2,54.2h36.8V150L84.1,150L84.1,150z"></path>
</svg>						</span>
										<span class="elementor-icon-list-text">Virgo</span>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 150 150" style="enable-background:new 0 0 150 150;" xml:space="preserve">
<path style="fill:#FFFFFF;" d="M54.4,1.8c41.2,9.5,74.7,50.7,55,86.4c-20.2,36.6-63.3,43.1-99.1,23.4c-3.3-1.8-7-3.3-10.1-5.1  c8.8,17.8,24,31.5,42.7,38.3c39.9,15.4,84.8-3.3,102-42.4c15.1-37.9-3.4-80.9-41.3-96c-1-0.4-2.1-0.8-3.1-1.2  C85.6-0.3,69.7-1.5,54.4,1.8z"></path>
</svg>						</span>
										<span class="elementor-icon-list-text">Aries</span>
									</li>
						</ul>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
									</div>
			</div>
					</div>
		</div><div class="dt-advanced-carousel-item-wrapper">		<div data-elementor-type="page" data-elementor-id="25232" class="elementor elementor-25232">
						<div class="elementor-inner">
				<div class="elementor-section-wrap">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-269803ef testimonial-wrapper elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="269803ef" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;7dfc0a4&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;],&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2a273259" data-id="2a273259" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-c6a9fdc testimonial-author elementor-widget elementor-widget-image" data-id="c6a9fdc" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
												<img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/02/author-4.jpg" title="author-4" alt="author-4" loading="lazy" />														</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-10d86c14 elementor-widget elementor-widget-text-editor" data-id="10d86c14" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>					</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-6cd2492 author-name elementor-widget elementor-widget-heading" data-id="6cd2492" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h4 class="elementor-heading-title elementor-size-default">Augstie Crisp</h4>		</div>
				</div>
				<div class="elementor-element elementor-element-243a7356 elementor-icon-list--layout-inline elementor-align-center elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="243a7356" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items elementor-inline-items">
							<li class="elementor-icon-list-item elementor-inline-item">
											<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 150 150" style="enable-background:new 0 0 150 150;" xml:space="preserve">
<circle style="fill:#FFFFFF;" cx="75" cy="75" r="22.3"></circle>
<g>
	<path style="fill:#FFFFFF;" d="M75,148.7c-40.6,0-73.7-33.1-73.7-73.7C1.3,34.4,34.4,1.3,75,1.3c40.6,0,73.7,33.1,73.7,73.7   C148.7,115.6,115.6,148.7,75,148.7z M75,14.7c-33.2,0-60.3,27.1-60.3,60.3c0,33.3,27.1,60.3,60.3,60.3c33.3,0,60.3-27,60.3-60.3   C135.3,41.8,108.3,14.7,75,14.7z"></path>
</g>
</svg>						</span>
										<span class="elementor-icon-list-text">Leo</span>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 150 150" style="enable-background:new 0 0 150 150;" xml:space="preserve">
<path style="fill:#FFFFFF;" d="M84.1,150V54.2h36.8L75,0L29.2,54.2h36.8V150L84.1,150L84.1,150z"></path>
</svg>						</span>
										<span class="elementor-icon-list-text">Virgo</span>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 150 150" style="enable-background:new 0 0 150 150;" xml:space="preserve">
<path style="fill:#FFFFFF;" d="M54.4,1.8c41.2,9.5,74.7,50.7,55,86.4c-20.2,36.6-63.3,43.1-99.1,23.4c-3.3-1.8-7-3.3-10.1-5.1  c8.8,17.8,24,31.5,42.7,38.3c39.9,15.4,84.8-3.3,102-42.4c15.1-37.9-3.4-80.9-41.3-96c-1-0.4-2.1-0.8-3.1-1.2  C85.6-0.3,69.7-1.5,54.4,1.8z"></path>
</svg>						</span>
										<span class="elementor-icon-list-text">Aries</span>
									</li>
						</ul>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
									</div>
			</div>
					</div>
		</div></div>		</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-49cd422 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="49cd422" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;3e16bd6&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-1ec4683" data-id="1ec4683" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-89cdf1b elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="89cdf1b" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;0d382a6&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-d266688" data-id="d266688" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-eb1c940 dt-skin-secondary-color elementor-widget elementor-widget-heading" data-id="eb1c940" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h4 class="elementor-heading-title elementor-size-default">Lorem Ipsum</h4>		</div>
				</div>
				<div class="elementor-element elementor-element-0d163bb elementor-widget elementor-widget-heading" data-id="0d163bb" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Best Books Form Our Author</h2>		</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-c2e23a4 title-bottom-content-wrapper elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="c2e23a4" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;0d382a6&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-833e489" data-id="833e489" data-element_type="column">
			<div class="elementor-column-wrap">
							<div class="elementor-widget-wrap">
								</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-3d0ed4f" data-id="3d0ed4f" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-8d3d6c6 elementor-widget elementor-widget-text-editor" data-id="8d3d6c6" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor Lorem ipsum dolor sit..</p>					</div>
						</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-7ffe8d9" data-id="7ffe8d9" data-element_type="column">
			<div class="elementor-column-wrap">
							<div class="elementor-widget-wrap">
								</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-8b666af elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="8b666af" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;0d382a6&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-357a8f8" data-id="357a8f8" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-5d61aa1 elementor-widget elementor-widget-dt-shop-products" data-id="5d61aa1" data-element_type="widget" data-widget_type="dt-shop-products.default">
				<div class="elementor-widget-container">
			<div class="dt-sc-products-container woocommerce  " ><ul class="products  product-style-default dt-augury-default  product-overlay-dark-bgcolor product-overlay-gradientbottomtotop product-hover-secimage-fade product-border-type-thumb product-border-position-default  product-padding-content product-with-space product-label-boxed product-thumb-alignment-bottom product-thumb-iconsgroup-style-brdrfill-rounded product-thumb-buttonelement-style-simple  product-content-alignment-center product-content-iconsgroup-style-simple product-content-buttonelement-style-brdrfill-rounded "><li class="product-grid-view product type-product post-20799 status-publish first instock product_cat-clothing has-post-thumbnail shipping-taxable product-type-simple">
	<div class="dt-col dt-col-xs-12 dt-col-sm-6 dt-col-md-6 dt-col-qxlg-4 dt-col-hxlg-3 dt-col-lg-3"><div class="product-wrapper" ><div class="product-thumb"><a class="image" href="https://dtaugury.wpengine.com/product/secret-in-the-north/" title="Secret in the North"><div class="product-thumb-overlay" ></div><div class="primary-image" style="background-image:url(https://dtaugury.wpengine.com/wp-content/uploads/2020/02/shop-6.jpg)"></div></a><div class="product-thumb-content" ><div class="product-buttons-wrapper product-icons"><div class="wc_inline_buttons"><div class="wcwl_btn_wrapper wc_btn_inline" data-tooltip="Wishlist">
<div
	class="yith-wcwl-add-to-wishlist add-to-wishlist-20799  wishlist-fragment on-first-load"
	data-fragment-ref="20799"
	data-fragment-options="{&quot;base_url&quot;:&quot;&quot;,&quot;in_default_wishlist&quot;:false,&quot;is_single&quot;:false,&quot;show_exists&quot;:false,&quot;product_id&quot;:&quot;20799&quot;,&quot;parent_product_id&quot;:20799,&quot;product_type&quot;:&quot;simple&quot;,&quot;show_view&quot;:false,&quot;browse_wishlist_text&quot;:&quot;Browse wishlist&quot;,&quot;already_in_wishslist_text&quot;:&quot;The product is already in your wishlist!&quot;,&quot;product_added_text&quot;:&quot;Product added!&quot;,&quot;heading_icon&quot;:&quot;&quot;,&quot;available_multi_wishlist&quot;:false,&quot;disable_wishlist&quot;:false,&quot;show_count&quot;:false,&quot;ajax_loading&quot;:false,&quot;loop_position&quot;:&quot;after_add_to_cart&quot;,&quot;item&quot;:&quot;add_to_wishlist&quot;}"
>

			<!-- ADD TO WISHLIST -->

<div class="yith-wcwl-add-button">
		<a
		href="?add_to_wishlist=20799&#038;_wpnonce=b1013c0c42"
		class="add_to_wishlist single_add_to_wishlist"
		data-product-id="20799"
		data-product-type="simple"
		data-original-product-id="20799"
		data-title="Add to wishlist"
		rel="nofollow"
	>
				<span>Add to wishlist</span>
	</a>
</div>

			<!-- COUNT TEXT -->

			</div>
</div><div class="wccm_btn_wrapper wc_btn_inline" data-tooltip="Compare"><a href="/?action=yith-woocompare-add-product&id=20799" class="button compare yith-woocompare-button" data-product_id="20799" rel="nofollow">Compare</a></div></div></div></div></div><div class="product-details"><div class="product-title"><h5><a href="https://dtaugury.wpengine.com/product/secret-in-the-north/">Secret in the North</a></h5></div><div class="product-buttons-wrapper product-button"><div class="wc_inline_buttons"><div class="wcct_btn_wrapper wc_btn_inline" data-tooltip="Add To Cart"><a href="https://dtaugury.wpengine.com/product/secret-in-the-north/" data-quantity="1" class="dt-sc-button too-small button product_type_simple" data-product_id="20799" data-product_sku="logo-collection" aria-label="Read more about &ldquo;Secret in the North&rdquo;" aria-describedby="" rel="nofollow">Read more</a></div></div></div></div><a href="#" class="button yith-wcqv-button" data-product_id="20799">Quick View</a></div></div></li>
<li class="product-grid-view product type-product post-20797 status-publish instock product_cat-tshirts has-post-thumbnail shipping-taxable purchasable product-type-simple">
	<div class="dt-col dt-col-xs-12 dt-col-sm-6 dt-col-md-6 dt-col-qxlg-4 dt-col-hxlg-3 dt-col-lg-3"><div class="product-wrapper" ><div class="product-thumb"><a class="image" href="https://dtaugury.wpengine.com/product/around-the-universe/" title="Around the Universe"><div class="product-thumb-overlay" ></div><div class="primary-image" style="background-image:url(https://dtaugury.wpengine.com/wp-content/uploads/2020/02/shop-11.jpg)"></div></a><div class="product-thumb-content" ><div class="product-buttons-wrapper product-icons"><div class="wc_inline_buttons"><div class="wcwl_btn_wrapper wc_btn_inline" data-tooltip="Wishlist">
<div
	class="yith-wcwl-add-to-wishlist add-to-wishlist-20797  wishlist-fragment on-first-load"
	data-fragment-ref="20797"
	data-fragment-options="{&quot;base_url&quot;:&quot;&quot;,&quot;in_default_wishlist&quot;:false,&quot;is_single&quot;:false,&quot;show_exists&quot;:false,&quot;product_id&quot;:&quot;20797&quot;,&quot;parent_product_id&quot;:20797,&quot;product_type&quot;:&quot;simple&quot;,&quot;show_view&quot;:false,&quot;browse_wishlist_text&quot;:&quot;Browse wishlist&quot;,&quot;already_in_wishslist_text&quot;:&quot;The product is already in your wishlist!&quot;,&quot;product_added_text&quot;:&quot;Product added!&quot;,&quot;heading_icon&quot;:&quot;&quot;,&quot;available_multi_wishlist&quot;:false,&quot;disable_wishlist&quot;:false,&quot;show_count&quot;:false,&quot;ajax_loading&quot;:false,&quot;loop_position&quot;:&quot;after_add_to_cart&quot;,&quot;item&quot;:&quot;add_to_wishlist&quot;}"
>

			<!-- ADD TO WISHLIST -->

<div class="yith-wcwl-add-button">
		<a
		href="?add_to_wishlist=20797&#038;_wpnonce=b1013c0c42"
		class="add_to_wishlist single_add_to_wishlist"
		data-product-id="20797"
		data-product-type="simple"
		data-original-product-id="20797"
		data-title="Add to wishlist"
		rel="nofollow"
	>
				<span>Add to wishlist</span>
	</a>
</div>

			<!-- COUNT TEXT -->

			</div>
</div><div class="wccm_btn_wrapper wc_btn_inline" data-tooltip="Compare"><a href="/?action=yith-woocompare-add-product&id=20797" class="button compare yith-woocompare-button" data-product_id="20797" rel="nofollow">Compare</a></div></div></div></div></div><div class="product-details"><div class="product-title"><h5><a href="https://dtaugury.wpengine.com/product/around-the-universe/">Around the Universe</a></h5></div><div class="product-buttons-wrapper product-button"><div class="wc_inline_buttons"><div class="wcct_btn_wrapper wc_btn_inline" data-tooltip="Add To Cart"><a href="?add-to-cart=20797" data-quantity="1" class="dt-sc-button too-small button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="20797" data-product_sku="Woo-tshirt-logo" aria-label="Add &ldquo;Around the Universe&rdquo; to your cart" aria-describedby="" rel="nofollow">Add to cart</a></div></div></div></div><a href="#" class="button yith-wcqv-button" data-product_id="20797">Quick View</a></div></div></li>
<li class="product-grid-view product type-product post-20790 status-publish instock product_cat-music has-post-thumbnail sale downloadable virtual purchasable product-type-simple">
	<div class="dt-col dt-col-xs-12 dt-col-sm-6 dt-col-md-6 dt-col-qxlg-4 dt-col-hxlg-3 dt-col-lg-3"><div class="product-wrapper" ><div class="product-thumb"><a class="image" href="https://dtaugury.wpengine.com/product/the-starborn-secrets/" title="The Starborn Secrets"><div class="product-thumb-overlay" ></div><div class="primary-image" style="background-image:url(https://dtaugury.wpengine.com/wp-content/uploads/2020/02/shop-10.jpg)"></div></a><div class="product-thumb-content" ><div class="product-buttons-wrapper product-icons"><div class="wc_inline_buttons"><div class="wcwl_btn_wrapper wc_btn_inline" data-tooltip="Wishlist">
<div
	class="yith-wcwl-add-to-wishlist add-to-wishlist-20790  wishlist-fragment on-first-load"
	data-fragment-ref="20790"
	data-fragment-options="{&quot;base_url&quot;:&quot;&quot;,&quot;in_default_wishlist&quot;:false,&quot;is_single&quot;:false,&quot;show_exists&quot;:false,&quot;product_id&quot;:&quot;20790&quot;,&quot;parent_product_id&quot;:20790,&quot;product_type&quot;:&quot;simple&quot;,&quot;show_view&quot;:false,&quot;browse_wishlist_text&quot;:&quot;Browse wishlist&quot;,&quot;already_in_wishslist_text&quot;:&quot;The product is already in your wishlist!&quot;,&quot;product_added_text&quot;:&quot;Product added!&quot;,&quot;heading_icon&quot;:&quot;&quot;,&quot;available_multi_wishlist&quot;:false,&quot;disable_wishlist&quot;:false,&quot;show_count&quot;:false,&quot;ajax_loading&quot;:false,&quot;loop_position&quot;:&quot;after_add_to_cart&quot;,&quot;item&quot;:&quot;add_to_wishlist&quot;}"
>

			<!-- ADD TO WISHLIST -->

<div class="yith-wcwl-add-button">
		<a
		href="?add_to_wishlist=20790&#038;_wpnonce=b1013c0c42"
		class="add_to_wishlist single_add_to_wishlist"
		data-product-id="20790"
		data-product-type="simple"
		data-original-product-id="20790"
		data-title="Add to wishlist"
		rel="nofollow"
	>
				<span>Add to wishlist</span>
	</a>
</div>

			<!-- COUNT TEXT -->

			</div>
</div><div class="wccm_btn_wrapper wc_btn_inline" data-tooltip="Compare"><a href="/?action=yith-woocompare-add-product&id=20790" class="button compare yith-woocompare-button" data-product_id="20790" rel="nofollow">Compare</a></div></div></div></div></div><div class="product-details"><div class="product-title"><h5><a href="https://dtaugury.wpengine.com/product/the-starborn-secrets/">The Starborn Secrets</a></h5></div><div class="product-buttons-wrapper product-button"><div class="wc_inline_buttons"><div class="wcct_btn_wrapper wc_btn_inline" data-tooltip="Add To Cart"><a href="?add-to-cart=20790" data-quantity="1" class="dt-sc-button too-small button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="20790" data-product_sku="woo-single" aria-label="Add &ldquo;The Starborn Secrets&rdquo; to your cart" aria-describedby="" rel="nofollow">Add to cart</a></div></div></div></div><a href="#" class="button yith-wcqv-button" data-product_id="20790">Quick View</a></div></div></li>
<li class="product-grid-view product type-product post-20789 status-publish last instock product_cat-music has-post-thumbnail downloadable virtual purchasable product-type-simple">
	<div class="dt-col dt-col-xs-12 dt-col-sm-6 dt-col-md-6 dt-col-qxlg-4 dt-col-hxlg-3 dt-col-lg-3"><div class="product-wrapper" ><div class="product-thumb"><a class="image" href="https://dtaugury.wpengine.com/product/the-modern-astrology/" title="The Modern Astrology"><div class="product-thumb-overlay" ></div><div class="primary-image" style="background-image:url(https://dtaugury.wpengine.com/wp-content/uploads/2020/02/Book1-1.jpg)"></div></a><div class="product-thumb-content" ><div class="product-buttons-wrapper product-icons"><div class="wc_inline_buttons"><div class="wcwl_btn_wrapper wc_btn_inline" data-tooltip="Wishlist">
<div
	class="yith-wcwl-add-to-wishlist add-to-wishlist-20789  wishlist-fragment on-first-load"
	data-fragment-ref="20789"
	data-fragment-options="{&quot;base_url&quot;:&quot;&quot;,&quot;in_default_wishlist&quot;:false,&quot;is_single&quot;:false,&quot;show_exists&quot;:false,&quot;product_id&quot;:&quot;20789&quot;,&quot;parent_product_id&quot;:20789,&quot;product_type&quot;:&quot;simple&quot;,&quot;show_view&quot;:false,&quot;browse_wishlist_text&quot;:&quot;Browse wishlist&quot;,&quot;already_in_wishslist_text&quot;:&quot;The product is already in your wishlist!&quot;,&quot;product_added_text&quot;:&quot;Product added!&quot;,&quot;heading_icon&quot;:&quot;&quot;,&quot;available_multi_wishlist&quot;:false,&quot;disable_wishlist&quot;:false,&quot;show_count&quot;:false,&quot;ajax_loading&quot;:false,&quot;loop_position&quot;:&quot;after_add_to_cart&quot;,&quot;item&quot;:&quot;add_to_wishlist&quot;}"
>

			<!-- ADD TO WISHLIST -->

<div class="yith-wcwl-add-button">
		<a
		href="?add_to_wishlist=20789&#038;_wpnonce=b1013c0c42"
		class="add_to_wishlist single_add_to_wishlist"
		data-product-id="20789"
		data-product-type="simple"
		data-original-product-id="20789"
		data-title="Add to wishlist"
		rel="nofollow"
	>
				<span>Add to wishlist</span>
	</a>
</div>

			<!-- COUNT TEXT -->

			</div>
</div><div class="wccm_btn_wrapper wc_btn_inline" data-tooltip="Compare"><a href="/?action=yith-woocompare-add-product&id=20789" class="button compare yith-woocompare-button" data-product_id="20789" rel="nofollow">Compare</a></div></div></div></div></div><div class="product-details"><div class="product-title"><h5><a href="https://dtaugury.wpengine.com/product/the-modern-astrology/">The Modern Astrology</a></h5></div><div class="product-buttons-wrapper product-button"><div class="wc_inline_buttons"><div class="wcct_btn_wrapper wc_btn_inline" data-tooltip="Add To Cart"><a href="?add-to-cart=20789" data-quantity="1" class="dt-sc-button too-small button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="20789" data-product_sku="woo-album" aria-label="Add &ldquo;The Modern Astrology&rdquo; to your cart" aria-describedby="" rel="nofollow">Add to cart</a></div></div></div></div><a href="#" class="button yith-wcqv-button" data-product_id="20789">Quick View</a></div></div></li>
</ul></div>		</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-cc79a2b elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="cc79a2b" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;463cdc6&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-4bbd258" data-id="4bbd258" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-5d326ea section-divider elementor-widget elementor-widget-spacer" data-id="5d326ea" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-f10af8b elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="f10af8b" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;29e7507&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}],&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-bf8d22c" data-id="bf8d22c" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="jet-parallax-widget elementor-element elementor-element-8ad355e elementor-widget__width-auto elementor-absolute elementor-widget elementor-widget-image" data-jet-tricks-settings="{&quot;parallax&quot;:&quot;true&quot;,&quot;invert&quot;:&quot;false&quot;,&quot;speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:20,&quot;sizes&quot;:[]},&quot;stickyOn&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}" data-id="8ad355e" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
												<img decoding="async" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/01/light-moon.png" title="light-moon" alt="light-moon" loading="lazy" />														</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-8f74bfa elementor-widget elementor-widget-heading" data-id="8f74bfa" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Get in Touch</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-ae5dd92 elementor-widget elementor-widget-shortcode" data-id="ae5dd92" data-element_type="widget" data-widget_type="shortcode.default">
				<div class="elementor-widget-container">
					<div class="elementor-shortcode">
<div class="wpcf7 no-js" id="wpcf7-f20560-p20398-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="/#wpcf7-f20560-p20398-o1" method="post" class="wpcf7-form init" aria-label="Contact form" novalidate="novalidate" data-status="init">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="20560" />
<input type="hidden" name="_wpcf7_version" value="5.7.7" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f20560-p20398-o1" />
<input type="hidden" name="_wpcf7_container_post" value="20398" />
<input type="hidden" name="_wpcf7_posted_data_hash" value="" />
</div>
<div class="dt-sc-one-third first column">
	<p><span class="wpcf7-form-control-wrap" data-name="text-758"><input size="40" class="wpcf7-form-control wpcf7-text" aria-invalid="false" placeholder="Name" value="" type="text" name="text-758" /></span>
	</p>
</div>
<div class="dt-sc-one-third column">
	<p><span class="wpcf7-form-control-wrap" data-name="email-20"><input size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-email" aria-invalid="false" placeholder="Your email Address" value="" type="email" name="email-20" /></span>
	</p>
</div>
<div class="dt-sc-one-fourth column">
	<p><input class="wpcf7-form-control has-spinner wpcf7-submit" type="submit" value="Get Notified" />
	</p>
</div><div class="wpcf7-response-output" aria-hidden="true"></div>
</form>
</div>
</div>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-e513916 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="e513916" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;463cdc6&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-c9bd705" data-id="c9bd705" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-7f5480a elementor-widget elementor-widget-spacer" data-id="7f5480a" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
									</div>
			</div>
					</div>
		</div><!-- #post-20398 -->
        </section><!-- Primary End -->    </div>
    <!-- ** Container End ** -->

</div><!-- **Main - End ** -->

        <!-- **Footer** -->
        <footer id="footer">
            <div class="container">
            		<div data-elementor-type="wp-post" data-elementor-id="20331" class="elementor elementor-20331">
						<div class="elementor-inner">
				<div class="elementor-section-wrap">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-4837477 elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="4837477" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;],&quot;_id&quot;:&quot;8d52a2a&quot;,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;}],&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-08493d0" data-id="08493d0" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-77224d7 footer-section elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="77224d7" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;89da19e&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;],&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-db41ec0" data-id="db41ec0" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-33ec241 elementor-widget elementor-widget-heading" data-id="33ec241" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Tarot, Predictions & Horoscope</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-5f2c516 elementor-align-left elementor-mobile-align-center elementor-widget elementor-widget-button" data-id="5f2c516" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-button-link elementor-size-sm" href="https://dtaugury.wpengine.com/appointment/">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">Fix Appointment</span>
		</span>
					</a>
		</div>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-20169cf" data-id="20169cf" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-606c4c8 elementor-widget elementor-widget-image" data-id="606c4c8" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
												<img width="336" height="100" src="https://dtaugury.wpengine.com/wp-content/uploads/2020/01/logo-1.png" class="attachment-full size-full wp-image-25367" alt="" loading="lazy" srcset="https://dtaugury.wpengine.com/wp-content/uploads/2020/01/logo-1.png 336w, https://dtaugury.wpengine.com/wp-content/uploads/2020/01/logo-1-300x89.png 300w" sizes="(max-width: 336px) 100vw, 336px" />														</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-e0268d4 elementor-widget elementor-widget-heading" data-id="e0268d4" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Astrology reveals the will of the gods</h2>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-2abc461" data-id="2abc461" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-8be958c elementor-widget elementor-widget-heading" data-id="8be958c" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Follow Us On Social</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-85e1c24 e-grid-align-right footer-social-share e-grid-align-mobile-center elementor-shape-rounded elementor-grid-0 elementor-widget elementor-widget-social-icons" data-id="85e1c24" data-element_type="widget" data-widget_type="social-icons.default">
				<div class="elementor-widget-container">
					<div class="elementor-social-icons-wrapper elementor-grid">
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-facebook-square elementor-animation-pop elementor-repeater-item-2356560" href="https://www.facebook.com/PremiumSitetemplates/" target="_blank">
						<span class="elementor-screen-only">Facebook-square</span>
						<i class="fab fa-facebook-square"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-twitter elementor-animation-pop elementor-repeater-item-86d9915" href="https://twitter.com/IamdesigningWeb" target="_blank">
						<span class="elementor-screen-only">Twitter</span>
						<i class="fab fa-twitter"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-instagram elementor-animation-pop elementor-repeater-item-0d9ce95" href="https://www.instagram.com/iamdesigning6428/" target="_blank">
						<span class="elementor-screen-only">Instagram</span>
						<i class="fab fa-instagram"></i>					</a>
				</span>
					</div>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-9784735 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="9784735" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;89da19e&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;],&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;}]}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-2ccb4d9" data-id="2ccb4d9" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-a7f848b elementor-widget elementor-widget-spacer" data-id="a7f848b" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-c547f60 elementor-widget elementor-widget-heading" data-id="c547f60" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">© 2020. All Rights Reserved. Augury Theme</h2>		</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
									</div>
			</div>
					</div>
		            </div>
        </footer><!-- **Footer - End** -->

    </div><!-- **Inner Wrapper - End** -->

</div><!-- **Wrapper - End** -->

		<script>
			window.RS_MODULES = window.RS_MODULES || {};
			window.RS_MODULES.modules = window.RS_MODULES.modules || {};
			window.RS_MODULES.waiting = window.RS_MODULES.waiting || [];
			window.RS_MODULES.defered = true;
			window.RS_MODULES.moduleWaiting = window.RS_MODULES.moduleWaiting || {};
			window.RS_MODULES.type = 'compiled';
		</script>

<div id="yith-quick-view-modal">
	<div class="yith-quick-view-overlay"></div>
	<div class="yith-wcqv-wrapper">
		<div class="yith-wcqv-main">
			<div class="yith-wcqv-head">
				<a href="#" id="yith-quick-view-close" class="yith-wcqv-close">X</a>
			</div>
			<div id="yith-quick-view-content" class="woocommerce single-product"></div>
		</div>
	</div>
</div>
<link href="https://fonts.googleapis.com/css?family=Roboto:400%7CJosefin+Sans:600%2C300&display=swap" rel="stylesheet" property="stylesheet" media="all" type="text/css" >

	<script type="text/javascript">
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
	<script>
		if(typeof revslider_showDoubleJqueryError === "undefined") {function revslider_showDoubleJqueryError(sliderID) {console.log("You have some jquery.js library include that comes after the Slider Revolution files js inclusion.");console.log("To fix this, you can:");console.log("1. Set 'Module General Options' -> 'Advanced' -> 'jQuery & OutPut Filters' -> 'Put JS to Body' to on");console.log("2. Find the double jQuery.js inclusion and remove it");return "Double Included jQuery Library";}}
</script>

<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="pswp__bg"></div>
	<div class="pswp__scroll-wrap">
		<div class="pswp__container">
			<div class="pswp__item"></div>
			<div class="pswp__item"></div>
			<div class="pswp__item"></div>
		</div>
		<div class="pswp__ui pswp__ui--hidden">
			<div class="pswp__top-bar">
				<div class="pswp__counter"></div>
				<button class="pswp__button pswp__button--close" aria-label="Close (Esc)"></button>
				<button class="pswp__button pswp__button--share" aria-label="Share"></button>
				<button class="pswp__button pswp__button--fs" aria-label="Toggle fullscreen"></button>
				<button class="pswp__button pswp__button--zoom" aria-label="Zoom in/out"></button>
				<div class="pswp__preloader">
					<div class="pswp__preloader__icn">
						<div class="pswp__preloader__cut">
							<div class="pswp__preloader__donut"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
				<div class="pswp__share-tooltip"></div>
			</div>
			<button class="pswp__button pswp__button--arrow--left" aria-label="Previous (arrow left)"></button>
			<button class="pswp__button pswp__button--arrow--right" aria-label="Next (arrow right)"></button>
			<div class="pswp__caption">
				<div class="pswp__caption__center"></div>
			</div>
		</div>
	</div>
</div>
<script type="text/template" id="tmpl-variation-template">
	<div class="woocommerce-variation-description">data.variation.variation_description</div>
	<div class="woocommerce-variation-price">data.variation.price_html</div>
	<div class="woocommerce-variation-availability">data.variation.availability_html</div>
</script>
<script type="text/template" id="tmpl-unavailable-variation-template">
	<p>Sorry, this product is unavailable. Please choose a different combination.</p>
</script>
<link rel='stylesheet' id='elementor-post-20376-css' href='https://dtaugury.wpengine.com/wp-content/uploads/elementor/css/post-20376.css?ver=1692845412' type='text/css' media='all' />

<link rel='stylesheet' id='elementor-post-20488-css' href='https://dtaugury.wpengine.com/wp-content/uploads/elementor/css/post-20488.css?ver=1692845412' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-25493-css' href='https://dtaugury.wpengine.com/wp-content/uploads/elementor/css/post-25493.css?ver=1692845412' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-25498-css' href='https://dtaugury.wpengine.com/wp-content/uploads/elementor/css/post-25498.css?ver=1692845412' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-shared-0-css' href='https://dtaugury.wpengine.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min.css?ver=5.15.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-solid-css' href='https://dtaugury.wpengine.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.min.css?ver=5.15.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-25218-css' href='https://dtaugury.wpengine.com/wp-content/uploads/elementor/css/post-25218.css?ver=1692845413' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-25219-css' href='https://dtaugury.wpengine.com/wp-content/uploads/elementor/css/post-25219.css?ver=1692845413' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-25220-css' href='https://dtaugury.wpengine.com/wp-content/uploads/elementor/css/post-25220.css?ver=1692845413' type='text/css' media='all' />
<link rel='stylesheet' id='slick-css' href='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-core/css/slick.css?ver=1.0' type='text/css' media='all' />
<link rel='stylesheet' id='dt-advanced-carousel-css' href='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-core/css/dt-advanced-carousel.css?ver=1.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-20526-css' href='https://dtaugury.wpengine.com/wp-content/uploads/elementor/css/post-20526.css?ver=1692845413' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-25203-css' href='https://dtaugury.wpengine.com/wp-content/uploads/elementor/css/post-25203.css?ver=1692845413' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-25204-css' href='https://dtaugury.wpengine.com/wp-content/uploads/elementor/css/post-25204.css?ver=1692845414' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-25232-css' href='https://dtaugury.wpengine.com/wp-content/uploads/elementor/css/post-25232.css?ver=1692845414' type='text/css' media='all' />
<link rel='stylesheet' id='dtel-products-css' href='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-core/widgets/modules/woocommerce/products/style.css?ver=1.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-20331-css' href='https://dtaugury.wpengine.com/wp-content/uploads/elementor/css/post-20331.css?ver=1692845414' type='text/css' media='all' />
<link rel='stylesheet' id='photoswipe-css' href='https://dtaugury.wpengine.com/wp-content/plugins/woocommerce/assets/css/photoswipe/photoswipe.min.css?ver=7.9.0' type='text/css' media='all' />
<link rel='stylesheet' id='photoswipe-default-skin-css' href='https://dtaugury.wpengine.com/wp-content/plugins/woocommerce/assets/css/photoswipe/default-skin/default-skin.min.css?ver=7.9.0' type='text/css' media='all' />
<link rel='stylesheet' id='e-animations-css' href='https://dtaugury.wpengine.com/wp-content/plugins/elementor/assets/lib/animations/animations.min.css?ver=3.14.1' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-brands-css' href='https://dtaugury.wpengine.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.min.css?ver=5.15.3' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css' href='https://dtaugury.wpengine.com/wp-content/plugins/revslider/public/assets/css/rs6.css?ver=6.6.13' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
		@keyframes move-twink-back{from{background-position:0 0}to{background-position:-10000px 5000px}}@-webkit-keyframes move-twink-back{from{background-position:0 0}to{background-position:-10000px 5000px}}@-moz-keyframes move-twink-back{from{background-position:0 0}to{background-position:-10000px 5000px}}@-ms-keyframes move-twink-back{from{background-position:0 0}to{background-position:-10000px 5000px}}.stars,.twinkling,.clouds{position:absolute; top:0; left:0; right:0; bottom:0; width:100%; height:100%; display:block}.stars{background:#0f0f0f url(https://dtaugury.wpengine.com/wp-content/uploads/2018/02/stars.png) repeat top center; z-index:0}.twinkling{background:transparent url(https://dtaugury.wpengine.com/wp-content/uploads/2018/02/twinkling2.png) repeat top center; z-index:1; -moz-animation:move-twink-back 200s linear infinite; -ms-animation:move-twink-back 200s linear infinite; -o-animation:move-twink-back 200s linear infinite; -webkit-animation:move-twink-back 200s linear infinite; animation:move-twink-back 200s linear infinite}
</style>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/yith-woocommerce-wishlist/assets/js/jquery.selectBox.min.js?ver=1.2.0' id='jquery-selectBox-js'></script>
<script type='text/javascript' src='//dtaugury.wpengine.com/wp-content/plugins/woocommerce/assets/js/prettyPhoto/jquery.prettyPhoto.min.js?ver=3.1.6' id='prettyPhoto-js'></script>
<script type='text/javascript' id='jquery-yith-wcwl-js-extra'>
/* <![CDATA[ */
var yith_wcwl_l10n = {"ajax_url":"\/wp-admin\/admin-ajax.php","redirect_to_cart":"no","yith_wcwl_button_position":"after_add_to_cart","multi_wishlist":"","hide_add_button":"1","enable_ajax_loading":"","ajax_loader_url":"https:\/\/dtaugury.wpengine.com\/wp-content\/plugins\/yith-woocommerce-wishlist\/assets\/images\/ajax-loader-alt.svg","remove_from_wishlist_after_add_to_cart":"1","is_wishlist_responsive":"1","time_to_close_prettyphoto":"3000","fragments_index_glue":".","reload_on_found_variation":"1","mobile_media_query":"768","labels":{"cookie_disabled":"We are sorry, but this feature is available only if cookies on your browser are enabled.","added_to_cart_message":"<div class=\"woocommerce-notices-wrapper\"><div class=\"woocommerce-message\" role=\"alert\">Product added to cart successfully<\/div><\/div>"},"actions":{"add_to_wishlist_action":"add_to_wishlist","remove_from_wishlist_action":"remove_from_wishlist","reload_wishlist_and_adding_elem_action":"reload_wishlist_and_adding_elem","load_mobile_action":"load_mobile","delete_item_action":"delete_item","save_title_action":"save_title","save_privacy_action":"save_privacy","load_fragments":"load_fragments"},"nonce":{"add_to_wishlist_nonce":"b1013c0c42","remove_from_wishlist_nonce":"1a6afa1055","reload_wishlist_and_adding_elem_nonce":"f702a7ef60","load_mobile_nonce":"f4a7f18ccc","delete_item_nonce":"c003d98434","save_title_nonce":"e7b2afec7b","save_privacy_nonce":"549763cd7e","load_fragments_nonce":"0b06847d41"},"redirect_after_ask_estimate":"","ask_estimate_redirect_url":"https:\/\/dtaugury.wpengine.com"};
/* ]]> */
</script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/yith-woocommerce-wishlist/assets/js/jquery.yith-wcwl.min.js?ver=3.23.0' id='jquery-yith-wcwl-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=5.7.7' id='swv-js'></script>
<script type='text/javascript' id='contact-form-7-js-extra'>
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/dtaugury.wpengine.com\/wp-json\/","namespace":"contact-form-7\/v1"},"cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.7.7' id='contact-form-7-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-booking-manager/vc/js/booking.js?ver=6.3' id='dt-booking-manager-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-includes/js/jquery/ui/core.min.js?ver=1.13.2' id='jquery-ui-core-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-includes/js/jquery/ui/datepicker.min.js?ver=1.13.2' id='jquery-ui-datepicker-js'></script>
<script id="jquery-ui-datepicker-js-after" type="text/javascript">
jQuery(function(jQuery){jQuery.datepicker.setDefaults({"closeText":"Close","currentText":"Today","monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"nextText":"Next","prevText":"Previous","dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"dateFormat":"MM d, yy","firstDay":1,"isRTL":false});});
</script>
<script type='text/javascript' id='dt-reservation-js-extra'>
/* <![CDATA[ */
var dtBookingManager = {"ajaxurl":"https:\/\/dtaugury.wpengine.com\/wp-admin\/admin-ajax.php","plugin_url":"https:\/\/dtaugury.wpengine.com\/wp-content\/plugins\/designthemes-booking-manager\/vc\/","eraptdatepicker":"Please Select Service and Date"};
/* ]]> */
</script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-booking-manager/vc/js/reservation.js?ver=6.3' id='dt-reservation-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-booking-manager/vc/js/jquery.validate.min.js?ver=6.3' id='jquery-validate-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-fb-pixel/script.js?ver=6.3' id='dt-fbpixel-script-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-portfolio-addon/js/jquery.plugins.js?ver=6.3' id='dtportfolio-plugins-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-portfolio-addon/js/isotope.pkgd.min.js?ver=6.3' id='dtportfolio-isotope-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-portfolio-addon/js/jquery.fullPage.min.js?ver=6.3' id='dtportfolio-fullpage-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-portfolio-addon/js/ilightbox.min.js?ver=6.3' id='dtportfolio-ilightbox-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-portfolio-addon/js/jarallax.js?ver=6.3' id='dtportfolio-jarallax-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-portfolio-addon/js/jquery.multiscroll.min.js?ver=6.3' id='dtportfolio-multiscroll-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-portfolio-addon/js/jquery.inview.js?ver=6.3' id='dtportfolio-inview-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-portfolio-addon/js/swiper.min.js?ver=6.3' id='dtportfolio-swiper-js'></script>
<script type='text/javascript' id='dtportfolio-frontend-js-extra'>
/* <![CDATA[ */
var dtportfoliofrontendobject = {"ajaxurl":"https:\/\/dtaugury.wpengine.com\/wp-admin\/admin-ajax.php","page_builder":"elementor","elementor_preview_mode":""};
/* ]]> */
</script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-portfolio-addon/js/frontend.js?ver=6.3' id='dtportfolio-frontend-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/revslider/public/assets/js/rbtools.min.js?ver=6.6.13' defer async id='tp-tools-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/revslider/public/assets/js/rs6.min.js?ver=6.6.13' defer async id='revmin-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.7.0-wc.7.9.0' id='jquery-blockui-js'></script>
<script type='text/javascript' id='wc-add-to-cart-js-extra'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/dtaugury.wpengine.com\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=7.9.0' id='wc-add-to-cart-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4-wc.7.9.0' id='js-cookie-js'></script>
<script type='text/javascript' id='woocommerce-js-extra'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=7.9.0' id='woocommerce-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-core/privacy/js/jquery.tabs.min.js?ver=6.3' id='jquery.tabs-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-core/privacy/js/privacy.js?ver=6.3' id='dt.privacy.script-js'></script>
<script type='text/javascript' id='yith-woocompare-main-js-extra'>
/* <![CDATA[ */
var yith_woocompare = {"ajaxurl":"\/?wc-ajax=%%endpoint%%","actionadd":"yith-woocompare-add-product","actionremove":"yith-woocompare-remove-product","actionview":"yith-woocompare-view-table","actionreload":"yith-woocompare-reload-product","added_label":"Added","table_title":"Product Comparison","auto_open":"yes","loader":"https:\/\/dtaugury.wpengine.com\/wp-content\/plugins\/yith-woocommerce-compare\/assets\/images\/loader.gif","button_text":"Compare","cookie_name":"yith_woocompare_list_1","close_label":"Close"};
/* ]]> */
</script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/yith-woocommerce-compare/assets/js/woocompare.min.js?ver=2.27.0' id='yith-woocompare-main-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/yith-woocommerce-compare/assets/js/jquery.colorbox-min.js?ver=1.4.21' id='jquery-colorbox-js'></script>
<script type='text/javascript' id='yith-wcqv-frontend-js-extra'>
/* <![CDATA[ */
var yith_qv = {"ajaxurl":"\/wp-admin\/admin-ajax.php","loader":"https:\/\/dtaugury.wpengine.com\/wp-content\/plugins\/yith-woocommerce-quick-view\/assets\/image\/qv-loader.gif","lang":""};
/* ]]> */
</script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/yith-woocommerce-quick-view/assets/js/frontend.min.js?ver=1.29.0' id='yith-wcqv-frontend-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/jquery.ui.totop.min.js?ver=6.3' id='jquery-ui-totop-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/jquery.easing.js?ver=6.3' id='jquery-easing-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/jquery.caroufredsel.js?ver=6.3' id='jquery-caroufredsel-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/jquery.debouncedresize.js?ver=6.3' id='jquery-debouncedresize-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/jquery.prettyphoto.js?ver=6.3' id='jquery-prettyphoto-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/jquery.touchswipe.js?ver=6.3' id='jquery-touchswipe-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/jquery.parallax.js?ver=6.3' id='jquery-parallax-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/jquery.downcount.js?ver=6.3' id='jquery-downcount-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/jquery.nicescroll.js?ver=6.3' id='jquery-nicescroll-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/jquery.bxslider.js?ver=6.3' id='jquery-bxslider-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/jquery.fitvids.js?ver=6.3' id='jquery-fitvids-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/jquery.simple-sidebar.js?ver=6.3' id='jquery-simple-sidebar-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/jquery.classie.js?ver=6.3' id='jquery-classie-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/jquery.placeholder.js?ver=6.3' id='jquery-placeholder-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/jquery.visualNav.min.js?ver=6.3' id='jquery-visualnav-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/ResizeSensor.min.js?ver=6.3' id='resizesensor-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/theia-sticky-sidebar.min.js?ver=6.3' id='theia-sticky-sidebar-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/matchHeight.js?ver=6.3' id='matchheight-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/jquery.waypoints.min.js?ver=6.3' id='jquery-waypoints-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/jquery.inview.js?ver=6.3' id='jquery-inview-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/isotope.pkgd.min.js?ver=6.3' id='isotope-pkgd-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/magnific/jquery.magnific-popup.min.js?ver=6.3' id='jquery-magnific-popup-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/woocommerce.js?ver=6.3' id='augury-woocommerce-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/themes/augury/framework/js/custom.js?ver=6.3' id='augury-jqcustom-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-core/js/slick.min.js?ver=1.0' id='slick-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-core/js/dt-advanced-carousel.js?ver=1.0' id='dt-advanced-carousel-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/elementor/assets/lib/jquery-numerator/jquery-numerator.min.js?ver=0.2.1' id='jquery-numerator-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/designthemes-core/widgets/modules/woocommerce/products/script.js?ver=1.0' id='dtel-products-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-includes/js/underscore.min.js?ver=1.13.4' id='underscore-js'></script>
<script type='text/javascript' id='wp-util-js-extra'>
/* <![CDATA[ */
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-includes/js/wp-util.min.js?ver=6.3' id='wp-util-js'></script>
<script type='text/javascript' id='wc-add-to-cart-variation-js-extra'>
/* <![CDATA[ */
var wc_add_to_cart_variation_params = {"wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_no_matching_variations_text":"Sorry, no products matched your selection. Please choose a different combination.","i18n_make_a_selection_text":"Please select some product options before adding this product to your cart.","i18n_unavailable_text":"Sorry, this product is unavailable. Please choose a different combination."};
/* ]]> */
</script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart-variation.min.js?ver=7.9.0' id='wc-add-to-cart-variation-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/woocommerce/assets/js/zoom/jquery.zoom.min.js?ver=1.7.21-wc.7.9.0' id='zoom-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/woocommerce/assets/js/photoswipe/photoswipe.min.js?ver=4.1.1-wc.7.9.0' id='photoswipe-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/woocommerce/assets/js/photoswipe/photoswipe-ui-default.min.js?ver=4.1.1-wc.7.9.0' id='photoswipe-ui-default-js'></script>
<script type='text/javascript' id='wc-single-product-js-extra'>
/* <![CDATA[ */
var wc_single_product_params = {"i18n_required_rating_text":"Please select a rating","review_rating_required":"yes","flexslider":{"rtl":false,"animation":"slide","smoothHeight":true,"directionNav":false,"controlNav":"thumbnails","slideshow":false,"animationSpeed":500,"animationLoop":false,"allowOneSlide":false},"zoom_enabled":"1","zoom_options":[],"photoswipe_enabled":"1","photoswipe_options":{"shareEl":false,"closeOnScroll":false,"history":false,"hideAnimationDuration":0,"showAnimationDuration":0},"flexslider_enabled":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/woocommerce/assets/js/frontend/single-product.min.js?ver=7.9.0' id='wc-single-product-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.14.1' id='elementor-webpack-runtime-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.14.1' id='elementor-frontend-modules-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2' id='elementor-waypoints-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=5.3.6' id='swiper-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/elementor/assets/lib/share-link/share-link.min.js?ver=3.14.1' id='share-link-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/elementor/assets/lib/dialog/dialog.min.js?ver=4.9.0' id='elementor-dialog-js'></script>
<script id="elementor-frontend-js-before" type="text/javascript">
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close","a11yCarouselWrapperAriaLabel":"Carousel | Horizontal scrolling: Arrow Left & Right","a11yCarouselPrevSlideMessage":"Previous slide","a11yCarouselNextSlideMessage":"Next slide","a11yCarouselFirstSlideMessage":"This is the first slide","a11yCarouselLastSlideMessage":"This is the last slide","a11yCarouselPaginationBulletMessage":"Go to slide"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}},"version":"3.14.1","is_static":false,"experimentalFeatures":{"a11y_improvements":true,"additional_custom_breakpoints":true,"landing-pages":true},"urls":{"assets":"https:\/\/dtaugury.wpengine.com\/wp-content\/plugins\/elementor\/assets\/"},"swiperClass":"swiper-container","settings":{"page":[],"editorPreferences":[]},"kit":{"global_image_lightbox":"yes","active_breakpoints":["viewport_mobile","viewport_tablet"],"lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":20398,"title":"Augury%20WordPress%20Theme%20%E2%80%93%20Your%20SUPER-powered%20WP%20Engine%20Site","excerpt":"","featuredImage":false}};
</script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.14.1' id='elementor-frontend-js'></script>
<script type='text/javascript' id='jet-elements-js-extra'>
/* <![CDATA[ */
var jetElements = {"ajaxUrl":"https:\/\/dtaugury.wpengine.com\/wp-admin\/admin-ajax.php","isMobile":"false","templateApiUrl":"https:\/\/dtaugury.wpengine.com\/wp-json\/jet-elements-api\/v1\/elementor-template","devMode":"false","messages":{"invalidMail":"Please specify a valid e-mail"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/jet-elements/assets/js/jet-elements.min.js?ver=2.6.11' id='jet-elements-js'></script>
<script type='text/javascript' id='jet-tabs-frontend-js-extra'>
/* <![CDATA[ */
var JetTabsSettings = {"ajaxurl":"https:\/\/dtaugury.wpengine.com\/wp-admin\/admin-ajax.php","isMobile":"false","templateApiUrl":"https:\/\/dtaugury.wpengine.com\/wp-json\/jet-tabs-api\/v1\/elementor-template","devMode":"false"};
/* ]]> */
</script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/jet-tabs/assets/js/jet-tabs-frontend.min.js?ver=2.1.22' id='jet-tabs-frontend-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/jet-tricks/assets/js/lib/tippy/popperjs.js?ver=2.5.2' id='jet-tricks-popperjs-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/jet-tricks/assets/js/lib/tippy/tippy-bundle.js?ver=6.3.1' id='jet-tricks-tippy-bundle-js'></script>
<script type='text/javascript' id='jet-tricks-frontend-js-extra'>
/* <![CDATA[ */
var JetTricksSettings = {"elements_data":{"sections":{"967d606":{"view_more":false,"particles":"false","particles_json":null},"39a37cc8":{"view_more":false,"particles":"false","particles_json":null},"c711845":{"view_more":false,"particles":"false","particles_json":null},"22b58ec":{"view_more":false,"particles":"false","particles_json":null},"de2eff1":{"view_more":false,"particles":"false","particles_json":null},"cb483d7":{"view_more":false,"particles":"false","particles_json":null},"6b56aff":{"view_more":false,"particles":"false","particles_json":null},"b1fe580":{"view_more":false,"particles":"false","particles_json":null},"ae17e8d":{"view_more":false,"particles":"false","particles_json":null},"50c980a":{"view_more":false,"particles":"false","particles_json":null},"517f8dd":{"view_more":false,"particles":"false","particles_json":null},"bb37020":{"view_more":false,"particles":"false","particles_json":null},"97201ab":{"view_more":false,"particles":"false","particles_json":null},"d775afc":{"view_more":false,"particles":"false","particles_json":null},"586d458":{"view_more":false,"particles":"false","particles_json":null},"d676024":{"view_more":false,"particles":"false","particles_json":null},"2d423dc":{"view_more":false,"particles":"false","particles_json":null},"c11e42e":{"view_more":false,"particles":"false","particles_json":null},"6f8eb4f":{"view_more":false,"particles":"false","particles_json":null},"9219d12":{"view_more":false,"particles":"false","particles_json":null},"1ebafb8":{"view_more":false,"particles":"false","particles_json":null},"edaa091":{"view_more":false,"particles":"false","particles_json":null},"2a0601f":{"view_more":false,"particles":"false","particles_json":null},"269803ef":{"view_more":false,"particles":"false","particles_json":null},"49cd422":{"view_more":false,"particles":"false","particles_json":null},"89cdf1b":{"view_more":false,"particles":"false","particles_json":null},"c2e23a4":{"view_more":false,"particles":"false","particles_json":null},"8b666af":{"view_more":false,"particles":"false","particles_json":null},"cc79a2b":{"view_more":false,"particles":"false","particles_json":null},"f10af8b":{"view_more":false,"particles":"false","particles_json":null},"e513916":{"view_more":false,"particles":"false","particles_json":null},"4837477":{"view_more":false,"particles":"false","particles_json":null},"77224d7":{"view_more":false,"particles":"false","particles_json":null},"9784735":{"view_more":false,"particles":"false","particles_json":null}},"columns":[],"widgets":{"1aab21f":[],"d291e16":[],"24e37b9":[],"df1e196":[],"21dbe73":[],"9402cb7":[],"73dfe88f":[],"7011684d":[],"9038a32":[],"0592a2a":[],"1db6614":[],"056b20a":[],"2c2f838":[],"964ae64":[],"cfce6c9":[],"5dfd8ef":[],"17b6f10":[],"6ff3b6c":[],"3e76fa27":[],"5a1f542":[],"829d038":[],"b148c7f":[],"b1bda54":[],"5038b01":[],"6e6250f":[],"f597090":[],"b506093":[],"20c02c5":[],"0200365":[],"e3ee78d":[],"1aecbe4":[],"59738c1":[],"ce34165":[],"16f7386":[],"68c02c5":[],"b784976":[],"0231c69":[],"51d11ed":[],"79e4e83":[],"6b8fb85":[],"aee2470":[],"18d4521":[],"1c6afd6":[],"8916b8b":[],"f288b51":[],"cb57658":[],"e2bcded":[],"19f458c":[],"a846109":[],"849593b":{"parallax":"true","invert":"false","speed":{"unit":"%","size":50,"sizes":[]},"stickyOn":["desktop","tablet"]},"dc83678":[],"b8f8bb7":[],"fd696af":[],"1f04d7b":[],"c6a9fdc":[],"10d86c14":[],"6cd2492":[],"243a7356":[],"eb1c940":[],"0d163bb":[],"8d3d6c6":[],"5d61aa1":[],"5d326ea":[],"8ad355e":{"parallax":"true","invert":"false","speed":{"unit":"%","size":20,"sizes":[]},"stickyOn":["desktop","tablet"]},"8f74bfa":[],"ae5dd92":[],"7f5480a":[],"33ec241":[],"5f2c516":[],"606c4c8":[],"e0268d4":[],"8be958c":[],"85e1c24":[],"a7f848b":[],"c547f60":[]}}};
/* ]]> */
</script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/jet-tricks/assets/js/jet-tricks-frontend.js?ver=1.4.4' id='jet-tricks-frontend-js'></script>
<script type='text/javascript' src='https://dtaugury.wpengine.com/wp-content/plugins/elementor/assets/js/preloaded-modules.min.js?ver=3.14.1' id='preloaded-modules-js'></script>
<script id="rs-initialisation-scripts">
		var	tpj = jQuery;

		var	revapi1;

		if(window.RS_MODULES === undefined) window.RS_MODULES = {};
		if(RS_MODULES.modules === undefined) RS_MODULES.modules = {};
		RS_MODULES.modules["revslider11"] = {once: RS_MODULES.modules["revslider11"]!==undefined ? RS_MODULES.modules["revslider11"].once : undefined, init:function() {
			window.revapi1 = window.revapi1===undefined || window.revapi1===null || window.revapi1.length===0  ? document.getElementById("rev_slider_1_1") : window.revapi1;
			if(window.revapi1 === null || window.revapi1 === undefined || window.revapi1.length==0) { window.revapi1initTry = window.revapi1initTry ===undefined ? 0 : window.revapi1initTry+1; if (window.revapi1initTry<20) requestAnimationFrame(function() {RS_MODULES.modules["revslider11"].init()}); return;}
			window.revapi1 = jQuery(window.revapi1);
			if(window.revapi1.revolution==undefined){ revslider_showDoubleJqueryError("rev_slider_1_1"); return;}
			revapi1.revolutionInit({
					revapi:"revapi1",
					sliderLayout:"fullwidth",
					visibilityLevels:"1240,1024,778,480",
					gridwidth:"1390,1024,778,480",
					gridheight:"800,550,500,450",
					lazyType:"smart",
					spinner:"spinner0",
					perspectiveType:"local",
					keepBPHeight:true,
					editorheight:"800,550,500,450",
					responsiveLevels:"1240,1024,778,480",
					progressBar:{disableProgressBar:true},
					navigation: {
						onHoverStop:false
					},
					viewPort: {
						global:true,
						globalDist:"-200px",
						enable:false
					},
					fallbacks: {
						allowHTML5AutoPlayOnAndroid:true
					},
			});

		}} // End of RevInitScript

		if (window.RS_MODULES.checkMinimal!==undefined) { window.RS_MODULES.checkMinimal();};
	</script>
</body>
</html>
