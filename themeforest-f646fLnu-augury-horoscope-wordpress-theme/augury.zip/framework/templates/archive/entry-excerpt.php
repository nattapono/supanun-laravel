<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

	<div class="entry-body"><?php echo augury_excerpt( $excerpt_length );?></div>